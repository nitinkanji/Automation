################################################################################
#
#   Title: myVipShelll.psm1
#
#   By: Todd Lehmann (toddle)
#
#    Purpose: Provides various cmdlets for interacting with myVips service 
#        (http://myVips/myVipsEngine/UserHLBMgmtSvc.asmx)
#
################################################################################

# TODO
#   * Add Try\Catch to recreate connection to MyVips if it's gone stale or is
#       otherwise not available
#
#   * Make connection object available only to functions, not a global variable
#
#   * Add switch to Resume-ITVipNode and Suspend-ITVipNode to disable all ports

# changelog:
# fixed Nodes UserNote in line #4054, updated version to 3.0.2 by BV


#REGION GlobalVariables
$MyVipShellVersion = '3.0.2'     # Current MyVip Shell version number
$MyVipsDefaultUrl = 'http://myvips'    # Default web service location
$MyVipsNotificationAlias = $null        # Groupa alias to send notification emails to
#ENDREGION GlobalVariables

#REGION PublicFunctions
################################################################################
#
# Returns a [System.Web.Services.Protocols.SoapHttpClientProtocol] for the 
#    MyVips service
#
################################################################################
function New-ITMyVipsConnection 
{
    <#  
    .SYNOPSIS  
        Creates a connection to the MyVips service
    .DESCRIPTION  
        Creates a connection to the MyVips service
    .NOTES  
        Author     : Todd Lehmann(toddle), Bohdan Velushchak (bohdanv) 
        Requires   : PowerShell V2, MyVips
    .EXAMPLE  
        New-ITMyVipsConnection
        Description
        -----------
        Creates a new connection to the MyVips service 
    .EXAMPLE
        $Credential = Get-Credential
        New-ITMyVipsConnection -CustomCredential $Credential
        
        Description
        -----------
        Creates a connection to the MyVips service as $Credential
    .EXAMPLE  
        New-ITMyVipsConnection -NotifyAlias operations
        Description
        -----------
        Creates a new connection to the MyVips service. If any updates are available for the module, an email will be sent to -NotifyAlias. Otherwise, an email notification will be sent to all VIP owner groups the account is a member of
    .PARAMETER CustomCredential
        Connects to the MyVips service under an identity other than the current user. Takes a PSCredential object
    .PARAMETER URL
        Web service URL to connect to
    .PARAMETER ShellVersion
        Version of the MyVip Shell to check against the MyVips web service
    .PARAMETER ReturnObject
        Returns the connection object if desired
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low",
            DefaultParametersetName = "CustomCredential"
        )]
        
        #REGION ParamaeterSet:CustomCredential
        
        #REGION $CustomCredential
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $false,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            ParameterSetName = "CustomCredential",
            HelpMessage = "Use currently logged in credentials"
        )]
        [System.Management.Automation.PSCredential]
        $CustomCredential 
        # Parameter Definition - End
        #ENDREGION $CustomCredential
        
        #ENDREGION ParamaeterSet:CustomCredential
        
        #REGION ParamaeterSet:General
        
        #REGION $Url
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Creates a web service proxy to the MyVips web service"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $Url = $MyVipsDefaultUrl
        # Parameter Definition - End
        #ENDREGION $Url
        
        #REGION $ShellVersion
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 2,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Shell version to connect as"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $ShellVersion = $MyVipShellVersion
        # Parameter Definition - End
        #ENDREGION $ShellVersion
        
        #REGION $NotifyAlias
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 3,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Shell version to connect as"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $NotifyAlias
        # Parameter Definition - End
        #ENDREGION $NotifyAlias
        
        #REGION $ReturnObject
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Returns the MyVips connection object"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    BEGIN
    {
        Write-DbgConsole ("Location: [New-ITMyVipsConnection]: Entering BEGIN ... ")

        # Make sure the URL is valid
        Write-DbgConsole -Message ("Verifying for web service is valid ... ")
        Write-DbgConsole -Message ("URL is " + $Url)
        
        if (($Url -match "http") -eq $true)
        {
            Write-DbgConsole ("It is a valid hostname" )
            $Uri = New-Object System.Uri -ArgumentList ($Url + '/myVipsEngine/UserHLBMgmtSvc.asmx')
            $HostName = $Uri.Host
        }
        else
        {
            Write-DbgConsole ("Invalid URL, gonna exit")
            throw("Invalid web service URI specified")
        }
        
        Write-Host 
        
        # Verify that the hostname is pingable
            
        Write-DbgConsole -Message ("Attempting to ping " + $Hostname)
        $IpAddresses = Resolve-IPAddress -Hostname $HostName
        if ($IpAddresses -ne $null)
        {
            Write-DbgConsole ("Able to resolve hostname, attempting ping")
            if ((Test-Connection -ComputerName $HostName -Quiet -Count 1) -eq $false)
            {
                Write-DbgConsole ("Nope, unable to ping. Exiting.")
                throw("Unable to ping $Hostname")
            }
        }
        else
        {
            Write-DbgConsole ("Unable to resolve the host name, exiting")
            throw("Unable to resolve $HostName")
        }

        Write-DbgConsole ("Location: [New-ITMyVipsConnection]: Exiting BEGIN ... ")
    }
    PROCESS 
    {
        Write-DbgConsole ("Location: [New-ITMyVipsConnection]: Entering PROCESS ... ")
        
        # Determine if a custom credential was passed, then do the appropriate thing
        
        switch ($PsCmdlet.ParameterSetName.ToUpper())
        {
            "CUSTOMCREDENTIAL"
            {
                # check for a credential, and error out if it doesnt exist, otherwise
                # create connection as a global var
                if ($Credential)
                {
                    Write-DbgConsole ("Some credential was passed, creating connection to " + $Url)
                    Write-DbgConsole ('Removing global var and recreate it')
                    Remove-Variable -Name MyVipsWebProxy -Scope Global -ErrorAction SilentlyContinue
                    Write-DbgConsole ('Attempting to connect using custom credential ... ')
                    New-Variable -Name MyVipsWebProxy -Scope Global -Value (New-WebServiceProxy -Uri $Uri.AbsoluteUri -Credential $Credential -ErrorAction Stop)
                    Write-DbgConsole ('Connection completed')
                }
                else
                {
                    Write-DbgConsole ('No custom credential specified, exiting')
                    Write-Error ("-Credential paramter not specified")
                }
            }
            default
            {
                # if no parameter specified at run time, just use the current user's credentials
                Write-DbgConsole ('Connecting using current user identity')
                Write-DbgConsole ('Removing global var so it can be recreated ... ')
                
                try
                {
                    Remove-Variable -Name MyVipsWebProxy -Scope Global -ErrorAction SilentlyContinue
                    Write-DbgConsole ('Attempting to connect to ' + $Url)
                    New-Variable -Name MyVipsWebProxy -Scope Global -Value (New-WebServiceProxy -Uri $Uri.AbsoluteUri -UseDefaultCredential -ErrorAction Stop )
                    Write-DbgConsole ('Connection completed')
                }
                catch [Exception]
                {
                    Write-Host
                    Write-Host ($_.Exception.Message)
                    Write-Host
                    Write-Host ($_.Exception.InnerException.Message)
                    Write-Host
                }
                
            }
        }

        # Let the user know which host they connected to
        Write-Host
        Write-Host ((Get-Date).ToString('MM/dd HH:mm:ss') + ': Connection to MyVips (' + ($Uri.Scheme + '://' + $Uri.Host) + ') established')
        Write-Host
        
        # Make sure the current version is compatible
        if ($NotifyAlias)
        {
            $VersionCheck = Compare-ModuleVersion -Version $ShellVersion -NotifyAlias $NotifyAlias
        }
        else
        {
            $VersionCheck = Compare-ModuleVersion -Version $ShellVersion
        }

        if($VersionCheck -ne $null)
        {
            if($VersionCheck -eq $false)
            {
                Write-Host
                Write-Host -ForegroundColor Red ('MyVipsShell has failed version check and cannot continue. Please update your version of MyVipsShell from the MyVips web site')
                Write-Host
                break
            }
        }
        else
        {
            Write-Host ("This code should not have executed.")
            break
        }

        # If for some reason wants to use the connection for some other purpose,
        # will return the object if -ReturnObject is passed, otherwise just exit
    
        if ($ReturnObject.IsPresent -eq $true)
        {
            Write-DbgConsole ('User wants the connnection object, back, so returning it and exiting... ')
            return $MyVipsWebProxy
        }
        else
        {
            Write-DbgConsole ('User does not want the connection object, so not doing anything ... ')
        }

        Write-DbgConsole ("Location: [New-ITMyVipsConnection]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Retrieves all the VIPs the user has access to
#
################################################################################
function Get-ITMyVips
{
    <#  
    .SYNOPSIS  
        Retrieves all the VIPs the user has access to
    .DESCRIPTION
        Retrieves all the VIPs the user has access to
    .NOTES  
        Author     : Todd Lehmann(toddle), Bohdan Velushchak (bohdanv) 
        Requires   : PowerShell V2, MyVips
    .EXAMPLE  
        Get-ITVips
        Description
        -----------
        Lists all VIPs the user has access to
    .EXAMPLE  
        Get-ITVips | -ShowHealthInformation
        Description
        -----------
        Lists all VIPs the user has access to, along with VIP availability 
    .EXAMPLE  
        Get-ITVips -ReturnObject | Where {$_.OwnerGroupAlias -eq "Domain\Username"} | Format-Table -Wrap -Autosize
        Description
        -----------
        Lists all VIPs where the OwnerGroup Alias is "Domain\Username"
    .OUTPUTS
        Returns a [PSObject] to the pipeline when -ReturnObject is used, otherwise nothing
    .PARAMETER ReturnObject
        Returns the raw object
    .PARAMETER ShowHealthInformation
        Shows the availability information for each VIP the user has access to
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low",
            DefaultParametersetName = "CustomCredential"
        )]
        
        #REGION ParamaeterSet:General
        
        #REGION $ReturnObject
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Returns the MyVips connection object"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject
        
        #REGION $ShowHealthInformation
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Shows availability information for each VIP"
        )]
        [Switch]
        $ShowHealthInformation
        # Parameter Definition - End
        #ENDREGION $ShowHealthInformation

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Get-ITVips]: Entering PROCESS ... ")
        
        # A variable can be set so that users scripting using this module
        #   don't have to remember to include -ReturnObject on each command
        if ($MyVipsScriptingMode -eq $true)
        {
            $ReturnObject = [Switch]::Present
        }
        
        # Check for connection to My Vips, and if its not there create a new one
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }

        try
        {
            $AvailableVips = $MyVipsWebProxy.GetVIPs($null)
        }
        catch [System.Web.Services.Protocols.SoapException]
        {
            $SoapError = Parse-SoapException -Message $_.Exception.Message
            
            Write-SoapException -ErrorObject $SoapError
            break
        }
        catch [Exception]
        {         
            Write-Host
            Write-Error ('An unexpected error has occurred')
            Write-Host
            Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
            Write-Host
            Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
            Write-Host
            Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
            Write-Host
            Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
            Write-Host
            Write-Host ('Message:' + $_.Exception.Message)
            Write-Host
            break
        }

        if ($ReturnObject.IsPresent)
        {
            return $AvailableVips 
        }
        elseif ($ShowHealthInformation.IsPresent -eq $true)
        {
            Write-Host 
            Write-Host ('Retrieving availability information for each VIP ... ')
            
            # Create a storage array for handy Format-Table usage
            $StatusTable = @()
            
            # Store the start time 
            $StartTime = (Get-Date)
            Write-DbgConsole ('Vip Information Retrieval Start Time: ' + $StartTime.ToString())
            
            # Start looking ip each VIPs information
            foreach ($VipItem in $AvailableVips)
            {
                Write-DbgConsole ('Looking up IP: ' + $VipItem.IP)
                $StatusTable += @(New-pvtMyVipsObject -StatusItem $VipItem)
            }
            
            Write-DbgConsole ('Found ' + $StatusTable.Count + ' VIPs')
            $StatusTable | Format-Table -AutoSize
            
            Write-Host ("Total time taken (Hours:Minutes:Seconds.Milliseconds):`t" + ((Get-Date).Subtract($StartTime)).ToString())
            Write-Host
        }
        else
        {
            $AvailableVips | Select IP,UserNote,OwnerGroupAlias,MailAlias | Format-Table -AutoSize
        }
        
        Write-DbgConsole ("Location: [Get-ITVips]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Get's the status of a VIP
#
################################################################################
function Get-ITVipStatus 
{
    <#  
    .SYNOPSIS  
    	Displays the status of a VIP, nodes and ports
    .DESCRIPTION  
    	Displays the status of a VIP, nodes and ports
        
        availability is evaluated as follows:
        * Ports - If port is enabled but is failing availability check, node is not fully available.  Disabled ports failing availability check are flagged, but are not counted against node availability
        * Nodes - If node is enabled and all enabled ports are available, node is fully available. Disabled ports are not counted against node availability.  The AvailabilityPercent is the percentage of enabled ports passing load balancer health checks, divided by total enabled ports
        * VIP - If all enabled nodes are 100% avaialble, then VIP is 100% availalbe.  AvailabilityPercent is calculated against the number of 100% available, enabled nodes against divided by total enabled nodes
        
    .NOTES  
    	Author     : Todd Lehmann(toddle), Bohdan Velushchak (bohdanv) 
    	Requires   : PowerShell v2, MyVips
    .EXAMPLE  
    	Get-ITVipStatus -VIP Farmname
    	Description
    	-----------
    	Resolves Farmname to BigIP VIP IP, then returns the status of the VIP and node members
    .EXAMPLE  
    	$VipObject = Get-ITVipStatus -VIP Farmname -ReturnObject
    	Description
    	-----------
    	Returns raw VipObject to be used as desired
    .INPUTS
    	-ReturnObject returns a VipObject to the pipeline 
    .PARAMETER VIP
    	The network name or IP of the VIP to be queried
    .PARAMETER ReturnObject
    	Returns a raw VipObject for manipulation
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]

        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General

        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to retrieve status for"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP

        #REGION $ReturnObject
        # Parameter Definition - Start
        , # Comma needed to separate multiple parameter definitions
        [Parameter(
            Mandatory = $false,
            #Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Returns the full VIP object"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [FunctionName]: Entering PROCESS ... ")
        
        # A variable can be set so that users scripting using this module
        #   don't have to remember to include -ReturnObject on each command
        if ($MyVipsScriptingMode -eq $true)
        {
            $ReturnObject = [Switch]::Present
        }
        
        # Resolve VIP to an IP
        Write-DbgConsole ('Resolving ' + $VIP)
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)
        
        # Check for existing connection, create one if none exists
        
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }
        
        # Get the VIP object
        Write-DbgConsole ('Getting VIP object')
        $VipObject = New-pvtITInitVipObject -VIP $VIP
                        
        if ($ReturnObject.IsPresent -eq $true)
        {
            return $VipObject
        }
        else
        {
            # Write the header            
            Write-pvtItStatusHeader -VipObject $VipObject
            Write-pvtItStatusBody -VipObject $VipObject
        }

        Write-DbgConsole ("Location: [Get-ITVipStatus]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function Get-ITNodeStatus 
{
    <#  
    .SYNOPSIS  
        Displays more verbose information about the nodes within a VIP
    .DESCRIPTION  
        Displays more verbose information about the nodes within a VIP
    .NOTES  
        Author     : Todd Lehmann
        Requires   : PowerShell v2, MyVips
    .EXAMPLE  
        Get-ITNodeStatus -VIP 10.10.10.10
        Description
        -----------
        Returns the status of each node in VIP 10.10.10.10
    .EXAMPLE  
        Get-ITNodeStatus -VIP 10.10.10.10 -ReturnObject
        Description
        -----------
        Returns the .Net object for use in scripts and other automation
    .INPUTS
        None 
    .OUTPUTS
        [PSObject] is return when -ReturnObject switch is used
    .PARAMETER VIP
        The network name or IP of the VIP to be suspended
    .PARAMETER ReturnObject
        Returns a [PSObject] with node information
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]
        
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "VIP the node is a member of"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP

        #REGION $ReturnObject
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Return the raw object"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Get-ITNodeStatus]: Entering PROCESS ... ")
        
        # A variable can be set so that users scripting using this module
        #   don't have to remember to include -ReturnObject on each command
        if ($MyVipsScriptingMode -eq $true)
        {
            $ReturnObject = [Switch]::Present
        }
        
        Write-DbgConsole ('Resolving ' + $VIP)
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)
        
        # Check for existing connection, create one if none exists
        
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }
        
        $VipObject = Get-ITVipStatus -VIP $VIP -ReturnObject
        $NodeArray = New-pvtITNodeArray $VipObject
        if ($ReturnObject.IsPresent -eq $true)
        {
            return $NodeArray
        }
        else
        {
            $NodeArray | Format-Table -AutoSize | Out-Host
        }

        Write-DbgConsole ("Location: [Get-ITNodeStatus]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Retrieves the change log for a particular VIP
#
################################################################################
function Get-ITVipChangeLog 
{
    <#  
    .SYNOPSIS  
        Displays the change log for a particular VIP
    .DESCRIPTION  
        Displays the change log for a particular VIP, displaying the most recent changes or changes from a date range
    .NOTES  
        Author     : Todd Lehmann
        Requires   : PowerShell v2, MyVips
    .EXAMPLE  
        Get-ITVipChangeLog Hostname
        Description
        -----------
        Returns up to the last 100 entries for the VIP for Hostname
    .EXAMPLE  
        Get-ITVipChangeLog Hostname -From 1/1/2012
        Description
        -----------
        Returns up to the last 100 entries for the VIP for Hostname, between 1/1/2012 and now
    .EXAMPLE  
        Get-ITVipChangeLog Hostname -From 1/1/2012 -To 2/2/2010
        Description
        -----------
        Returns up to the last 100 entries for the VIP for Hostname, between 1/1/2012 and 2/1/2012
    .EXAMPLE  
        Get-ITVipChangeLog Hostname -ReturnObject | Select Stamp,Requestor,Command,Node,Port,RequestorGroup | Export-CSV C:\ChangeLog.csv
        Description
        -----------
        Exports the TimeStamp, Requestor, Command, Node, Port, and RequestorGroup information of up to the last 100 entries for the VIP for Hostname to C:\ChangeLog.csv
    .INPUTS
        None
    .OUTPUTS
        if -ReturnObject is specified, returns raw change log object
    .PARAMETER VIP
        VIP to return the change log for
    .PARAMETER MaxiumEntries
        Maximum number of entries to return, up to 100
    .PARAMETER From
        Earliest date to return records from
    .PARAMETER To
        Latest date to return records from
    .PARAMETER ReturnObject
        Returns the raw change log resultset delivered by the web service
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]
        
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "VIP the retrieve the change log for"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP
        
        #REGION $MaximumEntries
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Maximum number of log entries to return"
        )]
        [Int]
        [ValidateNotNullOrEmpty()]
        $MaximumEntries = 100
        # Parameter Definition - End
        #ENDREGION $MaximumEntries
        
        #REGION $From
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 2,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Start time to retrieve entries from"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $From
        # Parameter Definition - End
        #ENDREGION $From
        
        #REGION $To
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 3,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "End time to retrieve entries from"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $To = ((Get-Date).ToString())
        # Parameter Definition - End
        #ENDREGION $To
        
        #REGION $ReturnObject
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Return raw change log"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject
        
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    BEGIN
    {
        # Replace the bracketed text with something relevant to you
        Write-DbgConsole ("Location: [Get-ITVipChangeLog]: Entering BEGIN ... ")
        
        # A variable can be set so that users scripting using this module
        #   don't have to remember to include -ReturnObject on each command
        if ($MyVipsScriptingMode -eq $true)
        {
            $ReturnObject = [Switch]::Present
        }
        
        # Web service will only return 100 entires, so placing that in a variable to warn the user and for easy maintanence
        $MaxWebServiceResultSet = 100
        
        # Make sure -From is prior to -To
        
        if ($From)
        {
            $From = (Get-Date -Date $From)
            $To = (Get-Date -Date $To)
            
            if ($From -gt $To)
            {
                Write-Error ('-From parameter must be a date prior to ' + $To.ToString())
                break
            }
        }
        
        # Check for active connection
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }

        Write-DbgConsole ("Location: [Get-ITVipChangeLog]: Exiting BEGIN ... ")
    }
    PROCESS 
    {
        Write-DbgConsole ("Location: [Get-ITVipChangeLog]: Entering PROCESS ... ")
        
        # Resolve VIP to an IP
        Write-DbgConsole ('Resolving ' + $VIP)
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)

        # Write out the vip header 
        Write-pvtItStatusHeader -VipObject (New-pvtITInitVipObject -VIP $VIP)

        # If they've specified a from, then assume user wants to see a date range. -To defaults to now unless otherwise specified
        if ($From)
        {
            try
            {
                $ChangeLog = @($MyVipsWebProxy.GetVipChangeLog($null,$VIP,$From,$To,$MaximumEntries))
            }
            catch [System.Web.Services.Protocols.SoapException]
            {
                $SoapError = Parse-SoapException -Message $_.Exception.Message
                
                Write-SoapException -ErrorObject $SoapError
                break
                
            }
            catch [Exception]
            {         
                Write-Host
                Write-Error ('An unexpected error has occurred')
                Write-Host
                Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
                Write-Host
                Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
                Write-Host
                Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
                Write-Host
                Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
                Write-Host
                Write-Host ('Message:' + $_.Exception.Message)
                Write-Host
                break
            }
        }
        # Otherwise, just return the last x entries, which defaults to 100
        else
        {
            try
            {
                $ChangeLog = @($MyVipsWebProxy.GetVipChangeLog($null,$VIP,$null,$null,$MaximumEntries))
            }
            catch [System.Web.Services.Protocols.SoapException]
            {
                $SoapError = Parse-SoapException -Message $_.Exception.Message
                
                Write-SoapException -ErrorObject $SoapError
                break
                
            }
            catch [Exception]
            {         
                Write-Host
                Write-Error ('An unexpected error has occurred')
                Write-Host
                Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
                Write-Host
                Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
                Write-Host
                Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
                Write-Host
                Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
                Write-Host
                Write-Host ('Message:' + $_.Exception.Message)
                Write-Host
                break
            }
        }

        # Since the web service itself will not return more than 100, let the user know they can access more than the last 100 entries
        if ($ChangeLog.Count -eq $MaxWebServiceResultSet)
        {
            Write-Host
            Write-Host -ForegroundColor Red -BackgroundColor Yellow ($ChangeLog.Count + ' is maximum number of entries that can be returned from MyVips. If you are looking for a time range that is not displayed, please use -From and -To. Please see Get-Help for more information')
            Write-Host
        }
        
        # Return the raw change log, if requested. Useful for things like exporting the log to a CSV
        if ($ReturnObject.IsPresent -eq $true)
        {
            return $ChangeLog
        }
        # Else spew results to screen in a friendly format
        else
        {
            $ChangeLog | Select @{Label="Time (24hr)";Expression={(Get-Date -Date $_.Stamp -Format "MM/dd/yyyy HH:mm:ss")}},Requestor,Command,Node,Port,RequestorGroup | Format-Table -AutoSize -Wrap
            Write-Host ('Found ' + $ChangeLog.Count + ' changes')
            Write-Host
        }
        
        Write-DbgConsole ("Location: [Get-ITVipChangeLog]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Stops a VIP from taking traffic
#
################################################################################
function Suspend-ITVip 
{
    <#  
    .SYNOPSIS  
    	Stops a VIP from taking traffic
    .DESCRIPTION  
    	Stops a VIP from taking traffic
    .NOTES  
    	Author     : Todd Lehmann(toddle), Bohdan Velushchak (bohdanv) 
    	Requires   : PowerShell v2, MyVips
    .EXAMPLE  
    	Suspend-ITVip -VIP 10.10.10.10
    	Description
    	-----------
    	Stops VIP 10.10.10.10 from taking traffic
    .INPUTS
    	None 
    .OUTPUTS
    	[PSObject] if -ReturnObject is used
    .PARAMETER VIP
    	The network name or IP of the VIP to be suspended
    .PARAMETER ReturnObject
        Returns the raw VIP object for use in scripting tasks
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "High"
        )]
                
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General

        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to retrieve status for"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP

        #REGION $ReturnObject
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Return the raw object"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Suspend-ITVip]: Entering PROCESS ... ")

        # A variable can be set so that users scripting using this module
        #   don't have to remember to include -ReturnObject on each command
        if ($MyVipsScriptingMode -eq $true)
        {
            $ReturnObject = [Switch]::Present
        }
        
        # Resolve VIP to IP
        Write-DbgConsole ('Resolving ' + $VIP + ' to IP address')
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)
        
        # Check for existing connection, create one if none exists
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }

        # Show status before modification
        # Supress output if being used in a script
        if ($ReturnObject.IsPresent -eq $false)
        {
            Write-Host
            Write-Host ('Current status for ' + $VIP)
            Get-ITVipStatus -VIP $VIP
            Write-Host ('Suspending VIP')
        }

        try
        {
            $UpdatedVIP = New-pvtITInitVipObject -VipStatus ($MyVipsWebProxy.DisableVip($null,$VIP))
        }
        catch [System.Web.Services.Protocols.SoapException]
        {
            $SoapError = Parse-SoapException -Message $_.Exception.Message
            
            Write-SoapException -ErrorObject $SoapError
            break
        }
        catch [Exception]
        {         
            Write-Host
            Write-Error ('An unexpected error has occurred')
            Write-Host
            Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
            Write-Host
            Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
            Write-Host
            Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
            Write-Host
            Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
            Write-Host
            Write-Host ('Message:' + $_.Exception.Message)
            Write-Host
            break
        }
        
        if ($ReturnObject.IsPresent -eq $true)
        {
            return $UpdatedVIP
        }
        else
        {
            Write-Host ('Current VIP status:')
            Write-pvtItStatusHeader -VipObject $UpdatedVIP        
            Write-pvtItStatusBody -VipObject $UpdatedVIP
        }
        
        Write-DbgConsole ("Location: [Suspend-ITVip]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Enables a VIP to take traffic
#
################################################################################
function Resume-ITVip 
{
    <#  
    .SYNOPSIS  
    	Enables a VIP for receive traffic
    .DESCRIPTION  
    	Enables a VIP for receive traffic
    .NOTES  
    	Author     : Todd Lehmann(toddle), Bohdan Velushchak (bohdanv) 
    	Requires   : PowerShell v2, MyVips
    .EXAMPLE  
    	Resume-ITVip -VIP 10.10.10.10
    	Description
    	-----------
    	Enables VIP 10.10.10.10 to take traffic
    .INPUTS
    	None 
    .OUTPUTS
    	[PSObject] if -ReturnObject is used
    .PARAMETER VIP
    	The network name or IP of the VIP to be enabled
    .PARAMETER ReturnObject
        Returns the raw VIP object for use in scripting tasks
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "High"
        )]
                
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General

        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to retrieve status for"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP
        
        #REGION $ReturnObject
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Return the raw object"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Resume-ITVip]: Entering PROCESS ... ")
        
        # Resolve VIP to IP
        Write-DbgConsole ('Resolving ' + $VIP + ' to IP address')
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)
        
        # Check for existing connection, create one if none exists
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }

        # Show status before modification
        # Supress output if being used in a script
        if ($ReturnObject.IsPresent -eq $false)
        {
            Write-Host
            Write-Host ('Current status for ' + $VIP)
            Get-ITVipStatus -VIP $VIP
            Write-Host ('Resuming VIP')
        }

        try
        {
            $UpdatedVIP = New-pvtITInitVipObject -VipStatus ($MyVipsWebProxy.EnableVip($null,$VIP))
        }
        catch [System.Web.Services.Protocols.SoapException]
        {
            $SoapError = Parse-SoapException -Message $_.Exception.Message
            
            Write-SoapException -ErrorObject $SoapError
            break
        }
        catch [Exception]
        {         
            Write-Host
            Write-Error ('An unexpected error has occurred')
            Write-Host
            Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
            Write-Host
            Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
            Write-Host
            Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
            Write-Host
            Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
            Write-Host
            Write-Host ('Message:' + $_.Exception.Message)
            Write-Host
            break
        }
        
        if ($ReturnObject.IsPresent -eq $true)
        {
            return $UpdatedVIP
        }
        else
        {
            Write-Host ('Current VIP status:')
            Write-pvtItStatusHeader -VipObject $UpdatedVIP        
            Write-pvtItStatusBody -VipObject $UpdatedVIP
        }
        
        Write-DbgConsole ("Location: [Resume-ITVip]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Removes a node within a VIP from rotation
#
################################################################################
function Suspend-ITVipNode 
{
    <#  
    .SYNOPSIS  
    	Suspends a port on a node within a VIP from rotation
    .DESCRIPTION  
    	Suspends a port on a node within a VIP from rotation
    .NOTES  
    	Author     : Todd Lehmann(toddle), Bohdan Velushchak (bohdanv) 
    	Requires   : PowerShell v2, MyVips
    .EXAMPLE  
    	Suspend-ITVipNode -VIP 10.10.10.10 -Node 10.11.11.11 -Port 80
    	Description
    	-----------
    	Disables port 80 on node 10.11.11.11 in VIP 10.10.10.10
    .INPUTS
    	None 
    .OUTPUTS
    	[PSObject] if -ReturnObject is specified or if $MyVipsScriptingMode is set to $true
    .PARAMETER VIP
    	The network name or IP of the VIP to be modified
    .PARAMETER Node
    	The IP of the Node to be modified
    .PARAMETER Port
    	Port to be disabled
    .PARAMETER ReturnObject
        Supresses console output and returns the VIP object after the node has been added
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "High"
        )]
                
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General

        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to retrieve status for"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP

        #REGION $NodeIP
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $true,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "IP of node to suspend"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $NodeIP
        # Parameter Definition - End
        #ENDREGION $NodeIP

        #REGION $Port
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $true,
            Position = 2,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Port to disable"
        )]
        [Int]
        [ValidateNotNullOrEmpty()]
        $Port
        # Parameter Definition - End
        #ENDREGION $Port
        
        #REGION $ReturnObject
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Return the raw object"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Suspend-ITVipNode]: Entering PROCESS ... ")
        
        # A variable can be set so that users scripting using this module
        #   don't have to remember to include -ReturnObject on each command
        if ($MyVipsScriptingMode -eq $true)
        {
            $ReturnObject = [Switch]::Present
        }
        
        # Resolve VIP to IP
        Write-DbgConsole ('Resolving ' + $VIP + ' to IP address')
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)
        
        # Check for existing connection, create one if none exists
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }

        # Current node status
        # Supress output if used in a script
        if ($ReturnObject.IsPresent -eq $false)
        {
            Write-Host
            Write-Host ('Current status for ' + $NodeIP)
            Get-ITNodeStatus -VIP $VIP
            Write-Host ('Suspending VIP')
        }

        try
        {
            $UpdatedVIP = New-pvtITInitVipObject -VipStatus ($MyVipsWebProxy.DisableVIPNode($null,$VIP,$NodeIP,$Port))
        }
        catch [System.Web.Services.Protocols.SoapException]
        {
            $SoapError = Parse-SoapException -Message $_.Exception.Message
            
            Write-SoapException -ErrorObject $SoapError
            break
        }
        catch [Exception]
        {         
            Write-Host
            Write-Error ('An unexpected error has occurred')
            Write-Host
            Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
            Write-Host
            Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
            Write-Host
            Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
            Write-Host
            Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
            Write-Host
            Write-Host ('Message:' + $_.Exception.Message)
            Write-Host
            break
        }
        
        if ($ReturnObject.IsPresent -eq $true)
        {
            return $UpdatedVIP
        }
        else
        {
            Write-Host ('Updated node status')
            $NodeArray = New-pvtITNodeArray -VipObject $UpdatedVIP
            $NodeArray | Where {$_.NodeIP -eq $NodeIP} | Format-Table -AutoSize | Out-Host
        }

        Write-DbgConsole ("Location: [Suspend-ITVipNode]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Addes a node within a VIP to rotation
#
################################################################################
function Resume-ITVipNode 
{
    <#  
    .SYNOPSIS  
    	Enables a port on a node within a VIP
    .DESCRIPTION  
    	Enables a port on a node within a VIP
    .NOTES  
    	Author     : Todd Lehmann(toddle), Bohdan Velushchak (bohdanv) 
    	Requires   : PowerShell v2, MyVips
    .EXAMPLE  
    	Resume-ITVipNode -VIP 10.10.10.10 -Node 10.11.11.11 -Port 80
    	Description
    	-----------
    	Enables port 80 on node 10.11.11.11 in VIP 10.10.10.10
    .INPUTS
    	None 
    .OUTPUTS
    	[PSObject] if -ReturnObject is specified or if $MyVipsScriptingMode is set to $true
    .PARAMETER VIP
    	The network name or IP of the VIP to be modified
    .PARAMETER Node
    	The IP of the Node to be modified
    .PARAMETER Port
    	Port to be enabled
    .PARAMETER ReturnObject
        Supresses console output and returns the VIP object after the node has been added
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "High"
        )]
                
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General

        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to retrieve status for"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP

        #REGION $NodeIP
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $true,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "IP of node to resume"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $NodeIP
        # Parameter Definition - End
        #ENDREGION $NodeIP

        #REGION $Port
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $true,
            Position = 2,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Port to enable traffic on"
        )]
        [Int]
        [ValidateNotNullOrEmpty()]
        $Port
        # Parameter Definition - End
        #ENDREGION $Port
        
        #REGION $ReturnObject
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Return the raw object"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Resume-ITVipNode]: Entering PROCESS ... ")
        
        # A variable can be set so that users scripting using this module
        #   don't have to remember to include -ReturnObject on each command
        if ($MyVipsScriptingMode -eq $true)
        {
            $ReturnObject = [Switch]::Present
        }
        
        # Resolve VIP to IP
        Write-DbgConsole ('Resolving ' + $VIP + ' to IP address')
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)
        
        # Check for existing connection, create one if none exists
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }

        # Current node status
        # Supress output if used in a script
        if ($ReturnObject.IsPresent -eq $false)
        {
            Write-Host
            Write-Host ('Current status for ' + $VIP)
            Get-ITVipStatus -VIP $VIP
            Write-Host ('Resuming node')
        }

        try
        {
            $UpdatedVIP = New-pvtITInitVipObject -VipStatus ($MyVipsWebProxy.EnableVIPNode($null,$VIP,$NodeIP,$Port))
        }
        catch [System.Web.Services.Protocols.SoapException]
        {
            $SoapError = Parse-SoapException -Message $_.Exception.Message
            
            Write-SoapException -ErrorObject $SoapError
            break
        }
        catch [Exception]
        {         
            Write-Host
            Write-Error ('An unexpected error has occurred')
            Write-Host
            Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
            Write-Host
            Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
            Write-Host
            Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
            Write-Host
            Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
            Write-Host
            Write-Host ('Message:' + $_.Exception.Message)
            Write-Host
            break
        }
        
        if ($ReturnObject.IsPresent -eq $true)
        {
            return $UpdatedVIP
        }
        else
        {
            Write-Host ('Updated node status')
            $NodeArray = New-pvtITNodeArray -VipObject $UpdatedVIP
            $NodeArray | Where {$_.NodeIP -eq $NodeIP} | Format-Table -AutoSize | Out-Host
        }

        Write-DbgConsole ("Location: [Resume-ITVipNode]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Adds a node to a VIP
#
################################################################################
function Add-ITVipNode
{
    <#  
    .SYNOPSIS  
    	Adds a node to a VIP
    .DESCRIPTION  
    	Adds a node to a VIP
    .NOTES  
    	Author     : Todd Lehmann(toddle), Bohdan Velushchak (bohdanv) 
    	Requires   : PowerShell v2, MyVips
    .EXAMPLE  
    	Add-ITVipNode -VIP 10.10.10.10 -Node 10.11.11.11
    	Description
    	-----------
    	Adds node 10.11.11.11 to VIP 10.10.10.10
    .INPUTS
    	None 
    .OUTPUTS
    	[PSObject] if -ReturnObject is specified or if $MyVipsScriptingMode is set to $true or if $MyVipsScriptingMode is set to $true
    .PARAMETER VIP
    	The network name or IP of the VIP to be modified
    .PARAMETER Node
    	The IP of the Node to be modified
    .PARAMETER ReturnObject
    	Supresses console output and returns the VIP object after the node has been added
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "High"
        )]
                
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General

        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to retrieve status for"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP

        #REGION $NodeIP
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $true,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "IP address of the node to add to VIP"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $NodeIP
        # Parameter Definition - End
        #ENDREGION $NodeIP

        #REGION $ReturnObject
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Return the raw object"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Add-ITVipNode]: Entering PROCESS ... ")

        # A variable can be set so that users scripting using this module
        #   don't have to remember to include -ReturnObject on each command
        if ($MyVipsScriptingMode -eq $true)
        {
            $ReturnObject = [Switch]::Present
        }

        # Resolve VIP to IP
        Write-DbgConsole ('Resolving ' + $VIP + ' to IP address')
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)
        
        # Check for existing connection, create one if none exists
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }

        # Current node status
        # Supress output if used in a script
        if ($ReturnObject.IsPresent -eq $false)
        {
            Write-Host
            Write-Host ('Current status for ' + $NodeIP)
            Get-ITNodeStatus -VIP $VIP
            Write-Host ('Adding node')
        }

        try
        {
            $UpdatedVIP = New-pvtITInitVipObject -VipStatus ($MyVipsWebProxy.AddNode($null,$VIP,$NodeIP))
        }
        catch [System.Web.Services.Protocols.SoapException]
        {
            $SoapError = Parse-SoapException -Message $_.Exception.Message
            
            Write-SoapException -ErrorObject $SoapError
            break
        }
        catch [Exception]
        {         
            Write-Host
            Write-Error ('An unexpected error has occurred')
            Write-Host
            Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
            Write-Host
            Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
            Write-Host
            Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
            Write-Host
            Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
            Write-Host
            Write-Host ('Message:' + $_.Exception.Message)
            Write-Host
            break
        }
        
        if ($ReturnObject.IsPresent -eq $true)
        {
            return $UpdatedVIP
        }
        else
        {
            Write-Host 
            Write-Host ('Node added to VIP')
            Write-Host ('Current VIP status:')
            Write-pvtItStatusHeader -VipObject $UpdatedVIP
            Write-pvtItStatusBody -VipObject $UpdatedVIP
        }

        Write-DbgConsole ("Location: [Add-ITVipNode]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Removes a node from a VIP
#
################################################################################
function Remove-ITVipNode
{
    <#  
    .SYNOPSIS  
    	Removes a node from a VIP
    .DESCRIPTION  
    	Removes a node from a VIP
    .NOTES  
    	Author     : Todd Lehmann(toddle), Bohdan Velushchak (bohdanv) 
    	Requires   : PowerShell v2, MyVips
    .EXAMPLE  
    	Remove-ITVipNode -VIP 10.10.10.10 -Node 10.11.11.11
    	Description
    	-----------
    	Removes node 10.11.11.11 from VIP 10.10.10.10
    .INPUTS
    	None 
    .OUTPUTS
    	[PSObject] if -ReturnObject is specified or if $MyVipsScriptingMode is set to $true or if $MyVipsScriptingMode is set to $true
    .PARAMETER VIP
    	The network name or IP of the VIP to be modified
    .PARAMETER Node
    	The IP of the Node to be modified
    .PARAMETER ReturnObject
    	Supresses console output and returns the VIP object after the node has been removed
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "High"
        )]
                
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General

        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to retrieve status for"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP

        #REGION $NodeIP
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $true,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "IP address of the node to add to VIP"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $NodeIP
        # Parameter Definition - End
        #ENDREGION $NodeIP

        #REGION $ReturnObject
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Return the raw object"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Remove-ITVipNode]: Entering PROCESS ... ")
        
        # A variable can be set so that users scripting using this module
        #   don't have to remember to include -ReturnObject on each command
        if ($MyVipsScriptingMode -eq $true)
        {
            $ReturnObject = [Switch]::Present
        }
        
        # Resolve VIP to IP
        Write-DbgConsole ('Resolving ' + $VIP + ' to IP address')
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)
        
        # Check for existing connection, create one if none exists
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }

        # Current node status
        # Supress output if used in a script
        if ($ReturnObject.IsPresent -eq $false)
        {
            Write-Host
            Write-Host ('Current status for ' + $VIP)
            Get-ITNodeStatus -VIP $VIP
            Write-Host ('Removing node')
        }

        try
        {
            $UpdatedVIP = New-pvtITInitVipObject -VipStatus ($MyVipsWebProxy.RemoveNode($null,$VIP,$NodeIP))
        }
        catch [System.Web.Services.Protocols.SoapException]
        {
            $SoapError = Parse-SoapException -Message $_.Exception.Message
            
            Write-SoapException -ErrorObject $SoapError
            break
        }
        catch [Exception]
        {         
            Write-Host
            Write-Error ('An unexpected error has occurred')
            Write-Host
            Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
            Write-Host
            Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
            Write-Host
            Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
            Write-Host
            Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
            Write-Host
            Write-Host ('Message:' + $_.Exception.Message)
            Write-Host
            break
        }
        
        if ($ReturnObject.IsPresent -eq $true)
        {
            return $UpdatedVIP
        }
        else
        {
            Write-Host 
            Write-Host ('Node added to VIP')
            Write-Host ('Current VIP status:')
            Write-pvtItStatusHeader -VipObject $UpdatedVIP
            Write-pvtItStatusBody -VipObject $UpdatedVIP
        }

        Write-DbgConsole ("Location: [Remove-ITVipNode]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function Resume-ITAllNodePorts 
{
    <#  
    .SYNOPSIS  
        Enables all ports on a node, or all nodes in a VIP
    .DESCRIPTION  
        Enables all ports on a node, or all nodes in a VIP
    .NOTES  
        Author     : Todd Lehmann and Bohdan Velushchak
        Requires   : PowerShell v2, MyVips
    .EXAMPLE  
        Resume-ITAllNodePorts -VIP 10.10.10.10
        Description
        -----------
        Enables all ports on all nodes in VIP 10.10.10.10 that are passing health checks on the load balancers
    .EXAMPLE  
        Resume-ITAllNodePorts -VIP 10.10.10.10 -NodeIP 10.10.10.11
        Description
        -----------
        Enables all ports on node 10.10.10.11 in VIP 10.10.10.10 that are passing health checks on the load balancers
    .INPUTS
        None
    .OUTPUTS
         [PSObject] if -ReturnObject is specified or if $MyVipsScriptingMode is set to $true or if $MyVipsScriptingMode is set to $true
    .PARAMETER VIP
    	The network name or IP of the VIP to be modified
    .PARAMETER Node
    	The IP of the Node to be modified
    .PARAMETER ReturnObject
    	Supresses console output and returns the VIP object after the ports have been enabled
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "High"
        )]
       
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to retrieve status for"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP

        #REGION $NodeIP
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "IP of node to resume"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $NodeIP
        # Parameter Definition - End
        #ENDREGION $NodeIP
        
        #REGION $ReturnObject
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Return the raw object"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject
        
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Resume-ITAllNodePorts]: Entering PROCESS ... ")
        
        # A variable can be set so that users scripting using this module
        #   don't have to remember to include -ReturnObject on each command
        if ($MyVipsScriptingMode -eq $true)
        {
            $ReturnObject = [Switch]::Present
        }
        
        # Resolve VIP to IP
        Write-DbgConsole ('Resolving ' + $VIP + ' to IP address')
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)
        
        # Check for existing connection, create one if none exists
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }
        
        if ($ReturnObject.IsPresent -eq $false)
        {
            Write-Host
            Write-Host ('Enabling all ports on all nodes in ' + $VIP)
            Write-Host ('Current node status:')
            Get-ItNodeStatus -VIP $VIP
        }
        
        # Get the VIP status
        $VipStatus = Get-ITVipStatus $VIP -ReturnObject
        
        # Whether changes were made
        $ChangesMade = $false

        # Find all the ports to enable
        # NOTE: Will only enable nodes that are passing health check
        if ($NodeIP)
        {
            $Node = ($VipStatus.Nodes | Where {$_.IPAddress -eq $NodeIP})
            if ($Node)
            {
                # Get all the healthy, disabled ports on a node
                $PortsToEnable = @($Node.Ports | Where {($_.Status -eq 'GREEN') -and ($_.Enabled -eq $false)})

                # Make sure there are ports to enable
                if ($PortsToEnable.Count -gt 0)
                {
                    # Enable ports
                    foreach ($Port in $PortsToEnable)
                    {
                        # Supress output if -ReturnObject specified
                        if ($ReturnObject.IsPresent -eq $true)
                        {
                            Write-Host ('Resuming port ' + $Port + ' on node ' + $Node.IPAddress + ' in VIP ' + $VIP)
                        }
                        # To supress output from Resume-ITVipNode, using -ReturnObject 
                        #   switch then throwing result away
                        # Updated status will be given once all operations are completed
                        Resume-ITVipNode -VIP $VIP -NodeIP $Node.IPAddress -Port $Port -ReturnObject | Out-Null
                    }
                    $ChangesMade = $true
                }
                # Nothing to enable, so lets all just move on with our lives
                else
                {
                    Write-Host
                    Write-Host ('There are no healthy, disabled ports in VIP ' + $VIP)
                    Write-Host
                    break
                }
            }
            # No node to muck with, so leave
            else
            {
                Write-Host
                Write-Host ('Node ' + $NodeIP + ' not found in ' + $VIP)
                Write-Host
                break
            }
        }
        # Enable all ports on all nodes in a VIP...
        else
        {
            # Get all the nodes in a VIP.  
            $AllNodes = $VipStatus.Nodes
            foreach ($Node in $AllNodes)
            {
                # Get all the healthy, disabled ports on a node
                $PortsToEnable = @($Node.Ports | Where {($_.Status -eq 'GREEN') -and ($_.Enabled -eq $false)})
                
                # Make sure there are ports to enable
                if ($PortsToEnable.Count -gt 0)
                {
                    foreach ($Port in $PortsToEnable)
                    {
                        # Supress output if -ReturnObject specified
                        if ($ReturnObject.IsPresent -eq $true)
                        {
                            Write-Host ('Resuming port ' + $Port + ' on node ' + $Node.IPAddress + ' in VIP ' + $VIP)
                        }
                        # To supress output from Resume-ITVipNode, using -ReturnObject 
                        #   switch then throwing result away
                        # Updated status will be given once all operations are completed
                        Resume-ITVipNode -VIP $VIP -NodeIP $Node.IPAddress -Port $Port -ReturnObject | Out-Null
                    }
                    $ChangesMade = $true
                }
                # Nothing to enable, so lets all just move on with our lives
                else
                {
                    Write-Host
                    Write-Host ('There are no healthy disabled ports on VIP')
                    Write-Host
                    break
                }
            }
        }

        # Get updated VIP status
        $UpdatedVIP = New-pvtITInitVipObject -VIP $VIP
        if ($ReturnObject.IsPresent -eq $true)
        {
            return $UpdatedVIP
        }
        else
        {
            if ($ChangesMade -eq $true)
            {
                Write-Host 
                Write-Host ('Current VIP status:')
                Write-pvtItStatusHeader -VipObject $UpdatedVIP
                Write-pvtItStatusBody -VipObject $UpdatedVIP
            }
        }
        
        Write-DbgConsole ("Location: [Resume-ITAllNodePorts]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function Suspend-ITAllNodePorts 
{
    <#  
    .SYNOPSIS  
        Disables all ports on a node, or all nodes in a VIP
    .DESCRIPTION  
        Disables all ports on a node, or all nodes in a VIP
    .NOTES  
        Author     : Todd Lehmann and Bohdan Velushchak
        Requires   : PowerShell v2, MyVips
    .EXAMPLE  
        Suspend-ITAllNodePorts -VIP 10.10.10.10
        Description
        -----------
        Disables all ports on all nodes in VIP 10.10.10.10 that are currently enabled
    .EXAMPLE  
        Resume-ITAllNodePorts -VIP 10.10.10.10 -NodeIP 10.10.10.11
        Description
        -----------
        Disables all ports on node 10.10.10.11 in VIP 10.10.10.10 that are currently enabled
    .INPUTS
        None
    .OUTPUTS
         [PSObject] if -ReturnObject is specified or if $MyVipsScriptingMode is set to $true or if $MyVipsScriptingMode is set to $true
    .PARAMETER VIP
    	The network name or IP of the VIP to be modified
    .PARAMETER Node
    	The IP of the Node to be modified
    .PARAMETER ReturnObject
    	Supresses console output and returns the VIP object after the ports have been enabled
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "High"
        )]
       
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to retrieve status for"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP

        #REGION $NodeIP
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "IP of node to resume"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $NodeIP
        # Parameter Definition - End
        #ENDREGION $NodeIP
        
        #REGION $ReturnObject
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Return the raw object"
        )]
        [Switch]
        $ReturnObject
        # Parameter Definition - End
        #ENDREGION $ReturnObject
        
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Suspend-ITAllNodePorts]: Entering PROCESS ... ")
        
        # A variable can be set so that users scripting using this module
        #   don't have to remember to include -ReturnObject on each command
        if ($MyVipsScriptingMode -eq $true)
        {
            $ReturnObject = [Switch]::Present
        }
        
        # Resolve VIP to IP
        Write-DbgConsole ('Resolving ' + $VIP + ' to IP address')
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)
        
        # Check for existing connection, create one if none exists
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }
        
        if ($ReturnObject.IsPresent -eq $false)
        {
            Write-Host
            Write-Host ('Enabling all ports on all nodes in ' + $VIP)
            Write-Host ('Current node status:')
            Get-ItNodeStatus -VIP $VIP
        }
        
        # Get the VIP status
        $VipStatus = Get-ITVipStatus $VIP -ReturnObject
        
        # Whether changes were made
        $ChangesMade = $false

        # Find all the ports to enable
        # NOTE: Will only enable nodes that are passing health check
        if ($NodeIP)
        {
            $Node = ($VipStatus.Nodes | Where {$_.IPAddress -eq $NodeIP})
            if ($Node)
            {
                # Get all the healthy, disabled ports on a node
                $PortsToDisable = @($Node.Ports | Where {$_.Enabled -eq $true})

                # Make sure there are ports to enable
                if ($PortsToDisable.Count -gt 0)
                {
                    # Enable ports
                    foreach ($Port in $PortsToDisable)
                    {
                        # Supress output if -ReturnObject specified
                        if ($ReturnObject.IsPresent -eq $false)
                        {
                            Write-Host ('Suspending port ' + $Port.Port + ' on node ' + $Node.IPAddress + ' in VIP ' + $VIP)
                        }
                        # To supress output from Resume-ITVipNode, using -ReturnObject 
                        #   switch then throwing result away
                        # Updated status will be given once all operations are completed
                        Suspend-ITVipNode -VIP $VIP -NodeIP $Node.IPAddress -Port $Port.Port -ReturnObject | Out-Null
                    }
                    $ChangesMade = $true
                }
                # Nothing to enable, so lets all just move on with our lives
                else
                {
                    Write-Host
                    Write-Host ('All ports on node ' + $NodeIP + ' in VIP ' + $VIP + ' are already disabled')
                    Write-Host
                    break
                }
            }
            # No node to muck with, so leave
            else
            {
                Write-Host
                Write-Host ('Node ' + $NodeIP + ' not found in ' + $VIP)
                Write-Host
                break
            }
        }
        # Enable all ports on all nodes in a VIP...
        else
        {
            # Get all the nodes in a VIP.  
            $AllNodes = $VipStatus.Nodes
            foreach ($Node in $AllNodes)
            {
                # Get all the healthy, disabled ports on a node
                $PortsToDisable = @($Node.Ports | Where {$_.Enabled -eq $true})
                
                # Make sure there are ports to enable
                if ($PortsToDisable.Count -gt 0)
                {
                    foreach ($Port in $PortsToDisable)
                    {
                        # Supress output if -ReturnObject specified
                        if ($ReturnObject.IsPresent -eq $false)
                        {
                            Write-Host ('Suspending port ' + $Port.Port + ' on node ' + $Node.IPAddress + ' in VIP ' + $VIP)
                        }
                        # To supress output from Resume-ITVipNode, using -ReturnObject 
                        #   switch then throwing result away
                        # Updated status will be given once all operations are completed
                        Suspend-ITVipNode -VIP $VIP -NodeIP $Node.IPAddress -Port $Port.Port -ReturnObject | Out-Null
                    }
                    $ChangesMade = $true
                }
                # Nothing to enable, so lets all just move on with our lives
                else
                {
                    Write-Host
                    Write-Host ('All ports on all nodes in VIP ' + $VIP + ' are already disabled')
                    Write-Host
                    break
                }
            }
        }

        # Get updated VIP status
        $UpdatedVIP = New-pvtITInitVipObject -VIP $VIP
        if ($ReturnObject.IsPresent -eq $true)
        {
            return $UpdatedVIP
        }
        else
        {
            if ($ChangesMade -eq $true)
            {
                Write-Host 
                Write-Host ('Current VIP status:')
                Write-pvtItStatusHeader -VipObject $UpdatedVIP
                Write-pvtItStatusBody -VipObject $UpdatedVIP
            }
        }
        
        Write-DbgConsole ("Location: [Suspend-ITAllNodePorts]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function Set-ITUserNote 
{
    <#  
    .SYNOPSIS  
        Sets the usernote field on a VIP or Node
    .DESCRIPTION
        Sets the usernote field on a VIP or Node
    .NOTES  
        Author     : Todd Lehmann, Bohdan Velushchak
        Requires   : PowerShell v2,MyVips
    .EXAMPLE  
        Set-ITUserNote -VIP 10.10.10.10 -UserNote 'Contoso'
        Description
        -----------
        Set's the usernote field on VIP 10.10.10.10 to Contoso
    .EXAMPLE  
        Set-ITUserNote -VIP 10.10.10.10 -NodeIP 10.10.10.11 -UserNote 'Server1'
        Description
        -----------
        Set's the usernote field on node 10.10.10.11 to Server1
    .INPUTS
        None 
    .OUTPUTS
        None  
    .PARAMETER VIP  
        VIP to set usernote on, or VIP that contains the node to set the usernote on
    .PARAMETER UserNote
        Value to set the usernote field to. Maximum characters of 30
    .PARAMETER NodeIP
        Node to set the usernote field on
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]
        
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to set Usernote on"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP
        
        #REGION $Usernote
        ,
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Value to set usernote to"
        )]
        [String]
        [ValidateLength(1,30)]
        [ValidateNotNullOrEmpty()]
        $Usernote
        # Parameter Definition - End
        #ENDREGION $Usernote
        
        #REGION $NodeIP
        ,
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $false,
            Position = 2,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Node to set Usernote on"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $NodeIP
        # Parameter Definition - End
        #ENDREGION $NodeIP
        
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain    
    PROCESS 
    {
        Write-DbgConsole ("Location: [Set-ITUserNote]: Entering PROCESS ... ")
        
        Write-DbgConsole ('Resolving ' + $VIP)
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)

        # Check for existing connection, create one if none exists
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }
       
        # Set the note on the node or VIP
        try
        {
            $MyVipsWebProxy = $MyVipsWebProxy.SetVipDescription($null,$VIP,$NodeIP,$Usernote)
        }
        catch [System.Web.Services.Protocols.SoapException]
        {
            $SoapError = Parse-SoapException -Message $_.Exception.Message
            
            Write-SoapException -ErrorObject $SoapError
            break
        }
        catch [Exception]
        {         
            Write-Host
            Write-Error ('An unexpected error has occurred')
            Write-Host
            Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
            Write-Host
            Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
            Write-Host
            Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
            Write-Host
            Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
            Write-Host
            Write-Host ('Message:' + $_.Exception.Message)
            Write-Host
            break
        }
        
        Write-DbgConsole ("Location: [Set-ITUserNote]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function Remove-ITUserNote 
{
    <#  
    .SYNOPSIS  
        Removes the usernote field on a VIP or Node
    .DESCRIPTION
        Removes the usernote field on a VIP or Node
    .NOTES  
        Author     : Todd Lehmann, Bohdan Velushchak
        Requires   : PowerShell v2,MyVips
    .EXAMPLE  
        Rmove-ITUserNote -VIP 10.10.10.10 
        Description
        -----------
        Removes the usernote field on VIP 10.10.10.10
    .EXAMPLE  
        Remove-ITUserNote -VIP 10.10.10.10 -NodeIP 10.10.10.11 
        Description
        -----------
        Removes the usernote field on node 10.10.10.11 to Server1
    .INPUTS
        None 
    .OUTPUTS
        None  
    .PARAMETER VIP  
        VIP to set usernote on, or VIP that contains the node to set the usernote on
    .PARAMETER UserNote
        Value to set the usernote field to. Maximum characters of 30
    .PARAMETER NodeIP
        Node to set the usernote field on
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]
        
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to set Usernote on"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP
        
        #REGION $NodeIP
        ,
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $false,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Node to set Usernote on"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $NodeIP
        # Parameter Definition - End
        #ENDREGION $NodeIP
        
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain    
    PROCESS 
    {
        Write-DbgConsole ("Location: [Set-ITUserNote]: Entering PROCESS ... ")
        
        Write-DbgConsole ('Resolving ' + $VIP)
        $VIP = Resolve-ITVipIP -VIP $VIP
        Write-DbgConsole ('Resolved to ' + $VIP)

        # Check for existing connection, create one if none exists
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }
       
        # Set the note on the node or VIP
        try
        {
            $MyVipsWebProxy = $MyVipsWebProxy.SetVipDescription($null,$VIP,$NodeIP,$null)
        }
        catch [System.Web.Services.Protocols.SoapException]
        {
            $SoapError = Parse-SoapException -Message $_.Exception.Message
            
            Write-SoapException -ErrorObject $SoapError
            break
        }
        catch [Exception]
        {         
            Write-Host
            Write-Error ('An unexpected error has occurred')
            Write-Host
            Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
            Write-Host
            Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
            Write-Host
            Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
            Write-Host
            Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
            Write-Host
            Write-Host ('Message:' + $_.Exception.Message)
            Write-Host
            break
        }
        
        Write-DbgConsole ("Location: [Set-ITUserNote]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function Register-ITNewVip 
{
    <#  
    .SYNOPSIS  
        Coming soon!
    .DESCRIPTION  
        Coming soon!
    .NOTES  
        Author     : Todd Lehmann, Bohdan Velushchak
        Requires   : PowerShell v2, MyVips
    .EXAMPLE  
        Coming soon!
        Description
        -----------
        Coming soon!
    .EXAMPLE  
        Coming soon!
        Description
        -----------
        Coming soon!
    .INPUTS
        None 
    .OUTPUTS
        None
    .PARAMETER VIP
        VIP address to register
    .PARAMETER OwnerGroup
        Alias of owner group
    .PARAMETER NotificationAlias
        Email notification alias of owner group
    .PARAMETER BusinessGroup
        Name of owning business group
    .PARAMETER VipDescription
        Description of the VIP
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]
       
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $false,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Undefined HelpMessage Attribute"
        )]
        [String]        
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP
        
        #REGION $OwnerGroup
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Undefined HelpMessage Attribute"
        )]
        [String]        
        [ValidateNotNullOrEmpty()]
        $OwnerGroup
        # Parameter Definition - End
        #ENDREGION $OwnerGroup
        
        #REGION $NotificationAlias
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 2,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Undefined HelpMessage Attribute"
        )]
        [String]        
        [ValidateNotNullOrEmpty()]
        $NotificationAlias
        # Parameter Definition - End
        #ENDREGION $NotificationAlias
        
        #REGION $BusinessGroup
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Undefined HelpMessage Attribute"
        )]
        [String]        
        [ValidateNotNullOrEmpty()]
        $BusinessGroup
        # Parameter Definition - End
        #ENDREGION $BusinessGroup
        
        #REGION $VipDescription
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Undefined HelpMessage Attribute"
        )]
        [String]        
        [ValidateNotNullOrEmpty()]
        $VipDescription
        # Parameter Definition - End
        #ENDREGION $VipDescription

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Register-ITNewVip]: Entering PROCESS ... ")
        
        # Check for existing connection, create one if none exists
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }
        
        Write-Host
        Write-Host ('Coming soon! Check back later!')
        Write-Host
        
        Write-DbgConsole ("Location: [Register-ITNewVip]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}
#ENDREGION PublicFunctions

#REGION PrivateFunctions
################################################################################
#
# Add additional information to debug ouput, such as script name and line number
#
################################################################################
function Write-DbgConsole
{
    <#
    .SYNOPSIS
    Adds additional information to debug output such as date/time, script name and line number
    .DESCRIPTION
    Adds additional information to debug output such as date/time, script name and line number
    .NOTES
    Author     : Todd Lehmann (toddle)
    Requires   : PowerShell V2
    .PARAMETER Message
    Text to be shown on screen
    .PARAMETER ShowPath
    Shows the absolute path to the script or just the script name.
    .INPUTS
    [System.String]
        Text to be displayed in console
    .EXAMPLE
    Write-DbgConsole ("This is a test debug message"
    Description
    -----------
    Displays the date/time, script name, line number and the message "this is a text message")
    
    Note: $DebugPreference needs to be set to "Continue" in order for debug output to be visible
    #>
    
    param
    (
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $true,
            ValueFromPipelineByPropertyName = $true # Don't forget to use BEGIN|PROCESS|END when set to true!
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $Message
        ,
        [Switch]$ShowPath
    )
    
    if ($ShowPath.IsPresent)
    {
        Write-DbgConsole ("[ " + (Get-Date -Format "MM/dd HH:mm:ss") + " ] [ " + $MyInvocation.ScriptName + " ! " + $MyInvocation.ScriptLineNumber + " ]`n   :\> " + $Message)
    }
    else
    {
        $ScriptFilename = ($MyInvocation.ScriptName.Substring($MyInvocation.ScriptName.LastIndexOf("\") + 1))
        Write-Debug ("[ " + (Get-Date -Format "MM/dd HH:mm:ss") + " ] [ " + $ScriptFilename + " ! " + $MyInvocation.ScriptLineNumber + " ]`n   :\> " + $Message)
    }
    Write-Debug "`n"
}

################################################################################
#
# Returns one or more [System.Net.IPAddress] objects for a given DNS hostname,
# or $null if name lookup fails
#
################################################################################
function Resolve-IPAddress 
{
    <#  
    .SYNOPSIS  
        A summary of what this script does  
        In this case, this script documents the auto-help text in PowerShell. 
        Appears in all basic, -detailed, -full, -examples  
    .DESCRIPTION  
        A more in depth description of the script.
        Should give script developer more things to talk about  
        Hopefully this can help the community too
        Becomes: "DETAILED DESCRIPTION"
        Appears in basic, -full and -detailed
    .NOTES  
        Additional Notes, eg  
        File Name  : get-autohelp.ps1  
        Author     : Thomas Lee - tfl@psp.co.uk  
        Requires   : PowerShell V2 CTP3  
        Appears in -full
    .LINK  
        A hyper link, 
        eg http://www.pshscripts.blogspot.com/2008/12/get-autohelpps1.html  
        Becomes: "RELATED LINKS"   
        Appears in basic and -Full  
    .EXAMPLE  
        The first example - just text documentation
        You should provide a way of calling the script and any expected output, eg: 
            C:\foo> .\get-autohelp.ps1 42 
            The meaning of life is 42 
            Appears in -detailed and -full 
        [Command] [Parameters]
        Description
        -----------
        [Description]
    .EXAMPLE  
        The second example - more text documentation  
        This would be an example calling the script differently. You have lots and 
        lots, and lots of examples if this is useful.  
        Appears in -detailed and -full  
    .INPUTS
        From the pipeline
        Documentary text, eg:  
        Input type  [Universal.SolarSystem.Planetary.CommonSense]  
        Appears in -full  
    .OUTPUTS
        Into the pipline
        Documentary Text, e,g:  
        Output type  [Universal.SolarSystem.Planetary.Wisdom]  
        Appears in -full  
    .PARAMETER foo  
        The .Parameter area in the script is used to derive the of the PARAMETERS in
        Get-Help output which documents the parameters in the param block. The 
        section takes a value (in this case foo,  the name of the first actual 
        parameter), and only appears if there is parameter of that name in the param 
        block. Having a section for a parameter that does not exist generate no 
        extra output of this section    
        Appears in -detailed, -full (with more info than in -det) 
        Appears in -Parameter (need to specify the parameter name)  
    .PARAMETER bar  
        Example of a parameter definition for a parameter that does not exist.  
        Does not appear at all.  
    #>

    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]
        
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $Hostname
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false,
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "DNS hostname to retrieve the IP addresses of"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $Hostname
        # Parameter Definition - End
        #ENDREGION $Hostname
                
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [FunctionName]: Entering PROCESS ... ")
        
        trap [Exception]
        {
            return $null
        }
        
        $AllAddresses = [System.Net.Dns]::GetHostAddresses($HostName)
        
        Write-DbgConsole ("Location: [FunctionName]: Exiting PROCESS ... ")
    }
    END
    {
        Write-DbgConsole ("Location: [FunctionName]: Exiting END ... ")
        
        return $AllAddresses
        
        Write-DbgConsole ("Location: [FunctionName]: Exiting End ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Verifies a VIP is in proper format; ensures it is a valid IP address and
#    attempts to resolve name to IP, if necessary
#
################################################################################
function Resolve-ITVipIP
{
    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "High"
        )]
        
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General

        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to retrieve status for"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP

#        #REGION ParameterName
#        # Parameter Definition - Start
#        , # Comma needed to separate multiple parameter definitions
#        [Parameter(
#            Mandatory = $false,
#            #Position = 0,
#            ValueFromPipeline = $false, 
#            ValueFromPipelineByPropertyName = $false, 
#            ParameterSetName = "DefaultSet",
#            HelpMessage = "Undefined HelpMessage Attribute"
#        )]
#        #[alias("AliasName")]
#        [Object]
#        #[ValidateCount(1,5)] # min and max number of arguments
#        #[ValidateLength(min,max)]
#        #[ValidatePattern('RegExPattern')]
#        #[ValidateRange(0,10)]
#        #[ValidateScript({)]
#        #[ValidateSet("Steve", "Mary", "Carl")]
#        #[ValidateNotNull()]
#        #[ValidateNotNullOrEmpty()]
#        $ParameterName
#        # Parameter Definition - End
#        #ENDREGION ParameterName

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Resolve-ITVipIP]: Entering PROCESS ... ")
        
        # Some reg ex to check for valid MSFT DNS or valid NETBios hostname
        $MSFQDNRegEx = "(?=^.{1,254}$)(^(?:(?!\d+\.|-)[a-zA-Z0-9_\-]{1,63}(?<!-)\.?)+(?:[a-zA-Z]{2,})$)"
        $StringRegEx = "^^[a-zA-Z]+$"
        
        # Check to see if an IPAddress was passed. Our F5s don't support IPv6 yet, so 
        # exit if it's IPv6.  If it wasn't an IPAddress, then try to resolve to an IP if 
        # its a valid DNS or NetBios name
        #
        # It's assuming that DNS round robin is not used, so only one IP will be returned
        Try
        {
            Write-DbgConsole ('Attempting to create .NET IPAddress object')
            $IP = [System.Net.IPAddress]::Parse($VIP)
                        
            if ($Ip.AddressFamily -eq "InterNetworkV6")
            {
                Write-DbgConsole ('IPv6 not supported today, so exiting')
                throw("IPv6 not supported.  Please see Get-Help for more information.")
            }
        }
        catch [FormatException]
        {
            Write-DbgConsole ('Not a valid IP address, attempting to resolve to IP')
            if ($VIP -match $MSFQDNRegEx)
            {
                Write-DbgConsole ('MSFT FQDN detected, resolving ... ')
                $VIP = Resolve-IPAddress -Hostname $VIP
            }
            elseif ($VIP -match $StringRegEx)
            {
                Write-DbgConsole ('NETBios hostname detected, resolving ... ')
                $VIP = Resolve-IPAddress -Hostname $VIP
            }
            else
            {
                Write-DbgConsole ('No idea what this thing is, existing ... ')
                throw ("-VIP parameter not recognized. Please see Get-Help for more information")
            }
        }
        
        Write-DbgConsole ('Returning IP address ' + $VIP)
        return $VIP
        Write-DbgConsole ("Location: [Resolve-ITVipIP]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function Parse-SoapException 
{
    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]

        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $Message
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Message attribute on exception"
        )]
        [String]
        $Message
        # Parameter Definition - End
        #ENDREGION $Message
        
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Parse-SoapException]: Entering PROCESS ... ")
        
        # Exception object to be returned
        $ParsedMessage = New-Object PSObject
        # The error message itself, ex NO_VIP_REGISTERED, VIP_NOT_FOUND, etc
        $ParsedMessage | Add-Member -MemberType NoteProperty -Name Message -Value $null
        # The argument passed, such as the IP address that was queried
        $ParsedMessage | Add-Member -MemberType NoteProperty -Name Argument -Value $null
        # If an unrecognized or unparsable message is found, Message will contain the 
        #   MyVips error and Argument will contain the PowerShell specific error

        try
        {
            # Parse: System.ArgumentException
            # Ex: System.Web.Services.Protocols.SoapException: NO_VIP_REGISTERED ---> System.ArgumentException: 12.25.13.46
            #       --- End of inner exception stack trace ---
            #       at MyVipsEngine.IdentityManager.CheckAuthorizationForVip(String strVip, String username) in c:\dev\Projects\iControl\MyVipsEngine\MyVipsEngine\IdentityManager.cs:line 457
            #       at MyVipsEngine.IdentityManager.CheckAuthZ(String strVip, String username) in c:\dev\Projects\iControl\MyVipsEngine\MyVipsEngine\IdentityManager.cs:line 383
            #       at MyVipsEngine.UserHLBMgmtSvc.GetVIPStatus(String AuthToken, String strVip) in c:\dev\Projects\iControl\MyVipsEngine\MyVipsEngine\UserHLBMgmtSvc.asmx.cs:line 908
            if ($Message.Contains('--->'))
            {
                # Get the NO_VIP_REGISTERED from the string
                $FirstColon = ($Message.IndexOf(':',0) + 1)
                $FirstArrow = $Message.IndexOf('--->',0)
                $ErrorLength = $FirstArrow - $FirstColon
                # Place the string in the error object
                $ParsedMessage.Message = ($Message.SubString($FirstColon,$ErrorLength)).Trim()
                
                # Get the argument, in this case 12.25.13.46
                $SecondColon = ($Message.IndexOf(':',$FirstColon) + 1)
                $FirstDash = ($Message.IndexOf('--- ',0) + 1)
                $ArgumentLength = ($FirstDash - $SecondColon) - 1
                # Place the string in the error object
                $ParsedMessage.Argument = $Message.Substring($SecondColon,$ArgumentLength).Trim()
            }

            # Parse: VIP_NOT_FOUND error
            # Ex: System.Web.Services.Protocols.SoapException: VIP_NOT_FOUND[VIP~10.248.18.11]
            #       at MyVipsEngine.UserHLBMgmtSvc.GetVIPStatus(String AuthToken, String strVip) in c:\dev\Projects\iControl\MyVipsEngine\MyVipsEngine\UserHLBMgmtSvc.asmx.cs:line 939
            elseif ($Message.Contains('VIP_NOT_FOUND'))
            {
                # Get the full error VIP_NOT_FOUND[VIP~10.248.18.11]
                $FirstColon = ($Message.IndexOf(':',0) + 1)
                $At = $Message.IndexOf('at',0)
                $ErrorLength = $At - $FirstColon
                $FullError = $Message.SubString($FirstColon,$ErrorLength)
                
                # Remove the extraneous VIP~
                $FullError = $FullError.Replace('VIP~','')
                # Populate the properties of the error object
                $ParsedMessage.Message = $FullError.Split('[')[0].Trim()
                $ParsedMessage.Argument = $FullError.Split('[')[1].Replace(']','').Trim()
            }
        }
        catch [Exception]
        {
            $ParsedMessage.Message = $Message
            $ParsedMessage.Argument = $_
        }
        
        Write-DbgConsole ("Location: [Parse-SoapException]: Exiting PROCESS ... ")
        return $ParsedMessage
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function Write-SoapException 
{
    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]
        
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $ErrorObject
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Custom error message object"
        )]
        [PSObject]
        [ValidateNotNullOrEmpty()]
        $ErrorObject
        # Parameter Definition - End
        #ENDREGION $ErrorObject
        
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Write-SoapException]: Entering PROCESS ... ")
        
        $TimeStamp = ((Get-Date).ToString('MM/dd HH:mm:ss.ff') + ': ')
        
        Write-Host
        switch($ErrorObject.Message)
        {
            'NO_VIP_REGISTERED'
            {
                Write-Host ($TimeStamp + 'There is no VIP registered for IP ' + $ErrorObject.Argument)
                break
            }
            'VIP_ISLOCKED'
            {
                Write-Host ($TimeStamp + 'The VIP is currently locked for modification. Please try again later')
                break
            }
            'INTERNAL_ERROR'
            {
                Write-Host ($TimeStamp + 'An unknown internal error in MyVips has occurred. Please contact a MyVips administrator for more information. Please include the time of the error, which was at ' + $TimeStamp)
                break
            }
            'ACCESS_DENIED'
            {
                Write-Host ($TimeStamp + 'User ' + $ErrorObject.Argument + ' does not have access to the VIP specified')
                break
            }
            'ACCESS_DENIED\MYVIPS_DOWN'
            {
                Write-Host ($TimeStamp + 'MyVips is down for administrative reasons. Plese try again later')
                break
            }
            'VIP_RESTRICTED_OPERATION'
            {
                Write-Host ($TimeStamp + 'Add/Remove Node operations are not allowed for this VIP')
                break
            }
            'VIP_NOT_FOUND'
            {
                Write-Host ($TimeStamp + 'Status for VIP ' + $ErrorObject.Argument + ' is not currently available on MyVips') -err
                Write-Host
                Write-Host ('This can occur when the load balancing device hosting the VIP is unresponsive or the VIP has been removed from the load balancing device outside of the MyVips tool')
                break
            }
            'WRONG_USERDATA'
            {
                Write-Host ($TimeStamp + 'Notification alias ' + $ErrorObject.Argument + ' is either invalid or not a group alias')
                break
            }
            'NODE_EXISTS'
            {
                Write-Host ($TimeStamp + 'Node ' + $ErrorObject.Argument + ' already exists in the requested VIP')
                break
            }
            'NODE_NOT_FOUND'
            {
                Write-Host ($TimeStamp + 'Node ' + $ErrorObject.Argument + ' does not exist in the requested VIP')
                break
            }
            'SENDMAIL_FAILED'
            {
                if ($ErrorObject.Argument -match 'An existing connection was forcibly closed by the remote host')
                {
                    Write-Host ($TimeStamp + 'Failure attempting to send mail status update. There was an error connecting to the mail server')
                }
                else
                {
                    Write-Host ($TimeStamp + 'An unknown error occurred attempting to send mail status update. The error text supplied was:')
                    Write-Host
                    Write-Host ($ErrorObject.Argument)
                }
                break
            }
            default
            {
                Write-Host -ForegroundColor Red ($TimeStamp + 'An unhandled error has occurred')
                Write-Host
                Write-Host ('Calling line number: ' + $MyInvocation.ScriptLineNumber)
                Write-Host
                Write-Host -ForegroundColor Yellow ('Error from MyVips:')
                Write-Host $ErrorObject.Message
                Write-Host
                Write-Host -ForegroundColor Gray ('Processing Exception:')
                Write-Host -ForegroundColor Gray $ErrorObject.Argument
                break
              }
        }
        
        
        Write-Host
        Write-DbgConsole ("Location: [Write-SoapException]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Writes a header for VIP status to console
#
################################################################################
function Write-pvtItStatusHeader 
{
    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]

        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $VipObject
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $false,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false
        )]
        [Object]
        [ValidateNotNullOrEmpty()]
        $VipObject
        # Parameter Definition - End
        #ENDREGION $VipObject

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Write-pvtItStatusHeader]: Entering PROCESS ... ")
        
        Write-Host
        Write-Host ("-" * ($Host.UI.RawUI.WindowSize.Width -1)) -ForegroundColor DarkGray -BackgroundColor Black
        Write-Host
        
        Write-Host ("`tIP Address:`t`t" + $VipObject.IPAddress) 
        
        Write-Host ("`tState:`t") -NoNewline
        
        if ($VipObject.State -eq "Disabled")
        {
            Write-Host ($VipObject.State.PadRight(8)) -ForegroundColor Gray -NoNewline
        }
        elseif ($VipObject.State -eq "Enabled")
        {
            Write-Host ($VipObject.State.PadRight(8)) -NoNewline -ForegroundColor Green
        }
        else
        {
            Write-Host ($VipObject.State) -ForegroundColor Yellow -NoNewline
        }
        
        Write-Host ("`tAvailability:`t") -NoNewline
        
        if ($VipObject.AllAvailable -eq $true)
        {
            Write-Host ($VipObject.AvailabilityPercent) -ForegroundColor Green -NoNewline
        }
        elseif ($VipObject.HealthCritical -eq $true)
        {
            Write-Host ($VipObject.AvailabilityPercent) -ForegroundColor Red -BackgroundColor Yellow -NoNewline
        }   
        elseif ($VipObject.AllAvailable -eq $false)
        {
            Write-Host ($VipObject.AvailabilityPercent) -ForegroundColor Yellow -NoNewline
        }
        
        Write-Host ('%')
        
        Write-Host ("`tLast Operation:`t`t" + $VipObject.LastOperation)
        Write-Host ("`tModified By:`t`t" + $VipObject.LastModifiedBy)
        Write-Host ("`tModified On:`t`t" + $VipObject.LastModifiedDate)
    
        Write-Host
        Write-Host ("-" * ($Host.UI.RawUI.WindowSize.Width -1)) -ForegroundColor DarkGray -BackgroundColor Black
        Write-Host

        Write-DbgConsole ("Location: [Write-pvtItStatusHeader]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function Write-pvtItStatusBody
{
    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]
        
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $VipObject
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $false,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false
        )]
        [Object]
        [ValidateNotNullOrEmpty()]
        $VipObject
        # Parameter Definition - End
        #ENDREGION $VipObject
        
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [FunctionName]: Entering PROCESS ... ")
        
        $StatusObject = @()
            
        # Adds nodes to the status object for output to console        
        foreach ($Node in $VipObject.Nodes)
        {
            $StatusObject += @(New-pvtITInitStatusItem -Node $Node)
        }
        
        # Status Table
        $StatusObject | Sort Enabled -Descending | Format-Table | Out-Host
        
        Write-DbgConsole ("Location: [FunctionName]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function New-pvtITVipObject 
{
    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [New-pvtITVipObject]: Entering PROCESS ... ")
        
        $VipObject = New-Object PSObject
        $VipObject | Add-Member -MemberType NoteProperty -Name IPAddress -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name UserNote -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name Ports -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name Nodes -Value @()
        $VipObject | Add-Member -MemberType NoteProperty -Name State -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name Current -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name Total -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name RX -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name TX -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name LBMethod -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name AllAvailable -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name AvailabilityPercent -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name HealthCritical -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name LastModifiedBy -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name LastModifiedDate -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name LastOperation -Value $null
        $VipObject | Add-Member -MemberType NoteProperty -Name AddRemoveDisabled -Value $null

        return $VipObject

        Write-DbgConsole ("Location: [New-pvtITVipObject]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function New-pvtITNodeArray
{
    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]
                
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $VipObject
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            HelpMessage = "Node object"
        )]
        [PSObject]
        [ValidateNotNullOrEmpty()]
        $VipObject
        # Parameter Definition - End
        #ENDREGION $VipObject
     
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [function New-pvtITNodeItem ]: Entering PROCESS ... ")
        
        $AllNodes = @()
        foreach ($NodeObject in $VipObject.Nodes)
        {
            $NodeItem = New-Object PSObject
            $NodeItem | Add-Member -MemberType NoteProperty -Name PoolIP -Value $null
            $NodeItem | Add-Member -MemberType NoteProperty -Name NodeIP -Value $null
            $NodeItem | Add-Member -MemberType NoteProperty -Name UserNote -Value $null
            $NodeItem | Add-Member -MemberType NoteProperty -Name Enabled -Value $null
            $NodeItem | Add-Member -MemberType NoteProperty -Name AllAvailable -Value $null
            $NodeItem | Add-Member -MemberType NoteProperty -Name AvailabilityPercent -Value $null
            $NodeItem | Add-Member -MemberType NoteProperty -Name EnabledPorts -Value $null
            $NodeItem | Add-Member -MemberType NoteProperty -Name DisabledPorts -Value $null
            $NodeItem | Add-Member -MemberType NoteProperty -Name CurrentConnections -Value $null
            $NodeItem | Add-Member -MemberType NoteProperty -Name BytesReceived -Value $null
            $NodeItem | Add-Member -MemberType NoteProperty -Name BytesSent -Value $null
        
            $NodeItem.PoolIP = $VipObject.IPAddress
            $NodeItem.NodeIP = $NodeObject.IPAddress
            $NodeItem.UserNote = $NodeObject.UserNote
            $NodeItem.Enabled = $NodeObject.Enabled
            $NodeItem.EnabledPorts = @($NodeObject.Ports | Where {$_.Enabled -eq $true} | Foreach {$_.Port})
            $NodeItem.DisabledPorts = @($NodeObject.Ports | Where {$_.Enabled -eq $false} | Foreach {$_.Port})
            $NodeItem.CurrentConnections = ($NodeObject.Ports | Measure-Object -Sum -Property Current).Sum
            $NodeItem.BytesReceived = ($NodeObject.Ports | Measure-Object -Sum -Property RX).Sum
            $NodeItem.BytesSent = ($NodeObject.Ports | Measure-Object -Sum -Property TX).Sum
            $NodeItem.AllAvailable = $NodeObject.AllAvailable
            $NodeItem.AvailabilityPercent = $NodeObject.AvailabilityPercent
            $AllNodes += @($NodeItem)
        }
        Write-DbgConsole ("Location: [function New-pvtITNodeItem ]: Exiting PROCESS ... ")
        return $AllNodes
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function New-pvtITInitVipObject 
{
    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low",
            DefaultParametersetName = "VIP"
        )]
        
        #REGION ParamaeterSet:VIP
        
        #REGION $VIP
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            ParameterSetName = "VIP",
            HelpMessage = "VIP to retrieve status for"
        )]
        [PSObject]
        [ValidateNotNullOrEmpty()]
        $VIP
        # Parameter Definition - End
        #ENDREGION $VIP
        
        #REGION ParamaeterSet:VIP

        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:VipObject

        #REGION $VipStatus
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false,
            ParameterSetName = "VipStatus",
            HelpMessage = "Already instantiated VIP object"
        )]
        [PSObject]
        [ValidateNotNullOrEmpty()]
        $VipStatus
        # Parameter Definition - End
        #ENDREGION $VipStatus

        #ENDREGION ParamaeterSet:VipObject
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [New-pvtITInitVipObject]: Entering PROCESS ... ")
        
        # Check connection state and create if required
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
            $MyVipsWebProxy = $MyVipsWebProxy;
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }
        
        switch ($PsCmdlet.ParameterSetName)
        {             
            "VIP" 
            { 
                # Resolve VIP
                Write-DbgConsole ('Resolving VIP')
                $VIP = Resolve-ITVipIP -VIP $VIP

                # Get the vip status
                try
                {
                    $VipStatus = $MyVipsWebProxy.GetVIPStatus($null,$VIP)
                }
                catch [System.Web.Services.Protocols.SoapException]
                {
                    $PsCmdlet.ThrowTerminatingError($_)
                    $SoapError = Parse-SoapException -Message $_.Exception.Message
                    
                    Write-SoapException -ErrorObject $SoapError
                    break
                    
                }
                catch [Exception]
                {         
                    Write-Host
                    Write-Error ('An unexpected error has occurred')
                    Write-Host
                    Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
                    Write-Host
                    Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
                    Write-Host
                    Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
                    Write-Host
                    Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
                    Write-Host
                    Write-Host ('Message:' + $_.Exception.Message)
                    Write-Host
                    break
                }
                break
            }
            'VipStatus'
            {
                # do nothing
                break
            }
            default 
            {
                # This should never execute unless there is a problem in the way the parameter sets are configured. 
                # Look for a problem upstream as opposed changing anything here
                Write-Host
                Write-Host ((Get-Date).ToString() + ": Something is broken in with parameter sets in this function!")
                Write-DbgConsole ((Get-Date).ToString() + ": Something is broken in with parameter sets in this function!")
                Write-Host
                Exit
            }
        }
        
        # Get blank VIP object
        Write-DbgConsole ('Getting blank VIP object')
        $VipObject = New-pvtITVipObject
        
        # And then populate the blank object with actual values        
        $VipObject.IPAddress = $VipStatus.VIP
        $VipObject.UserNote = $VipStatus.UserNote
        $VipObject.Ports = $VipStatus.Ports -join ","
        
        if ($VipStatus.State.EnabledState -eq $true)
        {
            $VipObject.State = "Enabled"
        }
        else
        {
            $VipObject.State = "Disabled"
        }
        
        $VipObject.LBMethod = $VipStatus.State.LBMethod
        $VipObject.Current = $VipStatus.Statistics.connections_current
        $VipObject.Total = $VipStatus.Statistics.connections_total 
        $VipObject.RX = $VipStatus.Statistics.bytes_in
        $VipObject.TX = $VipStatus.Statistics.bytes_out
        $VipObject.AddRemoveDisabled = $VipStatus.AddRemoveDisabled
        $VipObject.LastModifiedBy = $VipStatus.LastModifiedBy
        $VipObject.LastModifiedDate = $VipStatus.LastModifiedDate
        $VipObject.LastOperation = $VipStatus.LastOperation
        
        foreach ($Node in $VipStatus.Nodes)
        {
            $DipStatus = New-pvtITNodeObject
            
            $DipStatus.IPAddress = $Node.dip
            $DipStatus.CachedOn = $Node.CachedOn
            $DipStatus.UserNote = $Node.UserNote
            #$DipStatus.Ports = $Node.Ports -join ","
            
            foreach ($Port in $Node.NodePortStatus)
            {
                $PortStatus = New-pvtITPortObject

                $PortStatus.Port = $Port.port
                if ($Port.EnabledState -eq $true)
                {
                    $PortStatus.Enabled = $true
                    if (!$DipStatus.EnabledPorts)
                    {
                        $DipStatus.EnabledPorts += $Port.Port.ToString()
                    }
                    else
                    {
                        $DipStatus.EnabledPorts += (";" + $Port.Port.ToString())
                    }
                    $DipStatus.Enabled = $true
                }
                else
                {
                    if ($PortStatus.Enabled -eq $null)
                    {
                        $PortStatus.Enabled = $false
                        $DipStatus.Enabled = $false
                    }
                }
                
                $PortStatus.Status = $Port.AvailStatus
                
                $PortStatus.Current = $Port.Statistics.connections_current
                $PortStatus.Max  = $Port.Statistics.connections_max
                $PortStatus.Total = $Port.Statistics.connections_total 
                $PortStatus.RX = $Port.Statistics.bytes_in
                $PortStatus.TX = $Port.Statistics.bytes_out
                
                $DipStatus.Ports += $PortStatus
            }
            
            $VipObject.Nodes += $DipStatus
        }
        
        Write-DbgConsole ('Populating availability info ... ')
        $VipObject = Evaluate-ITVipHealth -VipObject $VipObject
        
        Write-DbgConsole ('Completed populating object, returning to caller')
        
        return $VipObject
        
        Write-DbgConsole ("Location: [New-pvtITInitVipObject]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function New-pvtITNodeObject 
{
    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [New-pvtITNodeObject]: Entering PROCESS ... ")
        
        $DipObject = New-Object PSObject
        $DipObject | Add-Member -MemberType NoteProperty -Name IPAddress -Value $null
        $DipObject | Add-Member -MemberType NoteProperty -Name Enabled -Value $null
        $DipObject | Add-Member -MemberType NoteProperty -Name Ports -Value @()
        $DipObject | Add-Member -MemberType NoteProperty -Name EnabledPorts -Value $null
        $DipObject | Add-Member -MemberType NoteProperty -Name CachedOn -Value $null
        $DipObject | Add-Member -MemberType NoteProperty -Name UserNote -Value $null
        $DipObject | Add-Member -MemberType NoteProperty -Name AllAvailable -Value $null
        $DipObject | Add-Member -MemberType NoteProperty -Name AvailabilityPercent -Value $null
        
        return $DipObject
        Write-DbgConsole ("Location: [New-pvtITNodeObject]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function New-pvtITPortObject 
{
    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [New-pvtITPortObject]: Entering PROCESS ... ")
        
        $PortObject = New-Object PSObject
        $PortObject | Add-Member -MemberType NoteProperty -Name Port -Value $null
        $PortObject | Add-Member -MemberType NoteProperty -Name Enabled -Value $null
        $PortObject | Add-Member -MemberType NoteProperty -Name Status -Value $null
        $PortObject | Add-Member -MemberType NoteProperty -Name Current -Value $null
        $PortObject | Add-Member -MemberType NoteProperty -Name Max -Value $null
        $PortObject | Add-Member -MemberType NoteProperty -Name Total -Value $null
        $PortObject | Add-Member -MemberType NoteProperty -Name RX -Value $null
        $PortObject | Add-Member -MemberType NoteProperty -Name TX -Value $null
        $PortObject | Add-Member -MemberType NoteProperty -Name AllAvailable -Value $null
        
        return $PortObject
        
        Write-DbgConsole ("Location: [New-pvtITPortObject]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Creates status line item
#
################################################################################
function New-pvtITInitStatusItem
{
    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]

        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General

        #REGION $Node
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to retrieve status for"
        )]
        [PSObject]
        [ValidateNotNullOrEmpty()]
        $Node
        # Parameter Definition - End
        #ENDREGION $Node

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMan
    PROCESS 
    {
        Write-DbgConsole ("Location: [New-pvtITInitStatusItem]: Entering PROCESS ... ")
        
        $StatusItem = New-Object PSObject
        $StatusItem | Add-Member -MemberType NoteProperty -Name Node -Value $null
        $StatusItem | Add-Member -MemberType NoteProperty -Name Enabled -Value $null
        $StatusItem | Add-Member -MemberType NoteProperty -Name EnabledPorts -Value $null
        $StatusItem | Add-Member -MemberType NoteProperty -Name DisabledPorts -Value $null
        $StatusItem | Add-Member -MemberType NoteProperty -Name AvailabilityPercent -Value $null
        
        # Set Node information
        if ($Node.Enabled -eq $false)
        {
            $StatusItem.Node = ('DSBL ' + $Node.IPAddress)
        }
        elseif ($Node.AllAvailable -eq $true)
        {
            $StatusItem.Node = ('ENBL ' + $Node.IPAddress)
        }
        elseif ($Node.AllAvailable -eq $false)
        {
            $StatusItem.Node = ('WRN! ' + $Node.IPAddress)
        }
        
        $StatusItem.Enabled = $Node.Enabled
        $StatusItem.AvailabilityPercent = $Node.AvailabilityPercent
        
        # Gather the enabled and disabled ports, and their availability for the EnabledPorts and 
        # DisabledPorts fields
        
        foreach ($Port in $Node.Ports)
        {
            if ($Port.Enabled -eq $true)
            {
                if ($Port.AllAvailable -eq $true)
                {
                    $StatusItem.EnabledPorts += @($Port.Port.ToString() + ':ENBL')
                }
                elseif ($Port.AllAvailable -eq $false)
                {
                    $StatusItem.EnabledPorts += @($Port.Port.ToString() + ':WRN!')
                }
                else
                {
                    $StatusItem.EnabledPorts += @($Port.Port.ToString() + ':UNKN')
                }
            }
            elseif ($Port.Enabled -eq $false)
            {
                if ($Port.AllAvailable -eq $true)
                {
                    $StatusItem.DisabledPorts = @($Port.Port.ToString() + ':DSBL')
                }
                elseif ($Port.AllAvailable -eq $false)
                {
                    $StatusItem.DisabledPorts = @($Port.Port.ToString() + ':WRN!')
                }
                else
                {
                    $StatusItem.DisabledPorts = @($Port.Port.ToString() + ':UNKN')
                }
            }
        }
        
        Write-DbgConsole ("Location: [New-pvtITInitStatusItem]: Exiting PROCESS ... ")
        return $StatusItem
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Creates empty MyVips object
#
################################################################################
function New-pvtMyVipsObject
{
    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]

        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General

        #REGION $StatusItem
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 1,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP to retrieve status for"
        )]
        [PSObject]
        [ValidateNotNullOrEmpty()]
        $StatusItem
        # Parameter Definition - End
        #ENDREGION $StatusItem

        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMan
    PROCESS 
    {
        Write-DbgConsole ("Location: [New-pvtMyVipsObject]: Entering PROCESS ... ")
        
        $MyVipsObject = New-Object PSObject
        $MyVipsObject | Add-Member -MemberType NoteProperty -Name IP -Value $null
        $MyVipsObject | Add-Member -MemberType NoteProperty -Name UserNote -Value $null
        $MyVipsObject | Add-Member -MemberType NoteProperty -Name MailAlias -Value $null
        $MyVipsObject | Add-Member -MemberType NoteProperty -Name OwnerGroup -Value $null
        $MyVipsObject | Add-Member -MemberType NoteProperty -Name Availability -Value $null
        
        $VipObject = New-pvtITInitVipObject -VIP $StatusItem.IP
        
        $MyVipsObject.IP = $VipObject.IPAddress
        $MyVipsObject.UserNote = $StatusItem.UserNote
        $MyVipsObject.MailAlias = $StatusItem.MailAlias
        $MyVipsObject.OwnerGroup = $StatusItem.OwnerGroupAlias
        $MyVipsObject.Availability = $VipObject.AvailabilityPercent
        
        Write-DbgConsole ("Location: [New-pvtMyVipsObject]: Exiting PROCESS ... ")
        return $MyVipsObject
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Add's Availability information to the VipObject
#
################################################################################
function Evaluate-ITVipHealth 
{
    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]
        
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $VipObject
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "VIP object"
        )]
        [PSObject]
        $VipObject
        # Parameter Definition - End
        #ENDREGION $VipObject
        
#        #REGION ParameterName
#        # Parameter Definition - Start
#        #, # Comma needed to separate multiple parameter definitions
#        [Parameter(
#            Mandatory = $false,
#            #Position = 0,
#            ValueFromPipeline = $false, 
#            ValueFromPipelineByPropertyName = $false, 
#            ParameterSetName = "DefaultSet",
#            HelpMessage = "Undefined HelpMessage Attribute"
#        )]
#        #[alias("AliasName")]
#        [Object]
#        #[ValidateCount(1,5)] # min and max number of arguments
#        #[ValidateLength(min,max)]
#        #[ValidatePattern('RegExPattern')]
#        #[ValidateRange(0,10)]
#        #[ValidateScript({)]
#        #[ValidateSet("Steve", "Mary", "Carl")]
#        #[ValidateNotNull()]
#        #[ValidateNotNullOrEmpty()]
#        $ParameterName
#        # Parameter Definition - End
#        #ENDREGION ParameterName
        
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Evaluate-ITVipHealth]: Entering PROCESS ... ")
        
        foreach ($Node in $VipObject.Nodes)
        {
            # Discover whether port is AllAvailable, and flag port appropriately
            foreach ($Port in $Node.Ports)
            {
                # If the port is enabled and status is Green, it is AllAvailable. All other conditions
                # mean the port is unhealthy
                if (($Port.Enabled -eq $true) -and ($Port.Status -eq "GREEN"))
                {
                    $Port.AllAvailable = $true
                }
                else
                {
                    $Port.AllAvailable = $false
                }
            }

            # Discover whether node is AllAvailable.  If any ports are unhealthy, node is unhealthy
            $IsUnhealthy = @($Node.Ports | Where {($_.AllAvailable -eq $false) -and ($_.Enabled -eq $true)})
            if ($IsUnhealthy)
            {
                $Node.AllAvailable = $false
            }
            else
            {
                $Node.AllAvailable = $true
            }

            # Calculate Availability percentage of node, which is just the percentage of ports that are enabled
            if ($Node.AllAvailable -eq $false)
            {
                $NumHealthyPorts = @($Node.Ports | Where {($_.AllAvailable -eq $true) -and ($_.Enabled -eq $true)})
                $NumEnabledPorts = @($Node.Ports | Where {$_.Enabled -eq $true})
                # Avoid divide by zero
                if ($NumEnabledPorts)
                {
                    $Node.AvailabilityPercent = [Math]::Round((($NumHealthyPorts.Count / $NumEnabledPorts.Count) * 100),2,[System.MidpointRounding]::AwayFromZero)
                }
                else
                {
                    $Node.AvailabilityPercent = [Math]::Round((($NumHealthyPorts.Count / $($Node.Ports).Count) * 100),2,[System.MidpointRounding]::AwayFromZero)
                }
                   
            }
            else
            {
                $Node.AvailabilityPercent = 100
            }
        }
        
        # Calculate Availability of VIP
        
        $NumUnhealthyNodes = @($VipObject.Nodes | Where {($_.AllAvailable -eq $false) -and ($_.Enabled -eq $true)})
        if ($NumUnhealthyNodes)
        {
            $NumHealthyNodes = @($VipObject.Nodes | Where {($_.AllAvailable -eq $true) -and ($_.Enabled -eq $true)})
            $NumEnabledNodes = @($VipObject.Nodes | Where {$_.Enabled -eq $true})
            # Avoid divide by zero
            if ($NumEnabledNodes)
            {
                $VipObject.AvailabilityPercent = [Math]::Round((($NumHealthyNodes.Count / @($NumEnabledNodes).Count) * 100),2,[System.MidpointRounding]::AwayFromZero)
            }
            else
            {
                $VipObject.AvailabilityPercent = [Math]::Round((($NumHealthyNodes.Count / @($VipObject.Nodes).Count) * 100),2,[System.MidpointRounding]::AwayFromZero)
            }
            
            # Determine if Availability is critical
            # Less than 2 nodes, then less than 50% is critical Availability
            if (@($VipObject.Nodes).Count -le 2)
            {
                if ($VipObject.AvailabilityPercent -le 50)
                {
                    $VipObject.HealthCritical = $true
                }
                else
                {
                    $VipObject.HealthCritical = $false
                }
            }
            else
            {
                # More than 2 nodes, than less than 60% is critical Availability
                if ($VipObject.AvailabilityPercent -le 60)
                {
                    $VipObject.HealthCritical = $true
                }
                else
                {
                    $VipObject.HealthCritical = $false
                }
            }
            
            # If any nodes are unhealthy, then the VIP is unhealthy
            $VipObject.AllAvailable = $false
        }
        # No unhealthy nodes? Then AllAvailable VIP!
        else
        {
            $VipObject.AllAvailable = $true
            $VipObject.AvailabilityPercent = 100
            $VipObject.HealthCritical = $false
        }

        return $VipObject
        
        Write-DbgConsole ("Location: [Evaluate-ITVipHealth]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function Compare-ModuleVersion
{
    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]
                
        # General (aka 'Setless') Parameters
        #REGION ParamaeterSet:General
        
        #REGION $VersionNumber
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Version number to validate against MyVips web service"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VersionNumber
        # Parameter Definition - End
        #ENDREGION $VersionNumber
        
        #REGION $NotifyAlias
        # Parameter Definition - Start
        ,
        [Parameter(
            Mandatory = $false,
            Position = 3,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Shell version to connect as"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $NotifyAlias
        # Parameter Definition - End
        #ENDREGION $NotifyAlias
        
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    BEGIN
    {
        # Replace the bracketed text with something relevant to you
        Write-DbgConsole ("Location: [Compare-ModuleVersion]: Entering BEGIN ... ")
        
        # Check for active connection
        if ($MyVipsWebProxy) 
        {
            Write-DbgConsole ('Connection exists to service, reusing ... ')
        }
        else 
        {
            # If a connection doesn't exist, just uses current credentials
            # If custom credentials are required, connection should be 
            # create first using New-ITMyVipsConnection. See Get-Help for
            # that command for more information
            Write-DbgConsole ('No connection, creating a new one ... ')
            New-ITMyVipsConnection
        }

        Write-DbgConsole ("Location: [Compare-ModuleVersion]: Exiting BEGIN ... ")
    }    
    PROCESS 
    {
        Write-DbgConsole ("Location: [Compare-ModuleVersion]: Entering PROCESS ... ")

        # Query the web service, return a two-item array
        try
        {
            if ($NotifyAlias)
            {
                $Result = $MyVipsWebProxy.PowerShellCheckModuleVersion($VersionNumber,$Env:COMPUTERNAME.ToUpper(),$NotifyAlias)
            }
            else
            { 
                $Result = $MyVipsWebProxy.PowerShellCheckModuleVersion($VersionNumber,$Env:COMPUTERNAME.ToUpper(),$null)
            }
        }
        catch [System.Web.Services.Protocols.SoapException]
        {
            $SoapError = Parse-SoapException -Message $_.Exception.Message
            
            Write-SoapException -ErrorObject $SoapError
            break
        }
        catch [Exception]
        {         
            Write-Host
            Write-Error ('An unexpected error has occurred')
            Write-Host
            Write-Host ('Script Name: ' + $MyInvocation.ScriptName)
            Write-Host
            Write-Host ('Line Number: ' + $MyInvocation.ScriptLineNumber)
            Write-Host
            Write-Host ('Exception type: ' + $_.Exception.GetType().Fullname)
            Write-Host
            Write-Host ('Inner Exception: ' + $_.Exception.InnerException)
            Write-Host
            Write-Host ('Message:' + $_.Exception.Message)
            Write-Host
            break
        }
        
        # Check to see what the response was.
        # 0 = Latest version
        # 1 = Supported version, but an update is available
        # 2 = Update required to continue
        # If result is 1 or 2, second item in array will be URL to update
        
        if($Result)
        {
            switch($Result[0])
            {
                0 
                {
                    # No update needed, so return $true
                    return $true
                }
                1
                {
                    # Echo to console that an optional update is available, then return $true
                    Write-Host
                    Write-Host -ForegroundColor Yellow ('An optional update for MyVipsShell is available at:')
                    Write-Host ($Result[1])
                    Write-Host
                    return $true
                }
                2
                {
                    # The current version is no longer supported, and must be updated in order to continue
                    # Echo to console then quit script
                    Write-Host
                    Write-Host -ForegroundColor Red ('An update is required in order to continue. Please download the latest version at:')
                    Write-Host ($Result[1])
                    Write-Host
                    return $false
                }
                default
                {
                    # If the response isn't recognized, echo to console and return $false
                    Write-Host
                    Write-Host -ForegroundColor Yellow ('Version check failed due to unrecognized response from MyVips web service.')
                    Write-Host -ForegroundColor Yellow ('Please check the MyVips tool for an updated version of this module')
                    Write-Host
                    return $false
                }
            }
        }
        else
        {
            Write-Host
            Write-Error ('MyVips returned an unrecognized response and cannot continue.')
            Write-Host 
            exit 0
        }
        
        Write-DbgConsole ("Location: [Compare-ModuleVersion]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}

################################################################################
#
# Quick function summary
#
################################################################################
function Write-ModuleVersion 
{
    #REGION Parameters
    param
    (
        [CmdletBinding(
            SupportsShouldProcess=$false,
            ConfirmImpact = "Low"
        )]
        
        #REGION ParamaeterSet:General
        
        #REGION $VersionNumber
        # Parameter Definition - Start
        [Parameter(
            Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $false, 
            ValueFromPipelineByPropertyName = $false, 
            HelpMessage = "Version number to validate against MyVips web service"
        )]
        [String]
        [ValidateNotNullOrEmpty()]
        $VersionNumber
        # Parameter Definition - End
        #ENDREGION $VersionNumber
        
        #ENDREGION ParamaeterSet:General
    )
    #ENDREGION Parameters

    #REGION FunctionMain
    PROCESS 
    {
        Write-DbgConsole ("Location: [Write-ModuleVersion]: Entering PROCESS ... ")
        
        Write-Host
        Write-Host ("`t" + 'MyVips Shell v' + $VersionNumber)
        Write-Host
        
        Write-DbgConsole ("Location: [Write-ModuleVersion]: Exiting PROCESS ... ")
    }
    #ENDREGION FunctionMain
}
#ENDREGION PrivateFunctions

#REGION ModuleExport
Export-ModuleMember New-ITMyVipsConnection,Get-ITMyVips,Get-ITVipStatus,Suspend-ITVip,Resume-ITVip,Suspend-ITVipNode,Resume-ITVipNode,Add-ITVipNode,Remove-ITVipNode,Get-ITVipChangeLog,Get-ITNodeStatus,Resume-ITAllNodePorts,Suspend-ITAllNodePorts,Set-ITUserNote,Remove-ITUserNote
#ENDREGION ModuleExport

#REGION Main
Write-ModuleVersion -Version $MyVipShellVersion
#ENDREGION Main