﻿<#
    TITLE : PasswordMaintenanceToolKit V 1.0
    
    AUTHOR: Nitin Gupta [nitinkg@microsoft.com]

    DESCRIPTION: 
    Build this tool to perform password related maintenance work which includes.
        - Get Service Account Password Expiry details
        - Generate Complex password
        - Set New password to AD Service Account 
        - Update latest password to all repositories.
        - Store Credentials to Azure Key Vault (AKV)
        - Pre/Post Activities Ex. [Put/Remove Server Into Maintenance mode & Take Node OOR from MyVips etc.]
        - Capture Servcie/Application Pool Status into Backend DB for Tracking and fix if not match post activity.
        - SQL Validation Both AG Cluster Environment or Standalone Machine.

    SILENT FEATURE : All new password will be stored and updated on AKV (Azure Key Vault) or Local System based on the selected parameter values.

    How to use these functions is defined inside the individual functions comment section.

    Note : This module require Active Directory and MyVips Module which you can Download or Import, Refer Below URL for more Details: 
    1. https://blogs.technet.microsoft.com/ashleymcglone/2016/02/26/install-the-active-directory-powershell-module-on-windows-10/
    2. http://MyVips

#>

Import-Module ActiveDirectory 
Import-Module C:\PasswordMaintenance1\myVipShell.psm1 #Update with current Path based on your system

Function AzureLogin                      {
    Param($AzureSubAdmin, $sub_name, $ResourceGrp, $VaultName)

    #$ResourceGrp   = 'KeyValut2storeVLPwds' #Default Resource Group for EC
    #$sub_name = 'ECIT Production Monitoring'; #Default EC Subscription for KeyVault
    Write-host -ForegroundColor Cyan "1. Connecting to Azure Key Vault [$($VaultName)]."    

    Try   
    {
        if((Get-AzureRmContext -ErrorAction SilentlyContinue).Tenant -eq $null)
        {
            throw;
        }
    }
    catch
    {
        Login-AzureRmAccount -ErrorAction Stop
        Try
        {
            if((Get-AzureRmContext -ErrorAction SilentlyContinue).Tenant -eq $null)
            {
                throw;
            }
        }
        catch
        {
            Write-Error "Failed to provide Azure Account or unable to retrieve ARM Context. Please try again.";
            return $false;
        }
    }

    Try   
    {
        $sub_id = Get-AzureRMSubscription -SubscriptionName $sub_name; 
        Set-AzureRmContext -SubscriptionId $sub_id.subscriptionid
        Write-host -ForegroundColor Cyan "2. Pulling Vault {$($VaultName)} by connecting subscription {$($sub_name)}."
    } 
    catch
    { 
        Write-host -ForegroundColor Red "Error: Subscription {$($sub_name)} Not Found."; return $false;
    }

    Try   
    {
        Write-host -ForegroundColor Cyan "3. Setting permission to Azure Account {$($AzureSubAdmin)}."
        Set-AzureRmKeyVaultAccessPolicy -VaultName $VaultName -ResourceGroupName $ResourceGrp -UserPrincipalName $AzureSubAdmin -PermissionsToSecrets all
        Write-host -ForegroundColor Cyan "..... Setting permission to Azure Account {$($AzureSubAdmin)} is successful."
    }
    catch 
    {
        Write-host -ForegroundColor Red "Error: Failed to assign permission to Azure Account {$($AzureSubAdmin)}. Please check with Subscription Owner for more details"; return $false;
    }

}
Function ConvertTo-Secret                { 
    [CmdletBinding()]
    param (
        [parameter(Mandatory = $true,Position=0)][string] $AccountName,
        [parameter(Mandatory = $true,Position=1)][string] $AccountDomain,
        [parameter(Mandatory = $true,Position=2)][string] $PassForAKV,
        [parameter(Mandatory = $false,Position=3)][string] $OldPassword
        )
  
    Try
    {
        $Creator=(get-azurermcontext -ErrorAction Stop).account.id 
        [string]$date = $(Get-date -Format 'dd/MMM/yyyy-hh:mm:ss' )
        $UserSecret = $Creator+" "+$AccountDomain.Substring(0,$AccountDomain.IndexOf('.'))+"\"+$AccountName+" "+$PassForAKV+" "+$OldPassword+" "+$date
    }
    Catch {$Error[0].Exception}
   
    Return $UserSecret|ConvertTo-SecureString -AsPlainText -Force
}
Function PingMachine                     {

   Param([string]$MachineName)
   
   $PingResult = Get-WmiObject win32_pingstatus -f "address='$MachineName'"
    
    if($PingResult.statuscode -eq 0) 
    {
        $true
    } 
    else 
    {
        $false
    }
}
Function Get-PasswordExpiry              {
<# 
    Title: Get Password Expiry
    Author : nitin gupta (nitinkg)

    Description:
    This Function will help to get the AD Account password expiry date along with the days pending for actual expiration.
    
    Example: 
    Get-PasswordExpiryAge -AccountName 'partners\prtexp'
        
#>
param($accountname, $dom)
    Try
    {
        $Expirydate=$null
        $return = $null
        
        $Expirydate = (Get-ADUser -identity $accountname -Server $dom -Properties msds-userpasswordexpirytimecomputed | 
        Select samaccountname,@{Name = "Expiration Date"; Expression={[datetime]::fromfiletime($_."msds-userpasswordexpirytimecomputed")}})
    
        If($Expirydate -ne $null)
        {     
            $timestamp = [datetime]($expirydate.'expiration date').tostring() - [datetime](get-date).tostring()
            $retrun = -join($expirydate.'expiration date',"#",$timestamp.days.tostring())
        }
        Else
        {
            write-host -ForegroundColor Cyan $accountname
        }
    }
    Catch 
    {
        write-host -foregroundcolor:red "error:" $error[0].exception.message
    }
    $retrun
}
Function GenerateADPassword              {
    <#
    DESCRIPTION
       Generates one or more complex passwords designed to fulfill the requirements for Active Directory
    
    .EXAMPLE
       GenerateADPassword
       GenerateADPassword -MinPasswordLength 8 -MaxPasswordLength 12 -Count 4
       GenerateADPassword -InputStrings abc, ABC, 123 -PasswordLength 4
       GenerateADPassword -InputStrings abc, ABC, 123 -PasswordLength 4 -FirstChar abcdefghijkmnpqrstuvwxyzABCEFGHJKLMNPQRSTUVWXYZ
    #>

    [CmdletBinding(DefaultParameterSetName='FixedLength',ConfirmImpact='None')]
    [OutputType([String])]
    Param
    (
        # Specifies minimum password length
        [Parameter(Mandatory=$false, ParameterSetName='RandomLength')]
        [ValidateScript({$_ -gt 0})]
        [Alias('Min')] 
        [int]$MinPasswordLength = 8,
        
        # Specifies maximum password length
        [Parameter(Mandatory=$false, ParameterSetName='RandomLength')]
        [ValidateScript({if($_ -ge $MinPasswordLength){$true} else{Throw 'Max value cannot be lesser than min value.'}})]
        [Alias('Max')]
        [int]$MaxPasswordLength = 12,

        # Specifies a fixed password length
        [Parameter(Mandatory=$false, ParameterSetName='FixedLength')]
        [ValidateRange(1,2147483647)]
        [int]$PasswordLength = 8,
        [String[]]$InputStrings = @('abcdefghijkmnpqrstuvwxyz', 'ABCEFGHJKLMNPQRSTUVWXYZ', '23456789', '!"#%&'),
        [String] $FirstChar,
        [ValidateRange(1,2147483647)]
        [int]$Count = 1
    )
    Begin {
        Function Get-Seed{
            # Generate a seed for randomization
            $RandomBytes = New-Object -TypeName 'System.Byte[]' 4
            $Random = New-Object -TypeName 'System.Security.Cryptography.RNGCryptoServiceProvider'
            $Random.GetBytes($RandomBytes)
            [BitConverter]::ToUInt32($RandomBytes, 0)
        }
    }
    Process {
        For($iteration = 1;$iteration -le $Count; $iteration++){
            $Password = @{}
            # Create char arrays containing groups of possible chars
            [char[][]]$CharGroups = $InputStrings

            $AllChars = $CharGroups | ForEach-Object {[Char[]]$_}

            # Set password length
            if($PSCmdlet.ParameterSetName -eq 'RandomLength')
            {
                if($MinPasswordLength -eq $MaxPasswordLength) {
                    # If password length is set, use set length
                    $PasswordLength = $MinPasswordLength
                }
                else {
                    # Otherwise randomize password length
                    $PasswordLength = ((Get-Seed) % ($MaxPasswordLength + 1 - $MinPasswordLength)) + $MinPasswordLength
                }
            }

            if($PSBoundParameters.ContainsKey('FirstChar')){
                $Password.Add(0,$FirstChar[((Get-Seed) % $FirstChar.Length)])
            }
            # Randomize one char from each group
            Foreach($Group in $CharGroups) {
                if($Password.Count -lt $PasswordLength) {
                    $Index = Get-Seed
                    While ($Password.ContainsKey($Index)){
                        $Index = Get-Seed                        
                    }
                    $Password.Add($Index,$Group[((Get-Seed) % $Group.Count)])
                }
            }

            for($i=$Password.Count;$i -lt $PasswordLength;$i++) {
                $Index = Get-Seed
                While ($Password.ContainsKey($Index)){
                    $Index = Get-Seed                        
                }
                $Password.Add($Index,$AllChars[((Get-Seed) % $AllChars.Count)])
            }
            Write-Output -InputObject $(-join ($Password.GetEnumerator() | Sort-Object -Property Name | Select-Object -ExpandProperty Value))
        }
    }
}
Function UpdatePassword                  {
<#
        DESCRIPTION: 
        After AD Service account password reset, this function will help you to apply the new password in all 5 diffrent repositories and recycle the components if requires.
        
            1. Windows Service 
            2. IIS Application Pool
            3. Task Scheduler
            4. COM+ Applications 
            5. Cached Credentials
    
        EXAMPLE:
        UpdatePassword -server <Domain value ex. Partners.extranet.microsoft.com> -ServiceAccount <AccountName which you want to update> -Password <Latest Password
#>
[cmdletbinding()]
Param(
        [Parameter(Mandatory=$True)] $server,
        [Parameter(Mandatory=$True)] $ServiceAccount,
        [Parameter(Mandatory=$false)] $Password,
        [Parameter(Mandatory=$True)] [ValidateSet('True','False')] [string]$AzureKeyVault,
        [Parameter(Mandatory=$false)] $SubscriptionName,
        [Parameter(Mandatory=$false)] $ResourceGroup,
        [Parameter(Mandatory=$false)] $KeyVaultName  
    )
Try
{
    $AppPool                             =  {
        Param ($ServiceAccount, $password)
        $Error.Clear()

        $i = Get-Module -ListAvailable | Select Name | Where {$_.Name -like 'WebAdministration'}
        If($i -ne $null){
            Import-Module WebAdministration
            $applicationPools = Get-ChildItem IIS:\AppPools | Where {$_.ProcessModel.UserName -Like "*$($ServiceAccount)*"}
        }
        else
        {
            write-host "Information : IIS Applications Not found."
        }

        foreach($applicationPool in $applicationPools)
        {
            write-host "$($applicationPool.Name) Application Pool using $($applicationPool.ProcessModel.UserName), We're Updating the Password & Recycling it."

            $applicationPool.processModel.userName = $applicationPool.ProcessModel.UserName
            $applicationPool.processModel.password = $password
            $applicationPool.processModel.identityType = 3
            $applicationPool | Set-Item

            Start-Sleep -s 2
            If($applicationPool.state -eq "Started")
            {
                Restart-WebAppPool $applicationPool.Name
                write-host "Restarted Application pool $($applicationPool.Name) & passwords updated" 
                write-host ""
            }
            else 
            { 
                write-host "App Pool $($applicationPool.Name) found in Stopped State, however applied the new password without recycle."
                Write-Host ""
            }
           
        }
    } #Completed
    $IISWebSiteAuthenticationCredentials =  {
    Param($server, $ServiceAccount, $Password)
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.Web.Administration") | Out-Null 
    Try{
    $iis = new-object Microsoft.Web.Administration.ServerManager
    }catch {write-host "Information: IIS Not Found"; continue}
    $ErrorActionPreference = "stop"
    $registryPath = "HKLM:\SOFTWARE\Microsoft\InetStp\"
    
    Try
    {
        $iisVersion = $(get-itemproperty HKLM:\SOFTWARE\Microsoft\InetStp\).setupstring
    }
    catch [System.Management.Automation.PSArgumentException]
    { 
        write-host  "Argument Missing"; 
        Break
    }
    Catch [System.Management.Automation.ItemNotFoundException]
    {
        write-host "IIS Not Found on {$Server}"; 
        Break
    }
        
    write-host  "Information : $($iisVersion) - Found on server {$($server)}."
    write-host  "Information : Below IIS Web Site Authentication Using {$($ServiceAccount)}."

    #Pulling Details
    Try
    {
        $Default = ($iis.Sites|Select Name) #Default
        write-host  "Information : Default Web Site : $Default"
        $Details =@()
        
        $details = $iis.Sites | ForEach{$_.Applications | select ApplicationPoolName, Path,
        @{Name="UserName"; Expression = {$_.GetWebConfiguration().GetSection("system.webServer/security/authentication/anonymousAuthentication").GetAttributeValue("UserName")}},
        @{Name="AnonymousEnabled"; Expression = {$_.GetWebConfiguration().GetSection("system.webServer/security/authentication/anonymousAuthentication").GetAttributeValue("Enabled")}}|
        where {$_.UserName -like "*$($ServiceAccount)*"}            
        }

        #$Details | Format-table -a
        ForEach($detail in $Details)
        {
            $file = -join ($default.Name,$detail.Path)
            $Pass = ($iis.GetApplicationHostConfiguration()).GetSection("system.webServer/security/authentication/anonymousAuthentication","$($file)").Attributes["Password"].Value
            $Detail | Select ApplicationPoolName, Path,AnonymousEnabled, UserName, @{Name="Password"; Expression={$($Pass)}} 
            
            Try
            {
                #Update Credentials
                #-------------------
                #($iis.GetApplicationHostConfiguration()).GetSection("system.webServer/security/authentication/anonymousAuthentication","$($file)").Attributes["Password"].Value = $Password 
                #$iis.CommitChanges()
            }
            Catch{$error[0].Exception.Message}
                   
        }
    }
    catch
    {
        write-host  "Failure : Unable to Pull IIS Credentials, Exception Details - " -NoNewline
        write-host  $Error[0].Exception.Message
    }

} #Completed
    $GetServiceRunningAccounts           =  {
        Param($UserName, $Password)

        $St = Get-WmiObject  -Namespace root\cimv2 -Class Win32_Service | Where-Object { $_.StartName -like "*$($UserName)*" -and $_.Name -notlike "*SQLSERVER*" } | ForEach-Object {
        $status = $_.Change($null, $null, $null, $null, $null, $null,$_.StartName,$Password).ReturnValue
        
            If($Status -eq 0)
            {
                write-host ""
                write-host -ForegroundColor Green "Windows Service Passwoard Change request accepted for $($_.Name) Service."
        
                $DependentService = (Get-Service -Name $_.Name).DependentServices #Pulling Dependent Service Details If any

                If($DependentService.Name) #If Found any Dependent 
                {
                    write-host  "Dependent Service {$($DependentService.Name)} found on Parent Service {$($_.Name)}."

                    if((Get-Service -Name $($DependentService.Name) | Select Status).Status -eq 'running') #If Dependent Service Running
                    {
                        Stop-Service -Name $($DependentService.Name) #Stopping Dependent Service
                        Start-Sleep -s 2

                        write-host  "Initiated Dependent Service {$($DependentService.Name)} Stop request."
                        Get-Service -Name $($DependentService.DisplayName)
                    
                        while((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($DependentService.Name)'").Started)
                        {
                            Start-Sleep -s 1
                        }
                    }
                    else
                    {
                        Get-Service -Name $($DependentService.Name)
                    }

                    if((Get-Service -Name $($_.Name) | Select Status).Status -eq 'running') #If Parent Service Running
                    {
                        write-host "Initiating Stop request for $($_.Name) Service."

                        $stop = ($_.StopService()).ReturnValue #Stopping Main Service
                        If($stop -eq 0)
                        {
                            write-host "Stop Service Request Accepted for Windows Service {$($_.Name)}. Awaiting 'stopped' status." -NoNewline 
                            while ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($_.Name)'").Started) 
                            {
                            Start-Sleep -s 1
                            write-host -NoNewline "."
                        }
                            write-host "."

                        $start = $_.StartService().ReturnValue
                        if ($start -eq 0)
                        {
                            write-host -ForegroundColor Green "Start request accepted for Windows Server {$($_.Name)}."
                        }
                        else
                        {
                            write-host -ForegroundColor Red ("Failed to start service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393660(v=vs.85).aspx" -f $start) 
                        }
                    }
             
                    Start-sleep 5
                    write-host   "Starting Dependent Service $($DependentService.Name)"
                    Start-Service -Name $($DependentService.Name)
                    Get-Service -Name $($DependentService.Name)
                    }
                    else
                    {
                        Get-Service -Name $($_.Name)
                    }
                
                }
                else # In case no dependent service
                {
                  if ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($_.Name)'").Started) #If Service in Running State
                    {
                        $serviceName = $_.Name
                        $stop = ($_.StopService()).ReturnValue
                
                        If($stop -eq 0)
                        {
                            write-host "Stop Service Request Accepted for Windows Service {$($serviceName)}. Awaiting 'stopped' status." -NoNewline 
                            while ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$serviceName'").Started)
                            {
                                Start-Sleep -s 1
                                write-host -NoNewline "."
                            }
                            write-host "."
                            $start = $_.StartService().ReturnValue
                    
                            if ($start -eq 0)
                            {
                                write-host -ForegroundColor Green "Start request accepted for Windows Server {$($serviceName)}."
                            }
                            else
                            {
                                
                                write-host ("Failed to start service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393660(v=vs.85).aspx" -f $start)  
                            }
                        }
                        else
                        {
                            write-host ("Failed to stop service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393673(v=vs.85).aspx" -f $stop) -ForegroundColor "red"
                        }
                    }
                    else
                    {                    
                        write-host "Current Service Status : $(Get-Service -Name $_.Name|Select Name, Status) " -NoNewline
                        write-host "As the service was in stop state before the Password change activity, We're not initiating the Start Request for the same."
                        
                    }
                }
            }
            else
            {
                write-host  "Windows Service Password Change request failed for $($_.Name) Service."
            }
        }
        
        if(!$St){
            write-host  "Information : SQL Services found with Logon Name as {$($UserName)} and will be taken care in next step, under SQL operations."
        }

    } #Updated except SQL Service #Updated except SQL Service & Service Status based action
    $COMAccount                          =  {
    Param ($UserName, $Password, $server)
    $comAdmin = New-Object -comobject COMAdmin.COMAdminCatalog
    $apps = $comAdmin.GetCollection(“Applications”)
    $apps.Populate();
    $AvailableCom=0;

    If($apps)
    {
        foreach($app in $apps)
        {
            if($app.Value("Identity") -like "*$($UserName)*")
            {
                write-host $app.Name "- using Service Account :" $app.Value("Identity") 
                $app.value("Identity") = $app.Value("Identity")
                $app.value("Password") = $Password
                $save = $apps.SaveChanges()
                $save
                    if($save -ne $null)
                    {
                    write-host "Password Update Successfully for COM+ : $($app.Name)"
                    #$comAdmin.StartApplication($app.Name)

                    #"$($app.Name) Application Started"

                } 
                    else
                    {
                    write-host "Password Update Failed for COM+ : $($app.Name)"
                }
                    $AvailableCom =+ 1
            }
        }
        write-host "$($AvailableCom): COM+ Applications running under $($UserName) & updated"
    }
    else {write-host "COM+ Application not found on Server {$($server)}."}
} #Completed
    $GetSchduleTaskUsers                 =  {
    Param ($User,$FullUser, $Password)

    $details=@(); $i=@()
    $serviceAccount =$User
    $TaskSystemAccounts = 'INTERACTIVE', 'SYSTEM', 'NETWORK SERVICE', 'LOCAL SERVICE', 'Run As User', 'Authenticated Users', 'Users', 'Administrators', 'Everyone', ''
    $TaskFilter = { $TaskSystemAccounts -notcontains $_.'Run As User' }
               
    Invoke-Expression "SCHTASKS /QUERY /FO CSV /V" -EA SilentlyContinue | ConvertFrom-CSV | Where-Object $TaskFilter | ForEach-Object {
    $details +=New-Object -TypeName PSObject -Property @{
    Type = 'Task'
    Name = $_.TaskName
    Account = $_.'Run As User'} | Select-Object Type, Name, Account | Where-Object {$_.account -like "*$($serviceAccount)*"}}
    
    write-host ""
    write-host "Below $($details.count) Tasks running under Account {$($FullUser)}."
    write-host "-------------------------------------------------------------------"
    $details |select Type, Name, Account | format-table -AutoSize

        foreach($detail in $details)
        {
            try
            {
                $i+=Set-ScheduledTask -TaskName $detail.Name -user $Fulluser -Password $Password -EA SilentlyContinue 
            }
            catch
            {
                $error[0].Exception.Message
            }
        }
        
        if($details.count -eq $i.count)
        {
            write-host "All $($details.count) Tasks are updated successfully."
        }
        else
        {
            write-host "Out of $($details.count) Tasks {$($details.count - ($details.count - $i.count))} Tasks failed!!!"
        }
    } #Updated
    $Cached                              =  {
    Param ($User,$Password)
    Function Get-CachedCredential{ 
    <# 
        DESCRIPTION: 
        This function wraps cmdkey /list and returns an object that contains 
        the Targetname, user and type of cached credentials. 
       
        PARAMETER Type:
        To filter the list provide one of the basic types of  
        cached credentials 
                1. Domain 
                2. Generic 
        EXAMPLE:
        Get-CachedCredential 
 
        Target                                                                         Type                User                  
        ------                                                                         ----                ----                  
        LegacyGeneric:target=MicrosoftAccount:user=nitink.gupta@outlook.com            Generic             nitink.gupta@outlook.com
        MicrosoftOnlineServices:target=virtualapp/didlogical                           Generic             02kqbmtcoyoq            
        WindowsLive:target=virtualapp/didlogical                                       Generic             02elhualljdh            
        LegacyGeneric:target=NITIN_DELLXPS\Test                                        Generic             NITIN_DELLXPS\Test      
        LegacyGeneric:target=Microsoft_OC1:uri=nitinkg@microsoft.com:specific:OCS:1    Generic             nitinkg@microsoft.com   
        LegacyGeneric:target=Microsoft_OC1:uri=nitinkg@microsoft.com:certificate:OCS:1 Generic Certificate <Certificate>           
        LegacyGeneric:target=REDMOND\lpoaasvc                                          Generic             REDMOND\lpoaasvc  
 
           
    #> 
    [CmdletBinding()] 
    
    Param ([ValidateSet("Generic","Domain","Certificate","All")] [string]$Type) 
    Begin{ $Result = cmdkey /list } 
    Process{ 
                $Return = @() 
                $Temp = New-Object -TypeName psobject 
                foreach ($Entry in $Result) { 
                    if ($Entry) { 
                        $Line = $Entry.Trim(); 
                        if ($Line.Contains('Target: ')){ 
                            Write-Verbose $Line 
                            $Target = $Line.Replace('Target: ',''); 
                            } 
                        if ($Line.Contains('Type: ')) { 
                            Write-Verbose $Line 
                            $TargetType = $Line.Replace('Type: ',''); 
                            } 
                        if ($Line.Contains('User: ')) { 
                            Write-Verbose $Line 
                            $User = $Line.Replace('User: ',''); 
                            Add-Member -InputObject $Temp -MemberType NoteProperty -Name Target -Value $Target 
                            Add-Member -InputObject $Temp -MemberType NoteProperty -Name Type -Value $TargetType 
                            Add-Member -InputObject $Temp -MemberType NoteProperty -Name User -Value $User 
                            $Return += $Temp; 
                            Write-Verbose $Temp; 
                            $Temp = New-Object -TypeName psobject 
                            }}}} 
    End{ 
        if ($Type -eq "All" -or $Type -eq "") { 
            Write-Verbose "ALL" 
            return $Return; } 
        else { 
            Write-Verbose "FILTERED" 
            if ($Type -eq "Domain") { 
                $myType = "Domain Password" } 
            if ($Type -eq "Certificate") { 
                $myType = "Generic Certificate"} 

                if ($Return -ne $null){
                return $Return |Where-Object -Property Type -eq $myType}
                else{
                write-host $user "not available in cached credentials"}

}}
    } #Completed
    Function Add-CachedCredential{ 
    <# 
        DESCRIPTION: 
        This function wraps cmdkey /add and stores a TargetName and 
        user/pass combination in the vault 
        
        PARAMETER: 
            1. TargetName: The name of the object to store credentials for, typically 
                           this would be a computer name 
            
            2. Type: Add credentials in one of the few valid types of cached credentials 
                2.1 - Domain 
                2.2 - Generic 
            3. Username : Specify the username which needs to be updated
            4. Password : New Password
    #> 
    [CmdletBinding()] 
    Param ( 
        [Parameter(Mandatory=$true,ValueFromPipeline=$True)] [string]$TargetName, [ValidateSet("Generic","Domain")] [string]$Type, 
        [Parameter(Mandatory=$true)] [string]$Username,
        [Parameter(Mandatory=$true)] [string]$Password) 
    Begin{ 
        #$Username = $Credential.UserName; 
        #$Password = $Credential.GetNetworkCredential().Password; 
    } 
    Process { foreach ($Target in $TargetName) 
            { switch ($Type) 
                { "Generic" 
                {$Result = cmdkey /generic:$Target /user:$Username /pass:$Password 
                    if ($LASTEXITCODE -eq 0) 
                    {Return $Result;} 
                    {Write-Error $Result; Write-Error $LASTEXITCODE} 
                } 
                "Domain"{ 
                    $Result = cmdkey /add:$Target /user:$Username /pass:$Password 
                    if ($LASTEXITCODE -eq 0) 
                    {Return $Result;} 
                    {Write-Error $Result; Write-Error $LASTEXITCODE} 
                }}}} 
    End 
    {}
 } #Completed
    $CachedCredentials = Get-CachedCredential | Select User, Type, Target | Where-Object {$_.User -like "*$($User)*" -and $_.Type -notlike '*Domain*'}
    if($CachedCredentials)
    {
        write-host "Cached Credential available for Service Account {$($User)}"
        Get-CachedCredential | Select User, Type, Target | Where-Object {$_.User -like "*$($User)*"}
        write-host "Updating New Credentials for Service Account {$($User)}."
        write-host ""

        foreach($cred in $CachedCredentials)
        {
                Add-CachedCredential -TargetName $cred.Target -Type $cred.type -Username $cred.User -Password $Password -InformationAction SilentlyContinue
        }
    }
    else
    {
        write-host "No Cached Credential found for Service Account {$($User)}."
    }
} #Updated
    $SQLChange                           =  {
    Param ($UserName, $password, $Server)
    $flag = 1; $FailoverDone = 0; $i=1; $DT =@() 

     Function ExecuteSqlQuery ($Query, $Server) { 
                Try
                {
                    $Datatable = New-Object System.Data.DataTable 
                    $conn = New-Object System.Data.SqlClient.SqlConnection("Data Source="+$($server)+";Integrated Security=SSPI;Initial Catalog=master")
                    $conn.Open()
    
                    $Command = New-Object System.Data.SQLClient.SQLCommand 
                    $Command.Connection = $conn 
                    $Command.CommandText = $Query

                    $DataAdapter = new-object System.Data.SqlClient.SqlDataAdapter $Command 
                    $Dataset = new-object System.Data.Dataset 
                    $DataAdapter.Fill($Dataset) 
                    $conn.Close() 
                }
                catch
                {
                    write-host  "SQL Exception: Connection Failure on $($Server)."
                    write-host  "Details: $($Error[0].Exception.Message)."
                    $conn.Close()
                }
                return $Dataset.Tables[0] 
            }

    $SQLStatus = (Get-WmiObject  -Namespace root\cimv2 -Class Win32_Service | Where-Object { $_.StartName -like "*$($UserName)*" -and $_.Name -eq "MSSQLSERVER"})
    
    If($SQLStatus.State -eq 'Running')
    {
        $Query = "select SERVERPROPERTY ('IsHadrEnabled') as Status"; $IsserverAGEnabled = ExecuteSqlQuery -Query $Query -Server $Server
        If($IsserverAGEnabled.Status -eq 1)
        {
            write-host  "Information : $($server) is a part of SQL AG cluster".

            $AODB      = "select top 1 database_name[Name] from 
            sys.dm_hadr_database_replica_cluster_states drcs"; $DB   = ExecuteSqlQuery -Query $AODB    -Server $server
            $AGQuery   = "select 'SECONDARY' AS Property, replica_server_name AS Value from sys.dm_hadr_availability_replica_cluster_states arcs 
            join sys.dm_hadr_database_replica_cluster_states drcs on arcs.replica_id=drcs.replica_id 
            join sys.dm_hadr_availability_replica_states ars on arcs.replica_id = ars.replica_id where arcs.replica_server_name = '$($server)' 
            AND drcs.database_name = '$($DB.Name)' AND ars.role_desc = 'SECONDARY'
            UNION ALL SELECT 'AGNAME' AS SITE , NAME AS [NODE] FROM SYS.AVAILABILITY_GROUPS_CLUSTER"; $Rows = ExecuteSqlQuery -Query $AGQuery -Server $server

            Foreach($Row in $Rows)
            {
                if($Row.Property -ne $null)
                {
                    if($Row.property -ne 'SECONDARY' -and $Rows.Count -eq 2)
                    {
                        $flag = 0
                        write-host  "Information : $($server) is a Primary node of the SQL AG cluster".
                        Try
                        {
                            If($Server.IndexOf('.') -ge 0)
                            {
                                $local = $server.Substring(0,$server.IndexOf('.'))
                                [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | out-null
                                $SMOWmiserver = New-Object ("Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer") "$($local)" 
                            }
                            else
                            {
                                [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | out-null
                                $SMOWmiserver = New-Object ("Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer") "$($Server)"
                            }
                            Try
                            {
                                $SMOWmiserver.Services | select name, ServiceAccount, DisplayName, StartMode | ? {$_.ServiceAccount -like "*$($UserName)*"} |Format-List
                                $ChangeService=$SMOWmiserver.Services | where {$_.ServiceAccount -like "*$UserName*"} #Make sure this is what you want changed!
                            }
                            catch 
                            {
                                write-host "SQL Configuration Manager not Found or SMO WMI Provider missing. Retrying the same from Services.msc"
                                Get-WmiObject -Namespace root\cimv2 -Class Win32_Service | Where-Object { $_.StartName -like "*$($UserName)*" -and $_.Name -like "*SQL*" } | ForEach-Object {
                                $Status = $_.Change($null, $null, $null, $null, $null, $null,$_.StartName,$Password).ReturnValue
            
                                If($Status -eq 0)
                                {
                                    write-host -ForegroundColor Green "....Success : Windows Service Passwoard Change request accepted for $($_.Name) Service."
                                    $DependentService = (Get-Service -Name $_.Name).DependentServices

                                    If($DependentService)
                                    {
                                        write-host  "Information : Stopping Dependent Windows Service {$($DependentService.Name)}."
                                        Stop-Service -Name $($DependentService.Name)

                                        while((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($DependentService.Name)'").Started)
                                        {
                                            Start-Sleep -s 1
                                            write-host "." -NoNewline
                                        }

                                        write-host "."
                                        write-host  "Information : Dependent Service {$($DependentService.Name)} Stopped Successfully."
                                        write-host  "Information : Stopping Parent Service {$($_.Name)}."

                                        $stop = ($_.StopService()).ReturnValue
                    
                                        If($stop -eq 0)
                                        {
                                            write-host  "Information : Stop Service Request Accepted for Windows Service {$($_.Name)}. Awaiting 'stopped' status." -NoNewline
                        
                                            while ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($_.Name)'").Started) 
                                            {
                                                Start-Sleep -s 1
                                                write-host -NoNewline "."
                                            }
                                            write-host "."

                                            write-host  "Success : Parent Service {$($_.Name)} Stopped Successfully."
                                            write-host  "Information : Starting Parent Service {$($_.Name)} after Password Update."

                                            $start = $_.StartService().ReturnValue
                                            if ($start -eq 0)
                                            {
                                                write-host -ForegroundColor Green "Information : Parent Service {$($_.Name)} Started Successfully."
                                                write-host  "Information : Starting Dependent Service {$($DependentService.Name)}."
                            
                                                Start-sleep 5
                                                Start-Service -Name $($DependentService.Name)

                                            }
                                            else
                                            {
                                                write-host  ("Failed : Failed to start service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393660(v=vs.85).aspx" -f $start) 
                                            }
                                        }
                                    }
                                    Else
                                    {
                                        If ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($_.Name)'").Started)
                                        {
                                            $serviceName = $_.Name
                                            write-host  "Information : Stopping Service {$($serviceName)}."
                                            $stop = ($_.StopService()).ReturnValue
                        
                                            If($stop -eq 0)
                                            {
                                                while ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$serviceName'").Started)
                                                {
                                                    Start-Sleep -s 1
                                                    write-host -NoNewline "."
                                                }
                                                write-host "."
                                                write-host -ForegroundColor Green "....Success : Service {$($serviceName)} Successfully Stopped."

                                                $start = $_.StartService().ReturnValue
                                                write-host  "Information : Initiating {$($serviceName)} Service Start after Password update."

                                                If ($start -eq 0)
                                                {
                                                    write-host -ForegroundColor Green "....Success : Service {$($serviceName)} Successfully Started."
                                                }
                                                Else
                                                {
                                                    write-host  ("Failed : Failed to start service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393660(v=vs.85).aspx" -f $start) 
                                                }

                                            }
                                            Else
                                            {
                                                write-host  ("Failed : Failed to stop service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393673(v=vs.85).aspx" -f $stop) 
                                            }
                    
                                        }
                                    }
                                }
                                Else
                                {
                                    write-host  "Failed : Windows Service Password Change request failed for $($_.Name) Service."
                                }}
                            }
                            ForEach($service in $ChangeService)
                            {
                                Try
                                {
                                    $Service.SetServiceAccount($Service.ServiceAccount, $password)
                                    write-host -ForegroundColor Green "Success : Password update completed for $($service.Name), Initiating Service recycle."

                                    Try
                                    {

                                        $SMOWmiserver.Services[$Service.Name].Stop() 
                                        start-sleep -s 15
                                        $SMOWmiserver.Services[$Service.Name].Start()
                                        write-host -foreground cyan "Sucess : Service [$($Service.Name)] Re-started."
                                    }
                                    Catch
                                    {
                                        write-host "Failed to Start\Stop [$($Service.Name)] from Microsoft Configuration Manager or WMI Missing."
                                        write-host -foreground cyan "Retrying [$($Service.Name)] Using Services.msc"

                                        Try
                                        {
                                            Restart-Service -Name $($Service.Name) -Force
                                            write-host -foreground cyan "Sucess : Service [$($Service.Name)] Re-started."
                                        }
                                        catch
                                        {
                                            write-host "Failed to Start\Stop [$($Service.Name)] from Services.msc, Please restart it manually." 
                                        }

                                    }
                                }
                                Catch
                                {
                                    write-host  "Failed : Password update failed for $($service.Name)." -NoNewline
                                    write-host "{Exception Details : $($Error[0].Exception.Message)}."
                                }
                            }

                            #$ChangeService
                            write-host  "Information : SQL Services Status post password change."
                            Get-Service | Select DisplayName, Name, Status | ? {$_.Name -like '*SQL*'} | Format-table -AutoSize
                        }
                        Catch
                        {
                            $flag = 1; 
                            write-host $error[0].exception.message
                        }
                    }
                    else
                    {
                        $Sec = 1; $flag = 0
                    }

                }
            }
        }
        else
        {
            write-host  "Information : $($Server) - Standalone SQL Server Machine."
            $flag = 0
        } 

        If($flag -eq 0)
        {
            if($sec -eq 1)
            {
                write-host  "Information : $($Server) is a Secondary Node of the AG Cluster."
            }

            write-host  'Information : Initiating Password update for SQL Services.'
            $ST = Get-WmiObject  -Namespace root\cimv2 -Class Win32_Service | Where-Object { $_.StartName -like "*$($UserName)*" -and $_.Name -like "*SQL*" }
            
            Get-WmiObject -Namespace root\cimv2 -Class Win32_Service | Where-Object { $_.StartName -like "*$($UserName)*" -and $_.Name -like "*SQL*" } | ForEach-Object {
            $Status = $_.Change($null, $null, $null, $null, $null, $null,$_.StartName,$Password).ReturnValue
            
                If($Status -eq 0)
                {
                    write-host -ForegroundColor Green "....Success : Windows Service Passwoard Change request accepted for $($_.Name) Service."
                    $DependentService = (Get-Service -Name $_.Name).DependentServices

                    If($DependentService)
                    {
                        write-host  "Information : Stopping Dependent Windows Service {$($DependentService.Name)}."
                        Stop-Service -Name $($DependentService.Name)

                        while((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($DependentService.Name)'").Started)
                        {
                            Start-Sleep -s 1
                            write-host "." -NoNewline
                        }
                        write-host "."
                        write-host -ForegroundColor Green "Success : Dependent Service {$($DependentService.Name)} Stopped Successfully."
                        write-host  "Information : Stopping Parent Service {$($_.Name)}."

                        $stop = ($_.StopService()).ReturnValue
                    
                        If($stop -eq 0)
                        {
                            write-host  "Information : Stop Service Request Accepted for Windows Service {$($_.Name)}. Awaiting 'stopped' status." -NoNewline
                        
                            while ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($_.Name)'").Started) 
                            {
                                Start-Sleep -s 1
                                write-host -NoNewline "."
                            }
                            write-host "."

                            write-host -ForegroundColor Green "Success : Parent Service {$($_.Name)} Stopped Successfully."
                            write-host  "Information : Starting Parent Service {$($_.Name)} after Password Update."

                            $start = $_.StartService().ReturnValue
                            if ($start -eq 0)
                            {
                                write-host -ForegroundColor Green "Success : Parent Service {$($_.Name)} Started Successfully."
                                write-host  "Information : Starting Dependent Service {$($DependentService.Name)}."
                            
                                Start-sleep 5
                                Start-Service -Name $($DependentService.Name)

                            }
                            else
                            {
                                write-host  ("Failed : Failed to start service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393660(v=vs.85).aspx" -f $start) 
                            }
                        }
                    }
                    Else
                    {
                        If ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($_.Name)'").Started)
                        {
                            $serviceName = $_.Name
                            write-host  "Information : Stopping Service {$($serviceName)}."
                            $stop = ($_.StopService()).ReturnValue
                        
                            If($stop -eq 0)
                            {
                                while ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$serviceName'").Started)
                                {
                                    Start-Sleep -s 1
                                    write-host -NoNewline "."
                                }
                                write-host "."
                                write-host -ForegroundColor Green "....Success : Service {$($serviceName)} Successfully Stopped."

                                $start = $_.StartService().ReturnValue
                                write-host  "Information : Initiating {$($serviceName)} Service Start after Password update."

                                If ($start -eq 0)
                                {
                                    write-host -ForegroundColor Green "....Success : Service {$($serviceName)} Successfully Started."
                                }
                                Else
                                {
                                    write-host  ("Failed : Failed to start service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393660(v=vs.85).aspx" -f $start) 
                                }

                            }
                            Else
                            {
                                write-host  ("Failed : Failed to stop service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393673(v=vs.85).aspx" -f $stop) 
                            }
                    
                        }
                    }
                }
                Else
                {
                    write-host  "Failed : Windows Service Password Change request failed for $($_.Name) Service."
                }

            }

            If(!$St)
            {
                write-host  "Information : No SQL Servcies found with Logon Name as {$($UserName)} on {$($Server)}"
            } 

        }
        else
        {
            write-host  "Error: Exception During SQL Operations, SQL Account Password change operation failed."; 
            write-host  "Actual Exception => $($Error[0].Exception.Message)"
            $flag = 1
        }

    }
    elseif($SQLStatus.State -eq 'Stopped')
    {
        write-host  "Information : SQL Service Available on [$($Server)] under logon [$($UserName)] and found in Stopped State."
        Get-WmiObject  -Namespace root\cimv2 -Class Win32_Service | Where-Object { $_.StartName -like "*$($UserName)*" -and $_.Name -like "*SQL*"} | ForEach-Object{
            if(($_.change($null, $null, $null, $null, $null, $null,$_.StartName,$Password).ReturnValue) -eq 0)
            {
                write-host  "Information : Password Change Accepted for {$($_.Name)} Service."
            }
            else
            {
                write-host "Password Change Failed for {$($_.Name)} Service."
            }
        }
    }
    else
    {
        write-host  "Information : SQL Server not available on {$($Server)}."

    }

} #Updated without AG Failover 
    $SQLProxy                            =  {

        Param ($ServerName,$UserName, $Password )
        Function ExecuteSqlQuery ($Query, $Server) { 
            Try
            {
                $Datatable = New-Object System.Data.DataTable 
                $conn = New-Object System.Data.SqlClient.SqlConnection("Data Source="+$($server)+";Integrated Security=SSPI;Initial Catalog=master")
                $conn.Open()
    
                $Command = New-Object System.Data.SQLClient.SQLCommand 
                $Command.Connection = $conn 
                $Command.CommandText = $Query

                $DataAdapter = new-object System.Data.SqlClient.SqlDataAdapter $Command 
                $Dataset = new-object System.Data.Dataset 
                $DataAdapter.Fill($Dataset) 
                $conn.Close() 
            
            }
            catch
            {
                write-host  "SQL Exception: Connection Failure on $($Server)."
                write-host  "Details: $($Error[0].Exception.Message)."
                $conn.Close()
                $flag=1
            }
            return $Dataset.Tables[0] 
        } 
        
        Try
        { 
            $SQLStatus = (Get-WmiObject  -Namespace root\cimv2 -Class Win32_Service -EA SilentlyContinue | Where-Object {$_.Name -like "*MSSQLSERVER*" }) 
        }
        Catch 
        {
            write-host $Error[0].Exception.Message
        }

        

        If($SQLStatus)
        {  
            if($SQLStatus.state -eq 'running')
            {
                TRy
                {
                $credQuery = "Select cred.name [Name], prox.enabled [Enabled] from  master.sys.credentials cred with (nolock) inner join msdb..sysproxies prox on cred.credential_id = prox.credential_id 
                where cred.name like '%$($UserName)%' and prox.enabled = 1"; $R = ExecuteSqlQuery -Query $credQuery -Server $ServerName      
                
                If($R)
                {
                    $AlterCred = "ALTER CREDENTIAL [$($R.Name)] WITH IDENTITY = N'$($R.Name)', SECRET = N'$($Password)'"; 
                    $S = ExecuteSqlQuery -Query $AlterCred -Server $ServerName
                    

                    if($S[0] -eq 0)
                    {
                        write-host  "Information : SQL Proxy crdential sucessfully updated on [$($ServerName)] for Service account [$($R.Name)]"    
                    }
                    else
                    {
                        write-host  "Error : Failed to Update SQL Proxy credential on [$($ServerName)] for Service Account [$($R.Name)]."
                    }
                }
                else
                {"No Proxy Account Found"}
            }
                Catch 
                {
                    write-host  "Error: SQL Proxy Account updation Failed [$($Error[0].Exception.Message)]"
                }
            }
            else
            {
                write-host "SQL Service found in Stopped State"
                $SQLStatus
            }
        }
        else {"No SQL Found on $servername"}
    } #Updated
    $WinAutoLogOn                        =  {
    Param($ServiceAccount, $Server, $DefaultPassword)
    $RegPath = "hklm:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\" 
    $r = Get-ChildItem $RegPath 

    If($r.AutoAdminLogon -eq 1)
    {
        write-host  "Windows Auto Logon Enabled on Server : $($Server)"
        
        If($r.DefaultUserName -like "*$($ServiceAccount)*") 
        {
            write-host  "$ServiceAccount :  account is in use as Windows Auto Logon."
            write-host  "Updating Password..."

            Set-ItemProperty $RegPath "AutoAdminLogon" -Value "1" -type String  
            Set-ItemProperty $RegPath "DefaultUsername" -Value "$ServiceAccount" -type String  
            Set-ItemProperty $RegPath "DefaultPassword" -Value "$DefaultPassword" -type String

        }
        else
        {
            write-host  "$ServiceAccount not in use."
        }    
    }
} #Code Added but not using
    
    $AzureAccount                =  [Environment]::UserName + "@microsoft.com"
    $Fulluser = $ServiceAccount.Trim()
    $user = $Fulluser.Substring($Fulluser.IndexOf('\')+1,(($Fulluser.Length)) - $Fulluser.IndexOf('\')-1) #Pulling the Name from the Service account after removing the Domain name

    #$Pass = Get-Content "d:\Password.txt" | ConvertTo-SecureString; $Account='fareast\nitinkg'
    #$credential = [System.Management.Automation.PSCredential]::new($Account, $Pass)

    $session = New-PSSession -ComputerName $Server -Credential $credential
    
    If($AzureKeyVault -eq 'True')
    {
        if(AzureLogin -AzureSubAdmin $AzureAccount -sub_name $SubscriptionName -ResourceGrp $ResourceGroup -VaultName $KeyVaultName)
        {
            write-host  "Pulling Existing Credentials from Azure KeyVault {$($KeyVaultName)}."
            Try
            {
                $Results = (Get-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $user.Trim())
                $Results
                if($Results.Name -eq $user.Trim())
                {
                    $Credentials = $Results.SecretValueText.Split(" ")
                    $AKVPassword = $Credentials[2].ToString()
                        
                    write-host    ""
                    write-host    "Validating and Updating Web Application pool on : $server"
                    write-host    "------------------------------------------------------------------------------------"
                    Invoke-Command -Session $session -ScriptBlock $AppPool -ArgumentList($user,$AKVPassword) 

                    write-host    ""
                    write-host    "Validating and Updating Web Anonymous Authentication on : $server"
                    write-host    "------------------------------------------------------------------------------------"
                    Invoke-Command -Session $session -ScriptBlock $IISWebSiteAuthenticationCredentials -ArgumentList($server, $user,$AKVPassword)

    
                    write-host    ""
                    write-host    "Validating & Updating Windows Services on : $server"
                    write-host    "------------------------------------------------------------------------------------"
                    Invoke-Command -Session $session -ScriptBlock $GetServiceRunningAccounts -ArgumentList($user,$AKVPassword) 

                    write-host    ""
                    write-host    "Validating & Updating SQL Services on : $server"
                    write-host    "------------------------------------------------------------------------------------"
                    Invoke-Command -Session $session -ScriptBlock $SQLChange -ArgumentList($user,$AKVPassword, $server) 

                    write-host    ""
                    write-host    "Validating & Updating SQL Proxy Accounts on : $server"
                    write-host    "------------------------------------------------------------------------------------"
                    Invoke-Command -Session $session -ScriptBlock $SQLProxy -ArgumentList($server, $user,$AKVPassword) 

                    write-host    ""
                    write-host    "Validating & Updating Windows Task Scheduler on : $server"
                    write-host    "------------------------------------------------------------------------------------"  
                    Invoke-Command -Session $session -ScriptBlock $GetSchduleTaskUsers -ArgumentList($user, $FullUser,$AKVPassword) 

                    write-host    ""
                    write-host    "Validating & Updating System Cached Credentials on : $server"
                    write-host    "------------------------------------------------------------------------------------"
                    Invoke-Command -Session $session -ScriptBlock $Cached -ArgumentList($user,$AKVPassword) 

                    write-host    ""
                    write-host    "Validating & Updating COM+ Applications on : $server"
                    write-host    "------------------------------------------------------------------------------------"
                    Invoke-Command -Session $session -ScriptBlock $COMAccount -ArgumentList($user,$AKVPassword, $server) 
                    write-host ""
                    $Retrun = $true
                }
                else{"Credential not Found on Vault"}
            }
            Catch {$Retrun = $false}
        }
        else {write-host "Azure Authentication Failed."}
    }
    else
    {
        Try
        {
           write-host    ""
           write-host    "Validating and Updating Web Application pool on : $($Server)"
           write-host    "------------------------------------------------------------------------------------"
           Invoke-Command -Session $session -ScriptBlock $AppPool -ArgumentList($user,$Password) 

           
           write-host    ""
           write-host    "Validating and Updating Web Anonymous Authentication on : $($server)"
           write-host    "------------------------------------------------------------------------------------"
           Invoke-Command -Session $session -ScriptBlock $IISWebSiteAuthenticationCredentials -ArgumentList($server.trim(), $user,$Password)
    
           write-host    ""
           write-host    "Validating & Updating Windows Services on : $($Server)"
           write-host    "------------------------------------------------------------------------------------"
           Invoke-Command -Session $session -ScriptBlock $GetServiceRunningAccounts -ArgumentList($user,$Password) 

           write-host    ""
           write-host    "Validating & Updating SQL Services on : $($Server)"
           write-host    "------------------------------------------------------------------------------------"
           Invoke-Command -Session $session -ScriptBlock $SQLChange -ArgumentList($user,$Password, $server.trim())

           write-host    ""
           write-host    "Validating & Updating SQL Proxy Accounts on : $($Server)"
           write-host    "------------------------------------------------------------------------------------"
           Invoke-Command -Session $session -ScriptBlock $SQLProxy -ArgumentList($server.Trim(), $user,$Password) 
           

           write-host    ""
           write-host    "Validating & Updating Windows Task Scheduler on : $($Server)"
           write-host    "------------------------------------------------------------------------------------"  
           Invoke-Command -Session $session -ScriptBlock $GetSchduleTaskUsers -ArgumentList($user, $FullUser,$Password) 

           write-host    ""
           write-host    "Validating & Updating System Cached Credentials on : $($Server)"
           write-host    "------------------------------------------------------------------------------------"
           Invoke-Command -Session $session -ScriptBlock $Cached -ArgumentList($user,$Password) 

           write-host    ""
           write-host    "Validating & Updating COM+ Applications on : $($Server)"
           write-host    "------------------------------------------------------------------------------------"
           Invoke-Command -Session $session -ScriptBlock $COMAccount -ArgumentList($user,$Password,$server)
           write-host    ""
           $Retrun = $true
        }
        catch{$Retrun = $false}
    }
}
catch
{
    $Retrun = $false
}
$Return
}
Function ReSetAccountPassword            {
<#
    DESCRIPTION
       Re-set the AD Service Account password, We're using the inhouse function to generate password. Provided two options either people can update account password directly from tool
       or configure it for first logon password change.
    
    PARAMETERS:
        -IDENTITY   : <ServiceAccountName> 
        -DOMAINNAME : <Domain Name ex. partners.extranet.microsoft.com> 
        -LOCATION   : AzureKeyVault | LocalSystem for passward repository.
                      AzureKeyVault : 
                        - SubscriptionName : Specify the Subscription Name Ex. ECIT Production Monitoring 
                        - ResourceGroup    : If you have the existing Resource Group, Please specify else will create on request.
                        - KeyVaultName     : Specify the KeyvaultName.
                      
                      LocalSystem : 
                        - Path             : Folder location to create Password repository CVS file. Which will store ServiceAccont Name & New Passwords.

        -LENGTH     : <Define the New Password length, default value is 8> 
        -NOCHANGE   : <It should be true if you want to update passward after first logon else false>
       
#>
 [cmdletbinding(SupportsShouldProcess=$true,ConfirmImpact='Medium')]   
 Param (
        [Parameter(Mandatory=$true, Position=0)][Alias('DistinguishedName')][String]$Identity,
        [Parameter(Mandatory=$true, Position=1)][String]$CurrentPassword,
        [Parameter(Mandatory=$true, Position=2)][String] $DomainName,
        [Parameter(Mandatory=$true, Position=3)][validateset('AzureKeyVault','LocalFileSystem')] [string[]] $Location,
        [Parameter(Mandatory=$false,Position=4)] $SubscriptionName,
        [Parameter(Mandatory=$false,Position=4)] $ResourceGroup,
        [Parameter(Mandatory=$false,Position=5)] $KeyVaultName)
  
        [int]$Length = 17
        [String[]]$InputStrings = @('abcdefghijkmnopqrstuvwxyz', 'ABCEFGHJKLMNPQRSTUVWXYZ', '0234567891', '#@$(}{)')
        
        $D = Get-ChildItem 'C:\PasswordMaintenance\' |Select Name, Mode |? {$_.Name -eq 'Maintenance'}
        if($D)
        {
            $DefaultLogFile = 'C:\PasswordMaintenance\Maintenance\AccountsDetails.csv'
        }
        else
        {
            mkdir 'c:\PasswordMaintenance\Maintenance'
            $D = Get-ChildItem 'C:\PasswordMaintenance' |Select Name, Mode |? {$_.Name -eq 'Maintenance'}
            if($D)
            {
                $DefaultLogFile = 'C:\PasswordMaintenance\Maintenance\AccountsDetails.csv'
            }
        }

        Try
		{
            $Pass = GenerateADPassword -PasswordLength $Length -InputStrings $InputStrings
            $NewPass = $Pass | ConvertTo-SecureString -AsPlainText -Force
            $OldPassword = $CurrentPassword | ConvertTo-SecureString -AsPlainText -Force
     
            if($PSCmdlet.ShouldProcess("`n$DistinguishedName",'Reset password'))
			{
                Try
				{
                    Set-ADAccountPassword -Identity $Identity -Server $DomainName -OldPassword $OldPassword -NewPassword $NewPass
                    write-host -ForegroundColor Cyan -BackgroundColor Black "Information : Password Successfully Changed for User {$($Identity)}."
                    
                    $flag = $true
                    $details = @{            
                                    "ServiceAccount"     = $Identity                 
                                    "NewPassword"        = $Pass
                                    "OldPassword"		 = $CurrentPassword
                                    "Domain"		     = $DomainName
                                    "PasswordChangeDate" = Get-Date 
                                 }

                    $results += New-Object PSObject -Property $details
                    $results
                    
                    If($Location -eq "LocalFileSystem")
					{
                        Write-Host -ForegroundColor Cyan "Information : Storing credentials on $($DefaultLogFile)."
                        $results | export-csv -Path $DefaultLogFile -Append -NoTypeInformation 
                    }
                    elseif($Location -eq "AzureKeyVault")
					{
                        #Storing Details in Default File System Location as well, Please remove it if all looks good in AKV
                        If(Test-Path $DefaultLogFile)
                        {

                            $results | export-csv -Path $DefaultLogFile -NoTypeInformation
                        }

                        #Pulling Creator Account Details
                        $AzureAccount = [Environment]::UserName + "@microsoft.com"
                        write-host ""    
                        #Connecting Azure Portal & Adding Credentials on AVK
                        If(AzureLogin -AzureSubAdmin $AzureAccount -Sub_name $SubscriptionName -ResourceGrp $ResourceGroup -VaultName $KeyVaultName )
						{
                            Try
							{
                                $Response = (Get-AzureKeyVaultSecret -VaultName $KeyVaultName |Select Name | Where {$_.Name -like "*$Identity*"})
                                $Secret = ConvertTo-Secret -AccountName $Identity -AccountDomain $DomainName -PassForAKV $Pass -OldPassword $CurrentPassword

                                If($Response)
                                {
                                    $i= (Set-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $Identity -SecretValue $Secret)
                                    if($i.Name -eq $Identity){Write-Host "Successfully updated Account {$($Identity)} credentials on KeyVault $($KeyVaultName)"}
                                
                                    elseif ($i -eq $null){
                                        Write-Warning "Fail to update credentials ($($Identity)) on Azure Key Vault {$($KeyVaultName)}."
                                    }
                                }
                                else
                                {
                                    $i= Set-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $Identity -SecretValue $Secret
                                    
                                    if($i.Name -eq $Identity){
                                        Write-Host -ForegroundColor Cyan "Created New Record for Account {$($Identity)} Successfully on KeyVault {$($KeyVaultName)}." 
                                    }
                                    Write-Host -ForegroundColor Cyan "Service Accoount {$($Identity)} not found on {$($KeyVaultName)} hence added as new record."    
                                }
                            }
                            Catch
							{
                                Write-Warning $error[0].Exception
                            }
						}              
                        else
						{
                            Write-host ""
                            Write-Warning "Doesn't have Access on Azure Subscription, Please check with Subscription Owners\Co-Owners."
                        }
					}
				}                
                Catch
				{
                    Write-Warning $Error[0].Exception
                    $flag = $false
                }
            }
		}      
        Catch
		{
            Write-Warning $Error[0].Exception        }
        return $results       
}
Function MyVIPsStatus                    {
<#
    .DESCRIPTION
     This will help people to perform MyVip (HLB) Actions which includes taking Server out of rotation or bring online. Deafult configuration doesn't allow you to take node OOR
     if total nodes availability is less then or equal to 60%.

    .PARAMETERS
     1. OwnerGroupName           : This the MyVips Owner Group Name, we defined few default values or you can check the same from http://MyVips --> Targent node own by Parent VIP Properties
     2. IPAdress                 : Optional parameter and if will be specified if you have correct Parent Vip IP.
     3. Server                   : Target Server\Node Name for Vip Actions.
     4. Action                   : To take node OOR or ONline
              4.1 Suspend(OOR)   : To Take Node OOR\Suspend
              4.2 Resume(OnLine) : Bring Node Online
     5. Force                    : Optional parameter, available to perform Force MyVip actions.
     
     .EXAMPLE
      
      To Take node OOR with Force Vip Action
      MyVIPsStatus -OwnerGroupName ExploreT2Personnel -Server CY1EMSWeb001.PARTNERS.EXTRANET.MICROSOFT.COM -Action 'Suspend(OOR)' -Force True

      To Being node Online 
      MyVIPsStatus -OwnerGroupName ExploreT2Personnel -Server CY1EMSWeb001.PARTNERS.EXTRANET.MICROSOFT.COM -Action 'Resume(Online)'

      Just for check Parent Vip health own by Target node.
      MyVIPsStatus -OwnerGroupName ExploreT2Personnel -Server CY1EMSWeb001.PARTNERS.EXTRANET.MICROSOFT.COM

#>
Param(
          [Parameter(Mandatory=$true,  Position=0, HelpMessage="MyVips Resource Owner Group Name")][validateset('CITSE','mslt2','VLCMSUP','MSQPRODVIP','EMCT2','VLISMSG','LAMINARL3SG','LPOWST2','OEMGTMADMIN','ExploreT2Personnel','ECITMYVIPS', 'MSQL3team', 'MOVEL3','ECIT VIP Mgmt','Papervision L3 Support-PVL3Sup','MSDN-Xena India T2 Team','OEM')][string] $OwnerGroupName,
          [Parameter(Mandatory=$false, Position=1, HelpMessage="MyVips IP Address")] $IPAddress ,
          [Parameter(Mandatory=$true,  Position=2, HelpMessage="Target Server name.")]$Server,
          [Parameter(Mandatory=$false, Position=3, HelpMessage="Want to perform action or see report")][validateset('Suspend(OOR)','Resume(OnLine)')][String] $Action,
          [Parameter(Mandatory=$false, Position=4, HelpMessage="Force OOR Action")][validateset('True','False')][String] $Force = "False")

write-host ""
Write-Host -ForegroundColor Yellow "---------------------------------------"
write-host -ForegroundColor Yellow -Background Black "Starting MyVIPs Opertaions - $(Get-date)."
Write-Host -ForegroundColor Yellow "---------------------------------------"
write-host ""

$ip1=0;$ip1=1

$ips = (Get-WmiObject win32_networkadapterconfiguration -filter "ipenabled = 'True'" -ComputerName $Server | Select @{Name = "IPAddress";Expression = {[regex]$rx = "(\d{1,3}(\.?)){4}"; $rx.matches($_.IPAddress).Value}})

Try{$ip1 = ([string]($ips[0].IPAddress)).Substring(0,([string]($ips[0].IPAddress)).IndexOf(' '))} catch{$ip1 = ([string]($ips[0].IPAddress))} #spliting the IP with port number
    $ip2 = ([string]($ips[1].IPAddress)) 

Write-Host -ForegroundColor Cyan "Server [$($Server)] -  EFL IP[$($ip2)] & EBL IP [$($ip1)]."


Try
{   
    $all_my_vips_info = Get-ITMyVips -ReturnObject | Where-Object {$_.OwnerGroupName -like "*$($OwnerGroupName)*"}
    foreach ($vip_info in $all_my_vips_info) 
    {
        If($vip_info.IP -eq $null){Write-Host "Null VIP IP : $($vip_info.IP)."; continue}

        $vip_status= Get-ITVipStatus -VIP $vip_info.IP -ReturnObject -ErrorAction Continue
        if ($vip_status -ne $null) 
        {
	        foreach ($node in $vip_status.Nodes)
            {
               if((($node.IPAddress).Trim() -eq ($ip1).Trim()) -or (($node.IPAddress).Trim() -eq ($ip2).Trim()))
                {
                    Write-host -ForegroundColor Yellow "Node $($Server) Found in MyVip under [$($vip_info.UserNote) - $($vip_info.IP)]."
                    write-host ""

                    $ParentVip = Get-ITVipStatus -VIP $vip_info.IP -ReturnObject -ErrorAction Continue
                    $PCount = ($ParentVip.Nodes).Count
                    
                    if ($ParentVip -ne $null)
                    {
                        Foreach($PNode in $ParentVip.Nodes)
                        {
                            if($PNode.Enabled -eq $true)
                            {
                                [int]$AvailableNodePercent += 1
                            }
                         }
                    }

                    [int]$nodeAvailPer = ($AvailableNodePercent/$PCount)*100 

                    if($Action -eq 'Suspend(OOR)')
                    {
                        Try
                        {
                            if($nodeAvailPer -ge 60)
                            {
                                Write-host -ForegroundColor Cyan  "1. Initiating Out of rotation process for Server $($server)."
                                #Suspend-ITVipNode -VIP:$vip_info.IP -NodeIP:$IP.IPAddressToString -Port:443
            
                                Start-Sleep -Seconds 3
                                Write-host -ForegroundColor Green "2. Successfully Taken node [$($server)] Out of Rotaion from http://MyVips."
                                write-host ""
                                Write-Host "Current node Health & Availability Status $(Get-date):"
                                write-host -ForegroundColor Yellow "--------------------------------------------------------------------------"
                                write-host -ForegroundColor Green  "Total Number of Nodes on Parent VIP " $vip_info.IP "of" $Server ":"$PCount 
                                write-host -ForegroundColor Green  "Total Number of Available Nodes : "$AvailableNodePercent
                                write-host -ForegroundColor Green  "Total Nodes Availability Percent: "$nodeAvailPer "%" 
                                write-host -ForegroundColor Yellow "--------------------------------------------------------------------------"

                                $return1 = $true
                                
                            }
                            else 
                            {
                                Write-Host -ForegroundColor Red "Error: No Action perform as Total Node availability % is <= 60%. Please check manually from http://MyVips"
                                $return1 = $false
                            }     
                        }
                        catch
                        {
                            $return1 = $false
                            Write-host -ForegroundColor Red "Exception :" $Error[0].Exception
                            $host.SetShouldExit(1)
                            exit 1
                        }
                    }
                    elseif($Action -eq 'Resume(OnLine)')
                    {
                        Try
                        {
                            Write-host -ForegroundColor Green "1. Initiating Bring node [$($Server)] online process on https://MyVips."
                            #Resume-ITVipNode -VIP:$vip_info.IP -NodeIP:$IP.IPAddressToString -Port:443
                            Start-Sleep -Seconds 3
                            Write-host -ForegroundColor Green "2. Successfully Bring node [$($Server)] Online on https://MyVips."
                            write-host ""
                            Write-Host "Current node Health & Availability Status $(Get-date) :"
                            write-host -ForegroundColor Yellow "--------------------------------------------------------------------------"
                            write-host -ForegroundColor Green  "Total Number of Nodes on Parent VIP " $vip_info.IP "of" $Server ":"$PCount 
                            write-host -ForegroundColor Green  "Total Number of Available Nodes : "$AvailableNodePercent
                            write-host -ForegroundColor Green  "Total Nodes Availability Percent: "$nodeAvailPer "%" 
                            write-host -ForegroundColor Yellow "--------------------------------------------------------------------------"

                            $return1 = $true
                        }
                        catch
                        {
                            Write-host -ForegroundColor Red "Exception: Failed to bring node [$($Server)] online"
                            Write-host -ForegroundColor Red "Details: $($Error[0].Exception)"
                            $return1 = $false
                        }
                    }
                    else
                    {
                                write-host ""
                                Write-Host "1. Current node Health & Availability Status $(Get-date):"
                                write-host -ForegroundColor Yellow "--------------------------------------------------------------------------"
                                write-host -ForegroundColor Green  "Total Number of Nodes on Parent VIP " $vip_info.IP "of" $Server ":"$PCount 
                                write-host -ForegroundColor Green  "Total Number of Available Nodes : "$AvailableNodePercent
                                write-host -ForegroundColor Green  "Total Nodes Availability Percent: "$nodeAvailPer "%" 
                                write-host -ForegroundColor Yellow "--------------------------------------------------------------------------"
                                $return1 = $true                          
                                
                            }
                }
                else 
                {
                        if($node.UserNote -ne $null)
                        {
                            if((($node.UserNote).Trim() -eq ($Server.Substring(0,$Server.IndexOf('.'))).Trim()) -or (($node.UserNote).Trim() -eq $Server))
                            {
                                Write-host -BackgroundColor Cyan -ForegroundColor Red "Error:" $($Server)" IP not matching with MyVip Node "$($node.UserNote)" IP ["$($node.IPAddress)"]. Please check MyVip under ["$($OwnerGroupName)"] Parent VIP IP["$($vip_info.UserNote)"\"$($vip_info.IP)"]."
                                write-host ""
                                continue
                            }
                            continue
                        }
                continue
                }
            }
        }
    }
}
Catch
{
    $return1 = $false
    Write-host -ForegroundColor Red "Exception : "$Error[0].Exception
    #$host.SetShouldExit(1)
    #exit 1
    
}

$return1

write-host ""
Write-Host -ForegroundColor Yellow "---------------------------"
write-host "Stopping MyVIPs Opertaions."
Write-Host -ForegroundColor Yellow "---------------------------"
write-host ""
}
Function ServerComplainceCheck           {
Param([Parameter(Mandatory=$true, Position=0, HelpMessage="Provide the Server Name [FQDN]")] [string] $Server)
$GetDotNet={
    
    param ($Computer)
    Try
    {
        $dotNetRegistry  = 'SOFTWARE\Microsoft\NET Framework Setup\NDP'
        $dotNet4Registry = 'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
        $dotNet4Builds = 
        @{
	    30319  =  '.NET Framework 4.0'
	    378389 = '.NET Framework 4.5'
	    378675 = '.NET Framework 4.5.1 (8.1/2012R2)'
	    378758 = '.NET Framework 4.5.1 (8/7 SP1/Vista SP2)'
	    379893 = '.NET Framework 4.5.2' 
	    380042 = '.NET Framework 4.5 and later with KB3168275 rollup'
	    393295 = '.NET Framework 4.6 (Windows 10)'
	    393297 = '.NET Framework 4.6 (NON Windows 10)'
	    394254 = '.NET Framework 4.6.1 (Windows 10)'
	    394271 = '.NET Framework 4.6.1 (NON Windows 10)'
	    394802 = '.NET Framework 4.6.2 (Windows 10 Anniversary Update)'
	    394806 = '.NET Framework 4.6.2 (NON Windows 10)'
    }
	
        if($regKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $Computer)) 
        {
		if ($net4RegKey = $regKey.OpenSubKey("$dotNet4Registry")) 
        {
			if(-not ($net4Release = $net4RegKey.GetValue('Release'))) 
            {
				#$net4Release = 30319
			}
			    New-Object -TypeName PSObject -Property 
                @{
			        ComputerName = $Computer
			        NetFXBuild = $net4Release
			        NetFXVersion = $dotNet4Builds[$net4Release]
			     } | Select-Object ComputerName, NetFXVersion, NetFXBuild
		}
    }
    }
    Catch {$Error[0].Exception}
}
$GetIEVersion={
    param ($Computer)
    Try
    {
        [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',$Computer).OpenSubKey('SOFTWARE\Microsoft\Internet Explorer').GetValue('SvcVersion')
    }
    Catch {$Error[0].Exception.InnerException}
}
Try
{
        $IPaks = (Invoke-Command -ComputerName:$Server -ScriptBlock {Get-ChildItem "hklm:\software\microsoft\msnipak"| ForEach-Object {Get-ItemProperty $_.pspath | Select IPak, Version, InstalledDate,Release | Where IPak -ne $null}})
           $OS = (Invoke-Command -ComputerName:$Server -ScriptBlock {Get-WmiObject Win32_OperatingSystem | Select-Object Caption, OSArchitecture})
    $LstReboot = (Invoke-Command -ComputerName:$Server -ScriptBlock {$R = Get-WmiObject Win32_OperatingSystem; $R.ConvertToDateTime($R.LastBootUpTime)})
          $rdf = (Invoke-Command -ComputerName:$Server -ScriptBlock $GetDotNet -ArgumentList:$Server |Select NetFXVersion, NetFXBuild)
          $Dot = [string] $rdf.NetFXVersion +" (Build : " + $rdf.NetFXBuild + ")"
    $IEVersion = (Invoke-Command -ComputerName:$Server -ScriptBlock:$GetIEVersion -ArgumentList:$Server)
          $Ram = (Invoke-Command -ComputerName:$Server -ScriptBlock {Get-WmiObject -Class Win32_ComputerSystem|Select @{Name="TotalPhysicalMemory";Expression={[String][math]::round($_.TotalPhysicalMemory/1gb)+"GB"}}})	
          $Co  = (Invoke-Command -ComputerName:$Server -ScriptBlock {Get-WmiObject –class Win32_processor | select Name,NumberOfCores,NumberOfLogicalProcessors})
        $Core  = ($Co| Measure-Object -Property NumberOfCores -Sum |Select Count, Sum)
        $LCore = ($Co| Measure-Object -Property NumberOfLogicalProcessors -Sum |Select Sum)
        
    $Details =@()
    ForEach($Ipak in $Ipaks)
    {
        $Details += ($Ipak| select @{Name="ServerName";Expression ={$($Server.Substring(0,$Server.IndexOf('.')))}}, @{Name ="ServerEdition";Expression={$($OS.Caption)}}, 
          @{Name ="ServerBits";Expression={$($OS.OSArchitecture)}}, Ipak, Version, InstalledDate,Release,
           @{Name="ServerLastReboot"; Expression={$($LstReboot)}},
           @{Name="DotNetFramework"; Expression={$($Dot)}},
           @{NAme="IEVersion"; Expression={$($IEVersion)}},
           @{Name="CPU"; Expression ={$($Core.Count)}},
           @{Name="NumberOfCores"; Expression ={$($Core.Sum)}},
           @{Name="LogicalProcessor"; Expression ={$($LCore.Sum)}},
           @{Name="TotalPhysicalMemory"; Expression ={$($Ram.TotalPhysicalMemory)}}) 
    }
    
    $Details | Format-Table -AutoSize -GroupBy $ServerName
}
catch {$Error[0].Exception.Message}
}
Function CheckServiceHungStopStatus      {
<#
    .Description
     This will help to identify Service which were is Hung\Not Responding or Stop state, Also has feature to take correctiveaction
     either bt taking the node OOR & Recycling or without taking node OOR & service recycling.

     .Paramaters
      1. ServerName        : Need to specify the Server name indivual or multiple by implementing the Foreach loop.
      2. ServiceName       : Specify individual Service or Multiple with nested (Inside Server Foreach) Foreach loop.
      3. MemoryDump        : Has feature to generate/Ignore Memory dump by selecting the Yes\No Properties.
      4. RecycleRequire    : Also giving option to Start\Ignore service recycle by selecting properties as True\false.
      5. VipAction         : If want to take node OOR\Online on\before Service Recycle, select property value as OOR or Online.  
      6. VipGroupOwnerName : Specify the Owner VIP Name, Available on http:\\MyVips

      .Example
      CheckServiceHungStopStatus -ServerName 'Nitin_DellXPS' -ServiceName 'SQLSERVERAGENT' -MemoryDump No -VipAction OOR -VipGroupOwnerName 'mslt2' -RecycleRequire true
#>
Param([Parameter(Mandatory=$true, Position=0, HelpMessage="Provide Target Server Name")][string]$ServerName,
      [Parameter(Mandatory=$true, Position=1, HelpMessage="Provide Target Service Name")][string]$ServiceName,
      [Parameter(Mandatory=$false,Position=2, HelpMessage="Memory Dump needed")][validateset('Yes','No')][string]$MemoryDump,
      [Parameter(Mandatory=$false,Position=3, HelpMessage="Service Recycle needed")][validateset('true','false')][string]$RecycleRequire,
      [Parameter(Mandatory=$false,Position=4, HelpMessage="Want to Take Node OOR\Online if Service found Hung or Stop")][validateset('OOR','Online')][string]$VipAction,
      [Parameter(Mandatory=$false,Position=5, HelpMessage="MyVips GroupOwnerName from https://MyVips")][string]$VipGroupOwnerName)
write-host ""
Write-host '--------------------------------'
Write-host 'Starting Service Hung\Stop Check'
Write-host '--------------------------------'
write-host ""

$HungService   =  {
param($Srv)
    $retrun =@()
    $nProcesses = 'No'
        Try{
                $Query = -Join("Name LIKE ","'",($Srv).Trim(),"'")
                $P_ID = Get-WmiObject -Class Win32_Service -Filter $Query | Select-Object -ExpandProperty ProcessId
                $Processe = (Get-Process -Id $P_ID -EA Stop | Select Name, ID)
                $nProcesses = @($Processe | ? { $_.Responding -eq $false })
        }     
        Catch{
                Write-Error "Failed to query processes. $_"
        }
    
        If($nProcesses -ne 'No'){
                $response = $true
                $retrun = ($nProcesses | Select Name,@{Name='ID'; expression={$P_ID}}, @{Name='Response'; expression ={$response}})
        } #t Non-Responding
        else{
                $response = $false
                $retrun = ($Processe | Select Name,@{Name='ID'; expression={$P_ID}}, @{Name='Response'; expression ={$response}})
        } #f Responding
 $retrun 
 }
$PingMachine   =  {
Param([string]$MachineName)
    Try{
            $PingResult = Get-WmiObject win32_pingstatus -f "address = '$($MachineName)'" -EA SilentlyContinue
            if($PingResult.statuscode -eq 0) {$true} else {$false}
       }
  catch{
            Write-host -ForegroundColor Red "Exception: Ping request failed for [$($MachineName)]"
            write-host -ForegroundColor Red "Detail: $($Error[0].Exception.Message)"
       }
}
$DumpMemory    =  {
Param($file, $Proc_Id)
    $r = [System.Reflection.Assembly]::LoadFile('C:\PasswordMaintenance\DLLFiles\Memory\MemoryDump.dll') 
    Try{
            $fileobj = New-Object IO.FileStream($file, [IO.FileMode]::Create,[IO.FileAccess]::ReadWrite, [IO.FileShare]::Write) 
            $MStatus = ([MemoryDump.FullDump]::Write($fileobj.SafeFileHandle,$Proc_Id))

            if($MStatus -eq $true){Write-host -ForegroundColor Cyan ".......3.2 Success: Memory dump available at $($file).";write-host ""}
            else{Write-Host -ForegroundColor Red "Error: Not allowed to create on $($file)."}
       }
    catch{
            write-Host -ForegroundColor Red "Exception : $($Error[0].Exception.Message)"
    }
}

Write-Host ""
Write-Host -ForegroundColor Cyan "1. Trying to connect Server[$($ServerName)]."
Start-Sleep -s 3
$Status =@()

If((Invoke-Command -ComputerName $ServerName -ScriptBlock $PingMachine -ArgumentList (, $ServerName)))
{
    Write-Host -ForegroundColor Cyan "2. $($ServerName) Server Successfully connected and ready for operations."
    $Status = (Invoke-Command -ComputerName $ServerName -ScriptBlock $HungService -ArgumentList (,$ServiceName))

    If($Status.response -eq $false) #It should be True, putting as false for testing the flow
    {
        $Resp = "NotResponding"
        $DllChk = (Invoke-Command -ComputerName $ServerName -ScriptBlock {Get-ChildItem  D:\ | Where-Object {$_.Name -like '*MemoryDump.dll*'}})

        if(!$DllChk)
        {
            $destination = "\\"+$($ServerName)+"\D$\"
            Write-host -ForegroundColor Yellow "Information: Moving MemoryDump DLL file to destination [$($Destination)] location to perform Memory dump operation."
            Write-host ""
            
            Robocopy.exe "C:\PasswordMaintenance\DLLFiles\Memory\" $destination
        }

        $Path = "\\"+$($ServerName)+"\D$\MemoryDump\"; $dmp=$($Path)+$($ServiceName)+"_"+$(Get-Date -Format "ddMMyyyy_hhmmss")+".dmp";
        Write-Host -ForegroundColor Yellow "3. $($ServiceName) found in Hung\not responding state."

        If(!(Test-Path $Path))  
        {
            
            If ($MemoryDump -eq 'Yes')
            {
                Write-Host -ForegroundColor Green ".......3.1 Taking Service Memory Dump before recycling it. Dump will be available on $($path)."
                Invoke-Command -ComputerName $ServerName -ScriptBlock {if(!(Test-Path "D:\MemoryDump")){mkdir "D:\MemoryDump"}}
                
                Try
                {   
                    Invoke-Command -ComputerName $ServerName -ScriptBlock $DumpMemory -ArgumentList (,$dmp,$Status.ID) #Memory Dump
                }
                catch
                {
                    Write-host -ForegroundColor red "Exception: Uanble to generate Process Memory Dump for Server [$($ServiceName)] on Server [$($ServerName)]"
                    write-host -ForegroundColor Red "Detail: $($Error[0].Exception.Message)"
                }

                If($RecycleRequire -eq 'true') {
                    If($VipAction -eq 'OOR'){ $Action = 'Suspend(OOR)'} Elseif ($VipAction -eq 'Online') {$Action = 'Resume(OnLine)'} else {Write-Host "Invalid VIPs Choice (It should be OOR)"}
        
                    $VipStatus = (MyVIPsStatus -OwnerGroupName $VipGroupOwnerName -Server $ServerName -Action $Action)
                                                         
                    If($VipStatus -eq $true)
                    {
                        Write-host -ForegroundColor Red   "4. Taken node $($ServerName) from MyVips."
                        Write-host -ForegroundColor Green "5. Feature flag is True hence recycling ["$($ServiceName)"] on server [$($ServerName)]."
                        
                        Try
                        {
                            #Restart-Service -Name:$ServiceName -Force -ErrorAction SilentlyContinue
                            $ReChk = (Get-Service -Name $ServiceName -ComputerName $ServerName |  Select Name, Status)
                            Start-Sleep -s 10

                            If($ReChk.Status -eq "Running")
                            {
                                Write-host -ForegroundColor Green "6. $($ServiceNAme) Service successfully started on ["$($Server)"]."
                                $VipStatus = (MyVIPsStatus -OwnerGroupName $VipGroupOwnerName -Server $ServerName -Action 'Resume(OnLine)')
                                
                                If($VipStatus -eq $true)
                                {
                                    Write-host -ForegroundColor Green "7. Node [$($ServerName)] Putting back on Rotation on MyVips." 
                                }
                            }
                            else
                            {
                                    Write-host -ForegroundColor red "Exception : Failed to Restart [$($ServiceName)] on Server [$($ServerName)]." 
                                    Write-host -ForegroundColor red "Error Details : $($Error[0].Exception.Message)"
                            }
                        }
                        Catch
                        {
                            Write-host -ForegroundColor red "Exception: $($ServerName) fail to start"
                            Write-host -ForegroundColor red "Details: $($Error[0].Exception.Message)."
                            Write-host ""
                            Write-host -ForegroundColor Cyan "Gathering EventLog for [$($ServerName)], which may take 30 - 60 Secs."
                            Try
                            {
                                Get-EventLog -LogName Application -Newest 10 -EntryType Error #| Where {$_.Source -like "*$($ServiceName)*"}   
                                wait-event -sourceIdentifier "ProcessStarted" -timeout 10 #Timeout defined if it is taking more then 10 secs.      
                            }
                            catch
                            { 
                                Write-Warning "No Record found for Service [$($ServerName)] under Application EventLog on Server [$($ServerName)]"
                            }
                        }                                              
                     }
                } # Action Require
                Get-Service -Name $ServiceName -ComputerName:$ServerName |  Select Name, Status
            }
            else
            {
                    Write-Host -ForegroundColor Green "3.1 Not processing for Service Memory Dump." 
            }
        }
        
        elseif ((Test-Path $Path)) 
        {
            If ($MemoryDump -eq 'Yes')
            {
                Write-Host -ForegroundColor Green ".......3.1 Taking Service Memory Dump before recycling it. Dump will be available on $($ServerName)."
                Try
                {
                    Invoke-Command -ComputerName $ServerName -ScriptBlock $DumpMemory -ArgumentList (,$dmp,$Status.ID) #Memory Dump
                }
                catch
                {
                    Write-host -ForegroundColor red "Exception: Uanble to generate Process Memory Dump for Server [$($ServiceName)] on Server [$($ServerName)]"
                }

                 If($RecycleRequire -eq 'true') {
                    If($VipAction -eq 'OOR'){ $Action = 'Suspend(OOR)'} Elseif ($VipAction -eq 'Online') {$Action = 'Resume(OnLine)'} else {Write-Host "Invalid VIPs Choice (It should be OOR)"}
        
                    $VipStatus = (MyVIPsStatus -OwnerGroupName $VipGroupOwnerName -Server $ServerName -Action $Action)
                    
                    If($VipStatus -eq $true)
                    {
                        Write-host -ForegroundColor Red   "4. Taken node $($ServerName) from MyVips."
                        Write-host -ForegroundColor Green "5. Feature flag is True hence recycling ["$($ServiceName)"] on server [$($ServerName)]."
                        
                        Try
                        {
                            #Restart-Service -Name:$ServiceName -Force -ErrorAction SilentlyContinue
                            $ReChk = (Get-Service -Name $ServiceName -ComputerName $ServerName |  Select Name, Status)
                            Start-Sleep -s 10

                            If($ReChk.Status -eq "Running")
                            {
                                Write-host -ForegroundColor Green "6. $($ServiceNAme) Service successfully started on ["$($ServerName)"]."
                                $VipStatus = (MyVIPsStatus -OwnerGroupName $VipGroupOwnerName -Server $ServerName -Action 'Resume(OnLine)')
                                
                                If($VipStatus -eq $true)
                                {
                                    Write-host -ForegroundColor Green "7. Node [$($ServerName)] Putting back on Rotation on MyVips." 
                                }
                            }
                            else
                            {
                                    Write-host -ForegroundColor red "Exception : Failed to Restart [$($ServiceName)] on Server [$($ServerName)]." 
                                    Write-host -ForegroundColor red "Error Details : $($Error[0].Exception.Message)"
                            }
                        }
                        Catch
                        {
                            Write-host -ForegroundColor red "Exception: $($ServerName) fail to start"
                            Write-host -ForegroundColor red "Details: $($Error[0].Exception.Message)."
                            Write-host ""
                            Write-host -ForegroundColor Cyan "Gathering EventLog for [$($ServerName)], which may take 30 - 60 Secs."
                            Try
                            {
                                Get-EventLog -LogName Application -Newest 10 -EntryType Error | Where {$_.Source -like "*$($ServiceName)*"}         
                            }
                            catch
                            { 
                                Write-Warning "No Record found for Service [$($ServerName)] under Application EventLog on Server [$($ServerName)]"
                            }
                        }                                              
                     }
                } # Action Require
                 Get-Service -Name $ServiceName -ComputerName $ServerName |  Select Name, Status
            }
            else
            {
                    Write-Host -ForegroundColor Green "3.1 Not processing for Service Memory Dump." 
            }
        }
        
        elseIf($RecycleRequire -eq 'true') 
        {
                    If($VipAction -eq 'OOR'){ $Action = 'Suspend(OOR)'} Elseif ($VipAction -eq 'Online') {$Action = 'Resume(OnLine)'} else {Write-Host "Invalid VIPs Choice (It should be OOR)"}
        
                    $VipStatus = (MyVIPsStatus -OwnerGroupName $VipGroupOwnerName -Server $ServerName -Action $Action)
                    
                    If($VipStatus -eq $true)
                    {
                        Write-host -ForegroundColor Red   "4. Taken node out of rotation $($ServerName) from MyVips."
                        Write-host -ForegroundColor Green "5. Feature flag is ON hence initiating the recycling for service ["$($ServiceName)"] on server [$($ServerName)]."
                        
                        Try
                        {
                            #Restart-Service -Name:$ServiceName -Force -ErrorAction SilentlyContinue
                            $ReChk = (Get-Service -Name $ServiceName -ComputerName $ServerName |  Select Name, Status)
                            Start-Sleep -s 10

                            If($ReChk.Status -eq "Running")
                            {
                                Write-host -ForegroundColor Green "6. $($ServiceNAme) Service successfully started on ["$($ServerName)"]."
                                $VipStatus = (MyVIPsStatus -OwnerGroupName $VipGroupOwnerName -Server $ServerName -Action 'Resume(OnLine)')
                                
                                If($VipStatus -eq $true)
                                {
                                    Write-host -ForegroundColor Green "7. Putting back Node [$($ServerName)] on Rotation\Online on MyVips." 
                                    write-host ""
                                    Get-Service -Name $ServiceName -ComputerName $ServerName
                                }
                            }
                            else
                            {
                                    Write-host -ForegroundColor red "Exception : Failed to Restart [$($ServiceName)] service on Server [$($ServerName)]." 
                                    Write-host -ForegroundColor red "Details : $($Error[0].Exception.Message)"
                            }
                        }
                        Catch
                        {
                            Write-host -ForegroundColor red "Exception: $($ServerName) fail to start"
                            Write-host -ForegroundColor red "Details: $($Error[0].Exception.Message)."
                            Write-host ""
                            Write-host -ForegroundColor Cyan "Gathering EventLog for [$($ServiceName)] service on $($ServerName), which may take 30 - 60 Secs. based on network load."
                            Try
                            {
                                Get-EventLog -LogName Application -Newest 10 -EntryType Error | Where {$_.Source -like "*$($ServiceName)*"}         
                            }
                            catch
                            { 
                                Write-Warning "No Record found for Service [$($ServerName)] under Application EventLog on Server [$($ServerName)]"
                                Write-host -ForegroundColor Red "Details: $($Error[0].Exception.Message)"
                            }
                        }                                              
                     }
                } # Action Require

        $flag = 1
        
    }
    elseif($Status.response -eq $true)
    {
        $Resp = "Responding";$Path = "N/A"
    }
    else
    {
        $rc += (Get-Service -Name $ServiceName -ComputerName $ServerName | Select Name, Status, MachineName, @{Name="ServiceHungStatus";Expression={$($Resp)}}, 
        @{Name="MemoryDump";Expression={$($dmp)}}) 

        if($rc[($rc.Count)-1].Status -eq "Stopped")
        {
            $Stopflag = 1
            Write-host -ForegroundColor Red "3. Service [$($ServiceName)] found in stop state on Server.......$($ServerName)."
            
            If($RecycleRequire -eq 'true') {
                    If($VipAction -eq 'OOR'){ $Action = 'Suspend(OOR)'} Elseif ($VipAction -eq 'Online') {$Action = 'Resume(OnLine)'} else {Write-Host "Invalid VIPs Choice (It should be OOR)"}
        
                    $VipStatus = (MyVIPsStatus -OwnerGroupName $VipGroupOwnerName -Server $ServerName -Action $Action)
                    
                    If($VipStatus -eq $true)
                    {
                        Write-host -ForegroundColor Red   "4. Taken node $($ServerName) from MyVips."
                        Write-host -ForegroundColor Green "5. Feature flag is True hence recycling ["$($ServiceName)"] on server [$($ServerName)]."
                        
                        Try
                        {
                            #Restart-Service -Name:$ServiceName -Force -ErrorAction SilentlyContinue
                            $ReChk = (Get-Service -Name $ServiceName -ComputerName $ServerName |  Select Name, Status)
                            Start-Sleep -s 10

                            If($ReChk.Status -eq "Running")
                            {
                                Write-host -ForegroundColor Green "6. $($ServiceNAme) Service successfully started on ["$($Server)"]."
                                $VipStatus = (MyVIPsStatus -OwnerGroupName $VipGroupOwnerName -Server $ServerName -Action 'Resume(OnLine)')
                                
                                If($VipStatus -eq $true)
                                {
                                    Write-host -ForegroundColor Green "7. Node [$($ServerName)] Putting back on Rotation on MyVips." 
                                }
                            }
                            else
                            {
                                    Write-host -ForegroundColor red "Exception : Failed to Restart [$($ServiceName)] on Server [$($ServerName)]." 
                                    Write-host -ForegroundColor red "Error Details : $($Error[0].Exception.Message)"
                            }
                        }
                        Catch
                        {
                            Write-host -ForegroundColor red "Exception: $($ServerName) fail to start"
                            Write-host -ForegroundColor red "Details: $($Error[0].Exception.Message)."
                            Write-host ""
                            Write-host -ForegroundColor Cyan "Gathering EventLog for [$($ServerName)], which may take 30 - 60 Secs."
                            Try
                            {
                                Get-EventLog -LogName Application -Newest 10 -EntryType Error | Where {$_.Source -like "*$($ServiceName)*"}         
                            }
                            catch
                            { 
                                Write-Warning "No Record found for Service [$($ServerName)] under Application EventLog on Server [$($ServerName)]"
                            }
                        }                                              
                     }
                } # Action Require
            Get-Service -Name $ServiceName -ComputerName $ServerName |  Select Name, Status
        }
        else
        {
            Write-host -ForegroundColor Green "$($ServiceName) running fine on server.......[$($ServerName)]"
        }
    }

}
else
{
     Write-host -ForegroundColor red "Error : $($ServerName) is not reachable, please check connectivity and try again."
}


    if($ServiceName -like '*SQL*')
    {
        $SQLBVTResult = (SQLBVT -ServerName $ServerName)
        If ($SQLBVTResult -eq $true)
        {
            Write-host -ForegroundColor Green "Success: SQL BVT for all nodes related to server $($ServerName) completed successfully."        
        }
        else
        {
            Write-host -ForegroundColor red "Failed: SQL BVT for one or more nodes related to server $($ServerName) are failed."
        }
    }

write-host ""
Write-host '--------------------------------'
Write-host 'Stopping Service Hung\Stop Check'
Write-host '--------------------------------'
write-host ""

}
Function ConnectivityCheck               {
param([Parameter(Mandatory=$true, Position=0, HelpMessage="Provide Target Server Name")][string]$server)

Try 
    {
            $flag = 0
            
            Write-host "Connectivity Test : " -NoNewline
            Write-host -ForegroundColor:red $server 
            write-host ""
        
        Try{
        $res = [net.dns]::Resolve($Server)
        }catch{$Error[0].Exception.GetBaseException()}
         
        If($res.HostName -ne $Null){
        Write-host -ForegroundColor:Green "1. DNS Name Resolution is successful"}
        else{
        $Flag = 5;write-host -ForegroundColor:red "1. DNS Name Resolution is failed"
        $FailMsg += "<Li>DNS Name Resolution is failed</Li>"}

        $PingResult = Get-WmiObject win32_pingstatus -f "address='$Server'" -EA Continue

        If($PingResult.statuscode -eq 0){
        Write-host -ForegroundColor:Green "2. Ping response is successful"}   
        else{
        $flag = 1; write-host -ForegroundColor:red "2. Ping response is failed"
        $FailMsg += "<Li>Ping response is failed</Li>"} 
            
            $type   = [Microsoft.Win32.RegistryHive]::LocalMachine
            $regkey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($type, $server)
            $subkey = $regKey.OpenSubKey($key)
            $r1= $regkey.GetSubKeyNames()
    
        if($r1.Count -gt 0){
        write-host -ForegroundColor:Green "3. Remote registry call successful"}
        else{
        $flag = 2; write-host -ForegroundColor:red "3. Remote registry call failed"
        $FailMsg += "<Li>Remote registry call failed</Li>"}

            $r2 = (Test-NetConnection -ComputerName $server -CommonTCPPort RDP -EA Continue) 
        
        if($r2.TcpTestSucceeded -eq $true){
        Write-Host -ForegroundColor:Green "4. RDP session call successful"}
        else{
        $flag = 3; write-host -ForegroundColor:red "4. RDP seesion failed"
        $FailMsg += "<Li>RDP seesion failed</Li>"} 

            $Wmi = (gwmi win32_bios -ComputerName $server -EA Continue)

        if($wmi){
        Write-Host -ForegroundColor:Green "5. WMI call successful"}
        else{
        $flag = 4; write-host -ForegroundColor:red "5. WMI call failed"
        $FailMsg += "<Li>WMI call failed</Li>"} 

             
    } 
        Catch{
       write-host -ForegroundColor Red -NoNewline
       "Cannot access registry on {0}. Error: {1:x}" -f $server, $_.Exception.HResult
    }

    if($flag -gt 0) {Write-Host -ForegroundColor Red "Error: Connectivity Test Failed"; $false} else {Write-Host -ForegroundColor Green " Connectivity Test Successful"; $true}
}
Function SQLBVT                          {
<#
    .Description:
     This Module will help to perform complete SQL server related validation for both (Standalone or AO Cluster). No need to provide 
     the listener name, any individual node will work fine and synamically will pull all relevent information.
     - AO Health
     - DB Health
     - Service status across nodes
     - Cluster Health & Dependency Expression etc. 

    .Parameter:
     ServerName      : Accepting Server Name as parameter. It should be any node of your cluster\AO group

    .Example
     SQLBVT -ServerName 'I02BU2BSQLCLT01.partners.extranet.microsoft.com'

    .In case of multiple servers:
     ----------------------------

     $ServerList = Get-Content "E:\Automation\Servers.txt" #Server List (FQDN) or Ensure DNS Suffix Search List upto date
     ForEach($Svr in $ServerList)
     {
            $SQLService = Get-Service -ComputerName $Svr | Select Name | Where {$_.Name -like '*SQL*'}   
            If ($SQLService -ne $null)
            {
                $r = SQLBVT -ServerName $Svr -EA continue
                $SQLBVTStatus = ($r | select-string -Pattern "True" -CaseSensitive).ToString()
  
                If ($SQLBVTStatus -eq "True")
                {
                    Write-host -foreground Green "Success: $($Srv) SQL BVT complted successfully - $(Get-Date)"        
                    #$r - Uncomment if you want to see the result set
                }
                else {Write-host -foreground Red "Failed: $($Srv) SQL BVT Failed with Exception - $(Get-Date)" }       
            }   
            else 
            {
                Write-Warning "This is not a SQL Machine, no SQL BVT Performed."
            }
     }
#>
param (
[Parameter(Mandatory=$true, Position=0, HelpMessage='Please provide the SQL Listiner Name')] [string] $ServerName)   

    $SQLStatus = Get-Service -ComputerName $ServerName | ? {$_.name -eq 'MSSQLSERVER'}
    
    If($SQLStatus.Status -eq 'Running')
    {
        $SrvcName =@{label="Service Name" ;alignment="left" ;width=20 ; Expression={$_.Name};};
        $SrvcMode =@{label="Start Mode" ;alignment="left" ;width=20 ;Expression={$_.StartMode};};
        $SrvcState =@{label="State" ;alignment="left" ;width=20 ;Expression={$_.State};};
        $SrvcMsg =@{label="Message" ;alignment="left" ;width=50 ; `
    Expression={ if ($_.State -ne "Running") {"Alarm: Stopped"} else {"OK"} };};
        $Rows = $null;  $i = 1; $DT =@()

        Try
        {
        Function ExecuteSqlQuery ($Query, $Server) 
        { 
            Try
                                                                {
            $Datatable = New-Object System.Data.DataTable 
            $conn = New-Object System.Data.SqlClient.SqlConnection("Data Source="+$($server)+";Integrated Security=SSPI;Initial Catalog=master")
            $conn.Open()
    
            $Command = New-Object System.Data.SQLClient.SQLCommand 
            $Command.Connection = $conn 
            $Command.CommandText = $Query

            $DataAdapter = new-object System.Data.SqlClient.SqlDataAdapter $Command 
            $Dataset = new-object System.Data.Dataset 
            $DataAdapter.Fill($Dataset) 
            $conn.Close() 
            
        }
            catch
            {
                Write-host -ForegroundColor red "SQL Exception: Connection Failure on $($Server)."
                Write-host -ForegroundColor red "Details: $($Error[0].Exception.Message)."
                $conn.Close()
                $false
            }
            return $Dataset.Tables[0] 
        } 

        $Query = "select SERVERPROPERTY ('IsHadrEnabled') as Status"; $IsserverAGEnabled = ExecuteSqlQuery -Query $Query -Server $ServerName
        
        If($IsserverAGEnabled.Status -eq 1)
        {
            $SQLList = ExecuteSqlQuery -Query $("Select dns_name [ListenerName] from sys.availability_group_listeners") -Server $ServerName
            $HostName1 = [net.dns]::Resolve($SQLList.ListenerName)
            $SQLListinerFQDN = [string]$HostName1.HostName
            
            $SQL   = "	SELECT 'Node' AS SITE, R.REPLICA_SERVER_NAME [NODE] FROM SYS.AVAILABILITY_REPLICAS  R JOIN SYS.DM_HADR_AVAILABILITY_REPLICA_STATES  RS ON R.REPLICA_ID = RS.REPLICA_ID LEFT OUTER JOIN SYS.DM_HADR_CLUSTER_MEMBERS CM
	ON CM.MEMBER_NAME = R.REPLICA_SERVER_NAME WHERE CM.NUMBER_OF_QUORUM_VOTES = 1 UNION ALL SELECT 'DRNode' AS SITE, R.REPLICA_SERVER_NAME [NODE]FROM SYS.AVAILABILITY_REPLICAS  R 
	JOIN SYS.DM_HADR_AVAILABILITY_REPLICA_STATES  RS ON R.REPLICA_ID = RS.REPLICA_ID LEFT OUTER JOIN SYS.DM_HADR_CLUSTER_MEMBERS CM
	ON CM.MEMBER_NAME = R.REPLICA_SERVER_NAME WHERE CM.NUMBER_OF_QUORUM_VOTES = 0 UNION ALL SELECT 'CURRENTPRIMARYNODE' AS SITE, RCS.REPLICA_SERVER_NAME [NODE]
	FROM SYS.AVAILABILITY_GROUPS_CLUSTER AS AGC INNER JOIN SYS.DM_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES AS RCS ON RCS.GROUP_ID = AGC.GROUP_ID
	INNER JOIN SYS.DM_HADR_AVAILABILITY_REPLICA_STATES AS ARS ON ARS.REPLICA_ID = RCS.REPLICA_ID INNER JOIN SYS.AVAILABILITY_GROUP_LISTENERS AS AGL
	ON AGL.GROUP_ID = ARS.GROUP_ID WHERE ARS.ROLE_DESC = 'PRIMARY' UNION ALL Select 'ListenerName' as site, dns_name [ListenerName] from sys.availability_group_listeners
	UNION ALL SELECT 'CLUSTERNAME' AS SITE, CLUSTER_NAME [NODE] FROM SYS.DM_HADR_CLUSTER
	UNION ALL SELECT 'AGNAME' AS SITE , NAME AS [NODE] FROM SYS.AVAILABILITY_GROUPS_CLUSTER
	UNION ALL SELECT 'OSVersion' AS SITE, windows_release FROM sys.dm_os_windows_info
	UNION ALL SELECT 'Domain' AS SITE, DEFAULT_DOMAIN()[DomainName]
	UNION ALL SELECT 'QuorumType' as Site, quorum_type_desc from sys.dm_hadr_cluster
	union all SELECT 'SQL Server' as Site,'SQL Server '+cast(SERVERPROPERTY('productversion')as varchar(20))
	union all SELECT 'SQL SP' as site, SERVERPROPERTY ('productlevel')
	union all SELECT 'SQL Edition' as site, SERVERPROPERTY ('edition')"; $Rows   = ExecuteSqlQuery -Query $SQL   -Server $SQLListinerFQDN
            $AGSQL = "select r.replica_server_name [Nodes], rs.role_desc [AGRole], r.failover_mode_desc [FailoverMode], r.availability_mode_desc [AvailabilityMode], rs.synchronization_health_desc [Health], cm.number_of_quorum_votes [QuorumVotes]
    from sys.availability_replicas  r join sys.dm_hadr_availability_replica_states  rs on r.replica_id = rs.replica_id left outer join sys.dm_hadr_cluster_members cm
    on cm.member_name = r.replica_server_name"; $AGRows = ExecuteSqlQuery -Query $AGSQL -Server $SQLListinerFQDN
            $DBSQL = "select r.replica_server_name [Node], d.name [Database], drs.synchronization_state_desc [DBState], drcs.is_failover_ready [IsFailoverReady] from sys.dm_hadr_database_replica_states drs
              join sys.databases d on drs.database_id = d.database_id join sys.availability_replicas  r on r.replica_id = drs.replica_id join sys.dm_hadr_database_replica_cluster_states drcs
              on drcs.replica_id = r.replica_id and drcs.database_name = d.name where drs.synchronization_state_desc = 'SYNCHRONIZED'
              order by 1, 2"; $DBRows = ExecuteSqlQuery -Query $DBSQL -Server $SQLListinerFQDN
        
            Write-host "******************************************************************"
            Write-host "Initiating SQL BVT for [$($SQLListinerFQDN)]                      "
            Write-host "******************************************************************"
            Write-host ""   
            Write-host -ForegroundColor cyan "1. Pulling SQL Server [$($SQLListinerFQDN)] System Configuration Details.                            " 
   
            ForEach($row in $Rows){ $DT +=($Rows[$i]);$i+=1} #Pulling SQL Infra Details
       
            $PrimaryNode = $DT | Select Site, Node | where {$_.Site -eq 'CURRENTPRIMARYNODE'}
            $ClusterName  = $DT | Select Site, Node | where {$_.Site -eq 'CLUSTERNAME'}

            #Write-host -ForegroundColor Cyan "Active Primary Node : $($PrimaryNode.Node )"
            $DT | Select Site, Node | Format-table -AutoSize

            Write-host -ForegroundColor cyan "2. Pulling SQL Server [$($SQLListinerFQDN)] AG Health Status." 
            $AGRows | select Nodes, AGRole,FailoverMode, AvailabilityMode, Health, QuorumVotes | format-table -autosize #Pulling SQL AG Details
    
            Write-host -ForegroundColor cyan "3. Pulling SQL Server [$($SQLListinerFQDN)] AlwaysON Database Health Status." 
            $DBRows | Select Node, Database, DBState,IsFailoverReady | format-table -autosize # DB Health
                
            Write-host -ForegroundColor cyan "4. Pulling SQL Server [$($SQLListinerFQDN)] Service Health Status of each connected nodes." 
            $i = 0
            write-host ""
            Foreach($r in $AGRows)
            {
                if($r.Nodes -ne $null)
                {
                    $i = $i+ 1
                    write-host -ForegroundColor cyan "********4.$($i) Pulling $($r.Nodes) Server Service Status."
                    try    
                    {    
                        $srvc = Get-WmiObject -query "SELECT * FROM win32_service WHERE name LIKE '%MSSQL%' OR name LIKE '%SQL%'" -computername $r.Nodes | Sort-Object -property name;
                        $srvc | Format-Table $SrvcName, $SrvcMode, $SrvcState, $SrvcMsg -AutoSize 
                    
                    }
                    catch
                    {
                        write-host -ForegroundColor red "Error: $($r.Nodes) unable to connect"; return $false
                    }
                }
            }

            write-host ""
            
            #Get Cluster Details
            Write-Host -ForegroundColor cyan "5. Pulling [$($SQLListinerFQDN)\$($ClusterName.Node)] Cluster Health Status:"
            write-host ""
            
            Try
            {
                Get-Cluster -Name $ClusterName.Node
                Get-ClusterNode -Cluster:$ClusterName.Node | select NodeName, NodeWeight,State | Format-table -AutoSize
                $RG = @(Get-ClusterResource -Cluster:$ClusterName.Node | Get-ClusterOwnerNode)
                $RS = @(Get-ClusterResource -Cluster:$ClusterName.Node | Select  Name, OwnerNode,State)

                $ClsuterDependency =@()
                Write-Host -ForegroundColor cyan "6. Pulling Cluster Resource Node Ownership and Resource State:"
                $j = 0     
                
                ForEach($r in $RG)
                {   
                    ForEach($G in $RS)
                    {
                        if($r.ClusterObject -eq $g.Name)
                        {
                            $j= $J+1
                            if($g.State -eq 'Online')
                            {
                                write-host -ForegroundColor Green "*******6.$($j) ClusterResource`t - $($r.ClusterObject):`tOwnerNodes {$($r.OwnerNodes)} ---> Resource State : $($g.state)"
                            }
                            else
                            {
                                write-host -ForegroundColor Red "*******6.$($j) ClusterResource`t - $($r.ClusterObject):`tOwnerNodes {$($r.OwnerNodes)} ---> Resource State : $($g.state)"
                            }
                        }
                    }
                    
                    $ClsuterDependency += Get-ClusterResourceDependency -Cluster $ClusterName.Node -Resource $([string]$r.ClusterObject)
                }
             
                Write-Host -ForegroundColor cyan "7. Gathering Cluster Resource Dependency Expression :"
                $ClsuterDependency | Format-Table -AutoSize       
            }
            catch 
            {
                Write-host -foregroundColor red "Exception: CLuster [$($ClusterName.Node)] unable to connect."
                Write-host -foregroundColor red "Details: $($Error[0].Exception.Message)."
                return $false
            } 
    }
        else
        {
            Write-host "Standalone Machine {$($ServerName)}"
            write-host "-------------------------------------"
            write-host ""

            $StandQuery = "select 'SQLNetworkName' as Property, Value = @@servername union all Select 'IsClustered' as Property, Value =CAST( SERVERPROPERTY('IsClustered') AS NVARCHAR(128))
            union all Select 'ComputerNamePhysicalNetBIOS' as Property, Value = CAST( SERVERPROPERTY('ComputerNamePhysicalNetBIOS')AS NVARCHAR(128))
            union all Select 'Edition' as Property, Value = serverproperty('edition')
            union all Select 'Servicepack' as Property, Value = serverproperty('productlevel') 
            union all Select 'InstanceName' as Property, Value = CAST( SERVERPROPERTY('InstanceName') AS NVARCHAR(128))
            union all Select 'ProductVersion' as Property, Value = SERVERPROPERTY('Productversion') 
            Union all Select 'Serverversion' as Property, Value = @@version"; $StandardSQLProperties = ExecuteSqlQuery -Query $StandQuery -Server $ServerName
            $SQLAgentStatus = ExecuteSqlQuery -Query "exec xp_servicecontrol N'querystate',N'SQLServerAGENT'" -Server $ServerName
            $DBStatus = "select name,state_desc from sys.databases"; $DBs = ExecuteSqlQuery -Query $DBStatus -Server $ServerName

            Write-host -ForegroundColor Cyan "Information: Pull SQL Server [$($ServerName)] Properties."
            write-host -ForegroundColor Cyan "-----------------------------------------------------------"
                       
            forEach($StandardSQLPropertie in $StandardSQLProperties) { $DT +=($StandardSQLProperties[$i]);$i+=1}
            $DT | Select Property, Value | Format-Table -AutoSize -HideTableHeaders
            Write-host ""
            Write-host "SQLAgent Status : $($SQLAgentStatus.'Current Service State')"

            Write-host -ForegroundColor Cyan "Database Status on [$ServerName]"
            write-host -ForegroundColor Cyan "----------------------------------"
            $DBs | Select Name, State_Desc | Format-Table -AutoSize -HideTableHeaders 
        
        
        }
    }
        catch
        {
        Write-host -ForegroundColor red "SQL Exception: Connection Failure on $($ServerName)."
        Write-Host -ForegroundColor red "Details: $($Error[0].Exception.Message)"
        return $false; 
        
    }
    
        write-host ""
        write-host -ForegroundColor Green "SQL BVT Completed Successfully - $(Get-Date)"
        write-host ""
        Write-host "******************************************************************"
        Write-host "Ending SQL BVT for [$($SQLListinerFQDN)]                          "
        Write-host "******************************************************************"

        return $true
    }
    else
    {
        Write-Warning "SQLServer Service is in Stop State on {$($ServerName)}."
        return $False
    }
}
Function SCOMMaintenance                 { 
<#
    .DESCRIPTION
     This will help you to perform SCOM operations which include, putting server in maintenance mode and removing it from maintenance mode.
     Also has option to define the maintenance periord in minutes.

    .PARAMETER
       - SERVERNAME        - Accepting Server name [FQDN]
       - MAINTENANCE MODE  - It should be either Enable (Putting in maintenance mode) or Disable (Removing it from maintenance mode).
       - AZUREACCOUNT      - Azure credentials to connect Azure portal and pull require credentials.
       - KEYVAULTNAME      - Default selection would be 'VLServiceAccounts' for all EC related service accounts & passwords (Account should exist on AKV). 

    .EXAMPLE
     SCOMMaintenance -ServerName 'ph1mslwb50.partners.extranet.microsoft.com' -MaintenanceMode Disable -AzureAccount 'nitinkg@microsoft.com' -KeyVaultName VLServiceAccounts
     SCOMMaintenance -ServerName 'ph1mslwb50.partners.extranet.microsoft.com' -MaintenanceMode Enable -AzureAccount 'nitinkg@microsoft.com' -KeyVaultName VLServiceAccounts
#>
 Param
 ([Parameter(Mandatory=$true, Position=0)][string]$ServerName,
           [Parameter(Mandatory=$true, Position=1)][ValidateSet('Enable', 'Disable')] [string]$MaintenanceMode,
           [Parameter(Mandatory=$true, Position=2)][String] $AzureAccount,
           [Parameter(Mandatory=$true, Position=3)][ValidateSet('VLServiceAccounts')] [string]$KeyVaultName) #Default for EC if you have other, include by seperating with comma
 Function AzureLogin {
    Param($AzureSubAdmin, $VaultName)
    #Default Values for EC
    $Password      = Read-Host "Enter Password for Account {$($AzureSubAdmin)}: " -AsSecureString
    $ResourceGrp   = 'KeyValut2storeVLPwds'
    $AzureCredentials = [System.Management.Automation.PSCredential]::new($AzureSubAdmin, $Password)

    Write-host -ForegroundColor Cyan '1. Connecting to Azure Key Vault.'
    Login-AzureRmAccount -Credential $AzureCredentials -EA SilentlyContinue
    
    Try   
    {if((Get-AzureRmContext -ErrorAction SilentlyContinue).Tenant -eq $null)
     {throw;}
    }
    catch
    {Login-AzureRmAccount -ErrorAction Stop
     Try{
            if((Get-AzureRmContext -ErrorAction SilentlyContinue).Tenant -eq $null)
            {throw;}}
        catch{
            Write-Error "Failed to provide Azure Account or unable to retrieve ARM Context. Please try again.";
            return $false;}}

    Try   
    {
    $sub_name = 'ECIT Production Monitoring'; 
    $sub_id = Get-AzureRMSubscription -SubscriptionName $sub_name; 
    Set-AzureRmContext -SubscriptionId $sub_id.subscriptionid
    Write-host -ForegroundColor Cyan '2. Pulling Vault {'$($VaultName)'} by connecting Subscriptio {'$($sub_name)'}.'
    } 
    catch{ Write-host -ForegroundColor Red "Error: Subscription {$($sub_name)} Not Found."; return $false;}

    Try   
    {Set-AzureRmKeyVaultAccessPolicy -VaultName $VaultName -ResourceGroupName $ResourceGrp -UserPrincipalName $AzureSubAdmin -PermissionsToSecrets all
     Write-host -ForegroundColor Cyan '3. Setting permission to Azure Account {'$($AzureSubAdmin)'}.'
    }
    catch 
    {Write-host -ForegroundColor Red "Error: Failed to assign permission to Azure Account {$($AzureSubAdmin)}. Please check with Subscription Owner for more details"; return $false;}

}
 $STARTSERVERSCOMMAINTENANCE ={
    Param([STRING] $SERVERNAME)
    [STRING]$MESSAGE = "PUTTING: $SERVERNAME INTO MAINTENANCE MODE VIA AUTOMATION"
    [INT]$MAINTMODEINMINUTES = '15'; #WE CAN CONTROL THE MAINTENANCE DURATION (DEFAULT VALUE : 60 MINS.)

    CD "D:\PROGRAM FILES\MICROSOFT SYSTEM CENTER 2012 R2\POWERSHELL\OPERATIONSMANAGER"

    IMPORT-MODULE OPERATIONSMANAGER
    Write-host -ForegroundColor Cyan '7. Connect Successfully with SCOM Management Server.'

    $FUNCNAME = 'FUNC - START-SERVERSCOMMAINTENANCE:'
    IF(GET-COMMAND -NAME 'GET-SCOMCLASSINSTANCE') 
    {
        $SERVER = (GET-SCOMCLASSINSTANCE -DISPLAYNAME "$SERVERNAME*") | SELECT -FIRST 1 | SELECT -EXPANDPROPERTY DISPLAYNAME
        if($SERVER -eq $null){Write-host -ForegroundColor Red "Error: $($ServerName) not available in SCOM"; return}
        $SCOMMANAGEMENTSERVERS = (GET-SCOMMANAGEMENTSERVER).DISPLAYNAME
        
        IF($SCOMMANAGEMENTSERVERS -CCONTAINS $SERVER)
        {WRITE-WARNING "$($FUNCNAME) Contains A Management Server $($SERVER).. You Cannot put A Management Server into Maintenance Mdde!!!"}
        ELSE
        {
                $TIME = ((GET-DATE).ADDMINUTES($MAINTMODEINMINUTES))
                $SERVERCLASSIDS = GET-SCOMCLASSINSTANCE -DISPLAYNAME $SERVER
                FOREACH($CLASSID IN $SERVERCLASSIDS)
                {
                        $SERVER1 = GET-SCOMCLASSINSTANCE -ID ($CLASSID.ID) | WHERE-OBJECT{$_.DISPLAYNAME -MATCH $SERVER}
                        WRITE-HOST -ForegroundColor Cyan "8. $($FUNCNAME) Putting $($SERVER1.ID) In Mainteance Mode Server {$($SERVER1.DISPLAYNAME)}."
                        IF(!(GET-SCOMMAINTENANCEMODE -INSTANCE $CLASSID)){
                            START-SCOMMAINTENANCEMODE -INSTANCE $SERVER1 -ENDTIME $TIME -REASON PLANNEDOTHER -COMMENT $MESSAGE
                            Write-host -ForegroundColor Cyan "9. Putting {$($SERVER1.DISPLAYNAME)} In Maintenance Mode Till : $TIME"}
                        ELSE{ $FLAG = $SERVER1.DISPLAYNAME +" Already Been Placed Into Maintenance Mode."}
                    }}}
                ELSE{ WRITE-HOST -ForegroundColor Red "$($FUNCNAME) Doesn't Have the OperationManager Module Imported for this Session"} 
                $FLAG
}
 $STOPSERVERSCOMMAINTENANCE = {
    PARAM([STRING] $SERVERNAME)
    [STRING]$MESSAGE = "Removing Server {$($SERVERNAME)} from Maintenance Mode -- $(Get-Date)"

    $FUNCNAME = 'FUNC - STOP-SERVERSCOMMAINTENANCE:'
    CD "D:\PROGRAM FILES\MICROSOFT SYSTEM CENTER 2012 R2\POWERSHELL\OPERATIONSMANAGER"  #LOCATION OF POWERSHELL MODULE ON SCOM SERVER 
    IMPORT-MODULE OPERATIONSMANAGER
    
    Write-host -ForegroundColor Cyan '7. Connect Successfully with SCOM Management Server.'
    
    IF(GET-COMMAND -NAME 'GET-SCOMCLASSINSTANCE')
    {
        $SERVER = (GET-SCOMCLASSINSTANCE -DISPLAYNAME "$SERVERNAME*") | SELECT -FIRST 1 | SELECT -EXPANDPROPERTY DISPLAYNAME
        if($SERVER -eq $null){Write-host -ForegroundColor Red "Error: $($ServerName) not available in SCOM"; return}
        $SCOMMANAGEMENTSERVERS = (GET-SCOMMANAGEMENTSERVER).DISPLAYNAME
        IF($SCOMMANAGEMENTSERVERS -CCONTAINS $SERVER)
        {WRITE-WARNING "$($FUNCNAME) Contains a Management Server $($SERVER)..You Cannot put a Management Server into Maintenance Mode!!!"}
        ELSE
        {
            $SERVERCLASSIDS = GET-SCOMCLASSINSTANCE -DISPLAYNAME $SERVER
            $TIME = (GET-DATE)
            FOREACH($CLASSID IN $SERVERCLASSIDS)
            {
                $SERVER1 = GET-SCOMCLASSINSTANCE -ID ($CLASSID.ID) | WHERE-OBJECT{$_.DISPLAYNAME -MATCH $SERVER}
                Write-host -ForegroundColor Cyan "8. Removing $($SERVER1.DISPLAYNAME) From Maintenance Mode @ $($TIME)"
                Try{               
                $RESULT = (GET-SCOMCLASSINSTANCE -ID ($CLASSID.ID)|WHERE-OBJECT{$_.DISPLAYNAME -LIKE "$SERVERNAME*"}).STOPMAINTENANCEMODE((GET-DATE).TOUNIVERSALTIME())
                }
                catch{Write-host -ForegroundColor Red "Error: Operation Failed : $($Error[0].Exception.Message)."}
            }}}
        ELSE
        { WRITE-HOST -ForegroundColor Red "Error: $($FUNCNAME) Doesn't have the OperationManager Module Imported for this Session."}
        
}

Write-host ""
Write-host -ForegroundColor Yellow -BackgroundColor Black "********************************"
Write-host -ForegroundColor Yellow                        " Starting SCOM Maintenance Work."
Write-host -ForegroundColor Yellow -BackgroundColor Black "********************************"
Write-host ""

 if(AzureLogin -AzureSubAdmin $AzureAccount -VaultName $KeyVaultName) 
 {
        write-host -ForegroundColor Cyan '4. Scanning Azure Key Vault for Credentials'
        $r = (Get-AzureKeyVaultSecret -VaultName $KeyVaultName -Name 'lpoaasvc')
        $cred = $r.SecretValueText.Split(" ")
    
        $Account = $cred[0].ToString()
        $PD = (ConvertTo-SecureString -String $cred[1] -AsPlainText -Force )
        $Credentials = [System.Management.Automation.PSCredential]::new($Account, $PD)
        
        $session = New-PSSession -ComputerName 'AZOMCAMECITPMS3.redmond.corp.microsoft.com' -Credential $Credentials
        Write-host -ForegroundColor Cyan '5. Connecting SCOM Management Server for maintenance Opertaions.'
        If($MaintenanceMode.Trim() -eq 'Enable')
        {
            $srv = $ServerName.Substring(0,$ServerName.IndexOf('.'))
            invoke-command -ScriptBlock $STARTSERVERSCOMMAINTENANCE -Session $session -ArgumentList (,$srv)  #Start Maintenance Mode
        }
        elseif ($MaintenanceMode.Trim() -eq 'Disable')
        {
            $srv = $ServerName.Substring(0,$ServerName.IndexOf('.'))
            invoke-command -ScriptBlock $STOPSERVERSCOMMAINTENANCE -Session $session -ArgumentList (,$srv) #Stop Maintenance Mode
        }

        Remove-PSSession $session.Id
 }
 else 
 {
        Write-host  -ForegroundColor Red "Error: Doesn't have permission to access Azure Key vault for pulling the credentials. "
 }

    Write-host ""
    Write-host -ForegroundColor Yellow -BackgroundColor Black "********************************"
    Write-host -ForegroundColor Yellow                        " Ending SCOM Maintenance Work.  "
    Write-host -ForegroundColor Yellow -BackgroundColor Black "********************************"
    Write-host ""

 }
Function ValidateAGPrimaryAndFailover    {
    param ([Parameter(Mandatory=$true, Position=0, HelpMessage='Please provide the SQL Node Name')] [string] $Servers)   
    $flag = 1; $FailoverDone = 0;$i = 1; $DT =@()

    Function ExecuteSqlQuery ($Query, $Server) { 
            Try
            {
                $Datatable = New-Object System.Data.DataTable 
                $conn = New-Object System.Data.SqlClient.SqlConnection("Data Source="+$($server)+";Integrated Security=SSPI;Initial Catalog=master")
                $conn.Open()
    
                $Command = New-Object System.Data.SQLClient.SQLCommand 
                $Command.Connection = $conn 
                $Command.CommandText = $Query

                $DataAdapter = new-object System.Data.SqlClient.SqlDataAdapter $Command 
                $Dataset = new-object System.Data.Dataset 
                $DataAdapter.Fill($Dataset) 
                $conn.Close() 
            }
            catch
            {
                Write-host -ForegroundColor red "SQL Exception: Connection Failure on $($Server)."
                Write-host -ForegroundColor red "Details: $($Error[0].Exception.Message)."
                $conn.Close()
                
            }
            return $Dataset.Tables[0] 
        }
    $Query = "select SERVERPROPERTY ('IsHadrEnabled') as Status"; $IsserverAGEnabled = ExecuteSqlQuery -Query $Query -Server $Servers     
    $AODB = "select top 1 database_name[Name] from sys.dm_hadr_database_replica_cluster_states drcs"

    Try{
        Foreach($Server in $servers)
        {
            If($IsserverAGEnabled.Status -eq 1)
            {
                $DB = ExecuteSqlQuery -Query $AODB -Server $server
                $AGQuery   = "select 'SECONDARY' AS Property, replica_server_name AS Value from sys.dm_hadr_availability_replica_cluster_states arcs 
                join sys.dm_hadr_database_replica_cluster_states drcs on arcs.replica_id=drcs.replica_id 
                join sys.dm_hadr_availability_replica_states ars on arcs.replica_id = ars.replica_id where arcs.replica_server_name = @@SERVERNAME 
                AND drcs.database_name = '$($DB.Name)' AND ars.role_desc = 'SECONDARY'
                UNION ALL SELECT 'AGNAME' AS SITE , NAME AS [NODE] FROM SYS.AVAILABILITY_GROUPS_CLUSTER";$Rows = ExecuteSqlQuery -Query $AGQuery -Server $server

                Foreach($Row in $Rows){
                if($Row.Property -ne $null){
                    if($Row.property -ne 'SECONDARY' -and $Rows.Count -eq 2){
                    $flag = 0
                    Try{
                    
                    $QuormVote = "select node.replica_server_name[Server], Role.Role_desc[Role], Qrm.number_of_quorum_votes[QVote] FROM SYS.AVAILABILITY_REPLICAS Node inner join SYS.DM_HADR_AVAILABILITY_REPLICA_STATES role on Node.replica_id = Role.replica_id 
                                      inner join SYS.DM_HADR_CLUSTER_MEMBERS Qrm on Qrm.member_name = node.replica_server_name"; $QuormVotes = ExecuteSqlQuery -Query $QuormVote -Server $server
                    ForEach($QRow in $QuormVotes)   { $DT +=($QuormVotes[$i]);$i+=1}
                    ForEach($Vote in $QuormVotes)   { 
                        If($Vote.Server -eq $server){
                            $PNodeVote  = $Vote.Qvote
                            $TargetNode = $DT | Select Server,Qvote | Where {($_.Qvote -eq $PNodeVote) -and $_.Server -ne $server}
                            }}
                            Try{
                                If($FailoverDone -ne 1){
                                    $FQDN = [net.dns]::Resolve($Server)
                                    Switch-SqlAvailabilityGroup -Path SQLSERVER:\Sql\$($FQDN)\Default\AvailabilityGroups\$($Row.value)
                                    $FailoverDone = 1;
                                    write-host 'Primary Node :'$($server) "-" $($Row.value) " - Switch-SqlAvailabilityGroup -Path SQLSERVER:\Sql\$($TargetNode.Server)\Default\AvailabilityGroups\$($Row.value)"
                                }
                            }
                            catch{$flag = 1; Write-Warning $error[0].exception.InnerException}
                        }
                       catch
                       {$flag = 1}
                }}}
            }
            else
            {
                Write-host "$($Server) - Standalone SQL Server Machine, No Failover Needed."
                $flag = 0
            }
        }
    }
    catch{$flag = 1} 
$flag
}
Function Get-ServiceStatusBeforeActivity {
    param (
    [Parameter(Mandatory=$true, Position=0)] [string] $Servers,
    [Parameter(Mandatory=$true, Position=1)] [string] $DBServer
)   

    $flag = 1
    $conn = New-Object System.Data.SqlClient.SqlConnection("Data Source=$($DBServer);Integrated Security=SSPI;Initial Catalog=master")
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $ServiceFilter = "(NOT StartName LIKE '%LocalSystem') AND (NOT StartName LIKE '%LocalService') AND (NOT StartName LIKE '%NetworkService') AND (NOT StartName LIKE 'NT AUTHORITY%')"

    Try
    {
        ForEach ($server in $Servers)
        {
            Try
            {
                $ServiceBeforePatching = (Get-WmiObject win32_service -ComputerName $Server -Filter $ServiceFilter |Select Name, StartMode,State,Status,StartName)
            }
            catch
            {
                "Failed to pull Service Status"; 
                $flag = 1
            }
            ForEach($Services in $ServiceBeforePatching) {
                if($conn.State -eq [Data.ConnectionState]::Open) {$conn.Close()}
                $conn.Open()
                $cmd.connection = $conn
            
                Try
                {
                    $cmd.commandtext = "INSERT INTO MASTER.dbo.ServiceBeforePatching (ServerName, ServiceName, State, Status, LogOnAccount) values ('{0}','{1}','{2}','{3}','{4}')"`
                    -f $($Server), $($Services.Name), $($Services.StartMode), $($Services.State),$($Services.StartName)
                    $cmd.executenonquery()
                    $conn.Close()
                    $flag = 0
                }
                catch 
                {
                    "Failed to Insert Serice Status on DB"; 
                    $flag = 1
                }
            } #Windows Service Insert

            $Pass = Get-Content "d:\Password.txt" | ConvertTo-SecureString; $Account='fareast\nitinkg'
            $credential = [System.Management.Automation.PSCredential]::new($Account, $Pass)

            $session = New-PSSession -ComputerName $Servers -Credential $credential
            $APools = @(Invoke-Command -Session $session -ScriptBlock ${function:CaptureAppPool} -ArgumentList ($Servers))
            
            ForEach($pool in $APools) {
                if($conn.State -eq [Data.ConnectionState]::Open) {$conn.Close()}
                $conn.Open()
                $cmd.connection = $conn

                Try
                {
                     $cmd.commandtext = "INSERT INTO MASTER.dbo.ServiceBeforePatching (ServerName, ServiceName, State, Status, LogOnAccount) values ('{0}','{1}','{2}','{3}','{4}')"`
                     -f $($Pool.ServerName), $($Pool.WebAppName), $($Pool.UserIdentityType), $($Pool.State),$($Pool.UserName)
                     $cmd.executenonquery()
                     $conn.Close()
                     $flag = 0
                }
                catch 
                {
                    "Failed to Insert Serice Status on DB"; 
                    $flag = 1
                }
                
            } #WebPool Details


        }
    }
    catch
    {
        "Failed to Insert Service Status on DB";
        $flag=1;
    }
}
Function Set-ServiceStatusAfterActivity  {
    param (
    [Parameter(Mandatory=$true, Position=0)] [string] $servers,
    [Parameter(Mandatory=$true, Position=1)] [string] $DBServer
)   
    
    $flag = 1; 
    $ServiceFilter = "(NOT StartName LIKE '%LocalSystem') AND (NOT StartName LIKE '%LocalService') AND (NOT StartName LIKE '%NetworkService') AND (NOT StartName LIKE 'NT AUTHORITY%')"
    
    Function ExecuteSqlQuery ($Query, $Server) { 
            Try
            {
                $Datatable = New-Object System.Data.DataTable 
                $conn = New-Object System.Data.SqlClient.SqlConnection("Data Source="+$($server)+";Integrated Security=SSPI;Initial Catalog=master")
                $conn.Open()
    
                $Command = New-Object System.Data.SQLClient.SQLCommand 
                $Command.Connection = $conn 
                $Command.CommandText = $Query

                $DataAdapter = new-object System.Data.SqlClient.SqlDataAdapter $Command 
                $Dataset = new-object System.Data.Dataset 
                $DataAdapter.Fill($Dataset) 
                $conn.Close() 
            }
            catch
            {
                Write-host -ForegroundColor red "SQL Exception: Connection Failure on $($Server)."
                Write-host -ForegroundColor red "Details: $($Error[0].Exception.Message)."
                $conn.Close()
                
            }
            return $Dataset.Tables[0] 
        }      
    $ServiceAction= {
    Param($ServiceName, $Action)

    If($Action -eq 'Start')
    { Start-Service -Name $ServiceName }
    elseif($Action -eq 'Stop')
    { Stop-Service -Name $serviceName  }

    }

    Try
    {
        Foreach ($Server in $servers)
        {
            Try
            { 
                $ServiceAfterPatching = (Get-WmiObject win32_service -ComputerName $Server -Filter $ServiceFilter | Select Name, StartMode,State,Status,StartName)
            }
            catch 
            {
                "Failed to Pull the Service Status";
                $flag = 1
            }
    
            $ServiceSQL = $("select ServerName, ServiceName,State,Status,LogOnAccount,StatusDate from Master..ServiceBeforePatching (nolock) 
            where ServerName = '$($Server)' and format(StatusDate,'MM/dd/yyyy HH:mm') in (Select MAX(format(StatusDate,'MM/dd/yyyy HH:mm')) 
            from Master..ServiceBeforePatching where ServerName = '$($Server)')"); $Rows = ExecuteSqlQuery -Query $ServiceSQL -Server $DBServer
    
            Try
            {
                ForEach($DBService in $Rows)
                {
                    Foreach($ServerService in $ServiceAfterPatching)
                    {
                        If($ServerService.Name -eq $DBService.ServiceName) 
                        {
                            If($ServerService.State -ne $DBService.Status)  
                            {
                                Write-host "$($ServerService.Name) status {$($ServerService.State)} is not matching with before patching servcie status {$($DBService.Status)}. Applying the change."
                                Try
                                {    
                                    switch ($DBService.Status) 
                                    {
                                        'Running' { "Starting Service";Invoke-Command -ComputerName $Server -ScriptBlock $ServiceAction -ArgumentList (,$DBService.ServiceName, 'Start') }
                                        'Stopped' { "Stopping Service";Invoke-Command -ComputerName $Server -ScriptBlock $ServiceAction -ArgumentList (,$DBService.ServiceName, 'Stop')  }
                                    }
                                } 
                                catch  
                                { 
                                    "Failed to pull the Before Patching Status from DB";$flag = 1
                                }
                            }   
                            else 
                            { 
                                "{$($ServerService.Name)} Services status is same as before patching..."
                            }
                        } 
                        $flag = 0 
                    }
                }
            }
            catch
            {
                "Failed to peform the Status change operations.";
                $flag = 1
            }
        }
    }
    Catch
    {
        $flag = 1
    }
$flag
}
Function CaptureAppPool                  {
Param($serverName)
    
    $i = Get-Module -ListAvailable | Select Name | Where {$_.Name -like 'WebAdministration'}
        If($i -ne $null)
        {
            $list = @()
            $webapps = Get-WebApplication
        
            foreach ($webapp in get-childitem IIS:\AppPools\)
            {
                $name = "IIS:\AppPools\" + $webapp.name
                $item = @{}

                $item.ServerName = $serverName
                $item.WebAppName = -join('ApplicationPool - ',$webapp.name)
                $item.State = (Get-WebAppPoolState -Name $webapp.name).Value
                $item.UserIdentityType = $webapp.processModel.identityType
                $item.Username = $webapp.processModel.userName
           
                $obj = New-Object PSObject -Property $item
                $list += $obj

            }

            return $list |Select ServerName, WebAppName, UserIdentityType, State, Username | ? {$_.Username -ne ""}

        }
        else
        {
            Write-Warning "Information : IIS Applications Not found."
        }

}
Function CertificateExpiry               {
    <#
        Title : Certificate Expiry Monitoring
        
        Description : This function will help you to pull Expiring certificates from target servers based on DaysToExpire Parameter values.
        Function will pull only those certificates which is expiring in next DaysToExpire Value and Alraedy expired in last 30 days. It is
        not pulling the old expired certificates from the pool.

        Example:
        CertificateExpiry -serverName nitin_dellxps -DayToExpire 300

    #>
    
    Param ($serverName, $DayToExpire)
    
    #Pulling Certificates
    $Certificate= {
        Param($server, [int]$DaysToExpire)
         $ds=@()
        $deadline = (Get-Date).AddDays($DaysToExpire)   #Set deadline date 
        Dir Cert:\LocalMachine\My | foreach { 
        $serverName
        if(($_.NotAfter - (Get-Date)).days -ge -30)
        {
            If ($_.NotAfter -le $deadline) 
            { 
                $ds+=$_ | Select Subject, Thumbprint,NotAfter, @{Label="Expires In (Days)";Expression={($_.NotAfter - (Get-Date)).Days} } 
            }
            }}
           $ds | Select @{Label="Server";Expression={$($server)}}, Thumbprint,Subject,NotAfter,"Expires In (Days)" | format-table -AutoSize
        }
    
    #Connecting to Remote Server
    Invoke-Command -ComputerName $ServerName  -ScriptBlock $Certificate -ArgumentList ($ServerName,$DaysToExpire)
    
}

