﻿start-transcript -path ($PSScriptRoot + "\Logs\PasswordLog_" + ([DateTime]::Now.ToString("MMddyyyyHHmmss"))+".txt") -noclobber
Import-Module C:\PasswordMaintenance1\ECPasswordMaintenance.psm1 -DisableNameChecking

$cred = Get-Credential -Message "Enter Credential to Connect Target Servers"
$Accounts = Import-Csv C:\PasswordMaintenance1\Accounts\Accounts.csv #AccountName, AccountDomain, CurrPassword

Write-Host -ForegroundColor Yellow -BackgroundColor Black "Start Time : $(get-date)"

#Change Below Variables based on your environment & vault
$subscription = 'ECIT Production Monitoring'
$ResourceGrp = 'KeyValut2storeVLPwds'
$KeyVault = 'VLServiceAccounts'

ForEach($Account in $Accounts)
{
    $Details = @()     
    #$Response = ReSetAccountPassword -Identity $Accounts.ServiceAccountName -CurrentPassword $Accounts.CurrentPassword -DomainName $Accounts.Domain -Location AzureKeyVault -SubscriptionName $subscription -ResourceGroup $ResourceGrp -KeyVaultName $KeyVault

    $Response = ReSetAccountPassword -Identity $Accounts.ServiceAccountName -CurrentPassword $Accounts.CurrentPassword -DomainName $Accounts.Domain -Location LocalFileSystem
    #AKV Version : $Response = ReSetAccountPassword -Identity $Accounts.ServiceAccountName -CurrentPassword $Accounts.CurrentPassword -DomainName $Accounts.Domain -Location AzureKeyVault -SubscriptionName $subscription -ResourceGroup $ResourceGrp -KeyVaultName $KeyVault
    
    $Details = $Response | Select -First 1

    
    Get-Content C:\PasswordMaintenance1\Servers\Servers.txt | % {   #Add FQDN Server List in Servers.txt file give the path
    Start-Job -ScriptBlock {
    Param(
    [Parameter(Mandatory=$True)] $server,
    [Parameter(Mandatory=$True)] $ServiceAccount,
    [Parameter(Mandatory=$false)] $Password,
    [Parameter(Mandatory=$false)] $OldPassword,
    [Parameter(Mandatory=$false)] [ValidateSet('True','False')] [string]$AzureKeyVault,
    [Parameter(Mandatory=$false)] $Credential,
    [Parameter(Mandatory=$false)] $SubscriptionName,
    [Parameter(Mandatory=$false)] $ResourceGroup,
    [Parameter(Mandatory=$false)] $KeyVaultName )
    
    Write-Host ""
    Write-Host -ForegroundColor Yellow "**********************************************************************************************"
    Write-Host -ForegroundColor Yellow " Initiating Service Account Password Updates on $($server).                                   "
    Write-Host -ForegroundColor Yellow "**********************************************************************************************"
    Write-Host ""


    Function AzureLogin{
    Param($AzureSubAdmin, $sub_name, $ResourceGrp, $VaultName)
    Write-host -ForegroundColor Cyan "1. Connecting to Azure Key Vault [$($VaultName)]."    

    Try   
    {
        if((Get-AzureRmContext -ErrorAction SilentlyContinue).Tenant -eq $null)
        {
            throw;
        }
    }
    catch
    {
        Login-AzureRmAccount -ErrorAction Stop
        Try
        {
            if((Get-AzureRmContext -ErrorAction SilentlyContinue).Tenant -eq $null)
            {
                throw;
            }
        }
        catch
        {
            Write-Error "Failed to provide Azure Account or unable to retrieve ARM Context. Please try again.";
            return $false;
        }
    }

    Try   
    {
        $sub_id = Get-AzureRMSubscription -SubscriptionName $sub_name; 
        Set-AzureRmContext -SubscriptionId $sub_id.subscriptionid
        Write-host -ForegroundColor Cyan "2. Pulling Vault {$($VaultName)} by connecting subscription {$($sub_name)}."
    } 
    catch
    { 
        Write-host -ForegroundColor Red "Error: Subscription {$($sub_name)} Not Found."; return $false;
    }

    Try   
    {
        Write-host -ForegroundColor Cyan "3. Setting permission to Azure Account {$($AzureSubAdmin)}."
        Set-AzureRmKeyVaultAccessPolicy -VaultName $VaultName -ResourceGroupName $ResourceGrp -UserPrincipalName $AzureSubAdmin -PermissionsToSecrets all
        Write-host -ForegroundColor Cyan "..... Setting permission to Azure Account {$($AzureSubAdmin)} is successful."
    }
    catch 
    {
        Write-host -ForegroundColor Red "Error: Failed to assign permission to Azure Account {$($AzureSubAdmin)}. Please check with Subscription Owner for more details"; return $false;
    }

}

    Try
    {
        $AppPool                             =  {
        Param ($ServiceAccount, $password)
        $Error.Clear()

        $i = Get-Module -ListAvailable | Select Name | Where {$_.Name -like 'WebAdministration'}
        If($i -ne $null){
            Import-Module WebAdministration
            $applicationPools = Get-ChildItem IIS:\AppPools | Where {$_.ProcessModel.UserName -Like "*$($ServiceAccount)*"}
        }
        else
        {
            write-host -ForegroundColor Cyan -BackgroundColor Black "Information : IIS Applications Not found."
        }

        foreach($applicationPool in $applicationPools)
        {
            write-host -ForegroundColor Cyan -BackgroundColor Black "Information : $($applicationPool.Name) Application Pool using $($applicationPool.ProcessModel.UserName), We're Updating the Password & Recycling it."

            $applicationPool.processModel.userName = $applicationPool.ProcessModel.UserName
            $applicationPool.processModel.password = $password
            $applicationPool.processModel.identityType = 3
            $applicationPool | Set-Item

            Start-Sleep -s 2
            If($applicationPool.state -eq "Started")
            {
                Restart-WebAppPool $applicationPool.Name
                write-host "Restarted Application pool $($applicationPool.Name) & passwords updated" 
                write-host ""
            }
            else 
            { 
                write-host "App Pool $($applicationPool.Name) found in Stopped State, however applied the new password without recycle."
                Write-Host ""
            }
           
        }
    } #Completed
        $IISWebSiteAuthenticationCredentials =  {
    Param($server, $ServiceAccount, $Password)
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.Web.Administration") | Out-Null 
    Try{
    $iis = new-object Microsoft.Web.Administration.ServerManager
    }catch {write-host -ForegroundColor Cyan -BackgroundColor Black "Information: IIS Not Found"; continue}
    $ErrorActionPreference = "stop"
    $registryPath = "HKLM:\SOFTWARE\Microsoft\InetStp\"
    
    Try
    {
        $iisVersion = $(get-itemproperty HKLM:\SOFTWARE\Microsoft\InetStp\).setupstring
    }
    catch [System.Management.Automation.PSArgumentException]
    { 
        Write-Warning  "Argument Missing"; 
        Break
    }
    Catch [System.Management.Automation.ItemNotFoundException]
    {
        write-host "IIS Not Found on {$Server}"; 
        Break
    }
        
    write-host -ForegroundColor Cyan -BackgroundColor Black "Information : $($iisVersion) - Found on server {$($server)}."
    write-host -ForegroundColor Cyan -BackgroundColor Black "Information : Below IIS Web Site Authentication Using {$($ServiceAccount)}."

    #Pulling Details
    Try
    {
        $Default = ($iis.Sites|Select Name) #Default
        write-host  -ForegroundColor Cyan -BackgroundColor Black "Information : Default Web Site : $Default"
        $Details =@()
        
        $details = $iis.Sites | ForEach{$_.Applications | select ApplicationPoolName, Path,
        @{Name="UserName"; Expression = {$_.GetWebConfiguration().GetSection("system.webServer/security/authentication/anonymousAuthentication").GetAttributeValue("UserName")}},
        @{Name="AnonymousEnabled"; Expression = {$_.GetWebConfiguration().GetSection("system.webServer/security/authentication/anonymousAuthentication").GetAttributeValue("Enabled")}}|
        where {$_.UserName -like "*$($ServiceAccount)*"}            
        }

        #$Details | Format-table -a
        ForEach($detail in $Details)
        {
            $file = -join ($default.Name,$detail.Path)
            $Pass = ($iis.GetApplicationHostConfiguration()).GetSection("system.webServer/security/authentication/anonymousAuthentication","$($file)").Attributes["Password"].Value
            $Detail | Select ApplicationPoolName, Path,AnonymousEnabled, UserName, @{Name="Password"; Expression={$($Pass)}} 
            
            Try
            {
                #Update Credentials
                #-------------------
                #($iis.GetApplicationHostConfiguration()).GetSection("system.webServer/security/authentication/anonymousAuthentication","$($file)").Attributes["Password"].Value = $Password 
                #$iis.CommitChanges()
            }
            Catch{$error[0].Exception.Message}
                   
        }
    }
    catch
    {
        write-host -ForegroundColor red -BackgroundColor Black "Failure : Unable to Pull IIS Credentials, Exception Details - " -NoNewline
        write-host  $Error[0].Exception.Message
    }

} #Completed
        $GetServiceRunningAccounts           =  {
        Param($UserName, $Password)

        $St = Get-WmiObject  -Namespace root\cimv2 -Class Win32_Service | Where-Object { $_.StartName -like "*$($UserName)*" -and $_.Name -ne "MSSQLSERVER" } | ForEach-Object {
        $status = $_.Change($null, $null, $null, $null, $null, $null,$_.StartName,$Password).ReturnValue
        
            If($Status -eq 0)
            {
                write-host ""
                write-host -ForegroundColor Green "Windows Service Passwoard Change request accepted for $($_.Name) Service."
        
                $DependentService = (Get-Service -Name $_.Name).DependentServices #Pulling Dependent Service Details If any

                If($DependentService.Name) #If Found any Dependent 
                {
                    write-host -ForegroundColor Cyan -BackgroundColor Black "Information : Dependent Service {$($DependentService.Name)} found on Parent Service {$($_.Name)}."

                    if((Get-Service -Name $($DependentService.Name) | Select Status).Status -eq 'running') #If Dependent Service Running
                    {
                        Stop-Service -Name $($DependentService.Name) #Stopping Dependent Service
                        Start-Sleep -s 2

                        write-host  "Initiated Dependent Service {$($DependentService.Name)} Stop request."
                        Get-Service -Name $($DependentService.DisplayName)
                    
                        while((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($DependentService.Name)'").Started)
                        {
                            Start-Sleep -s 1
                        }
                    }
                    else
                    {
                        Get-Service -Name $($DependentService.Name)
                    }

                    if((Get-Service -Name $($_.Name) | Select Status).Status -eq 'running') #If Parent Service Running
                    {
                        write-host "Initiating Stop request for $($_.Name) Service."

                        $stop = ($_.StopService()).ReturnValue #Stopping Main Service
                        If($stop -eq 0)
                        {
                            write-host "Stop Service Request Accepted for Windows Service {$($_.Name)}. Awaiting 'stopped' status." -NoNewline 
                            while ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($_.Name)'").Started) 
                            {
                            Start-Sleep -s 1
                            write-host -NoNewline "."
                        }
                            write-host "."

                        $start = $_.StartService().ReturnValue
                        if ($start -eq 0)
                        {
                            write-host -ForegroundColor Green "Start request accepted for Windows Server {$($_.Name)}."
                        }
                        else
                        {
                            write-host -ForegroundColor Red -BackgroundColor Black ("Failed to start service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393660(v=vs.85).aspx" -f $start) 
                        }
                    }
             
                    Start-sleep 5
                    write-host   "Starting Dependent Service $($DependentService.Name)"
                    Start-Service -Name $($DependentService.Name)
                    Get-Service -Name $($DependentService.Name)
                    }
                    else
                    {
                        Get-Service -Name $($_.Name)
                    }
                
                }
                else # In case no dependent service
                {
                  if ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($_.Name)'").Started) #If Service in Running State
                    {
                        $serviceName = $_.Name
                        $stop = ($_.StopService()).ReturnValue
                
                        If($stop -eq 0)
                        {
                            write-host "Stop Service Request Accepted for Windows Service {$($serviceName)}. Awaiting 'stopped' status." -NoNewline 
                            while ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$serviceName'").Started)
                            {
                                Start-Sleep -s 1
                                write-host -NoNewline "."
                            }
                            write-host "."
                            $start = $_.StartService().ReturnValue
                    
                            if ($start -eq 0)
                            {
                                write-host -ForegroundColor Green "Start request accepted for Windows Server {$($serviceName)}."
                            }
                            else
                            {
                                
                                write-host -ForegroundColor Red -BackgroundColor Black ("Failed to start service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393660(v=vs.85).aspx" -f $start)  
                            }
                        }
                        else
                        {
                            write-host -BackgroundColor Black ("Failed to stop service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393673(v=vs.85).aspx" -f $stop) -ForegroundColor "red"
                        }
                    }
                    else
                    {                    
                        write-host "Current Service Status : $(Get-Service -Name $_.Name|Select Name, Status) " -NoNewline
                        write-host -ForegroundColor Cyan -BackgroundColor Black "Information : As the service was in stop state before the Password change activity, We're not initiating the Start Request for the same."
                        
                    }
                }
            }
            else
            {
                write-host -ForegroundColor Red -BackgroundColor Black "Error : Windows Service Password Change request failed for $($_.Name) Service."
            }
        }
        
        if(!$St){
            $SQLStatus = (Get-WmiObject  -Namespace root\cimv2 -Class Win32_Service | Where-Object { $_.StartName -like "*$($UserName)*" -and $_.Name -eq "MSSQLSERVER"})
            If($SQLStatus)
            {
                write-host -ForegroundColor Cyan -BackgroundColor Black "Information : SQL Services found with Logon Name as {$($UserName)} and will be taken care in next step, under SQL operations."
            }
            else
            {Write-Host -ForegroundColor Cyan -BackgroundColor Black "Information :  No Services running under {$($UserName)}"}
        }

    } #Updated except SQL Service #Updated except SQL Service & Service Status based action
        $COMAccount                          =  {
    Param ($UserName, $Password, $server)
    $comAdmin = New-Object -comobject COMAdmin.COMAdminCatalog
    $apps = $comAdmin.GetCollection(“Applications”)
    $apps.Populate();
    $AvailableCom=0;

    If($apps)
    {
        foreach($app in $apps)
        {
            if($app.Value("Identity") -like "*$($UserName)*")
            {
                write-host -ForegroundColor Cyan -BackgroundColor Black "Information : $($app.Name) - using Service Account : $($app.Value("Identity"))"
                $app.value("Identity") = $app.Value("Identity")
                $app.value("Password") = $Password
                $save = $apps.SaveChanges()
                $save
                    if($save -ne $null)
                    {
                        write-host "Password Update Successfully for COM+ : $($app.Name)"
                        $comAdmin.StartApplication($app.Name) #Sometime doesn't require, included in code if not require comment this line.
                        write-host -ForegroundColor Cyan -BackgroundColor Black "Information : $($app.Name) Application Started"

                    } 
                    else
                    {
                        write-host -ForegroundColor red -BackgroundColor Black "Password Update Failed for COM+ : $($app.Name)"
                    }
                    $AvailableCom =+ 1
            }
        }
        write-host "$($AvailableCom): COM+ Applications running under $($UserName) & updated"
    }
    else {write-host -ForegroundColor Cyan -BackgroundColor Black "InformatiCOM+ Application not found on Server {$($server)}."}
} #Completed
        $GetSchduleTaskUsers                 =  {
    Param ($User,$FullUser, $Password)

    $details=@(); $i=@()
    $serviceAccount =$User
    $TaskSystemAccounts = 'INTERACTIVE', 'SYSTEM', 'NETWORK SERVICE', 'LOCAL SERVICE', 'Run As User', 'Authenticated Users', 'Users', 'Administrators', 'Everyone', ''
    $TaskFilter = { $TaskSystemAccounts -notcontains $_.'Run As User' }
               
    Invoke-Expression "SCHTASKS /QUERY /FO CSV /V" -EA SilentlyContinue | ConvertFrom-CSV | Where-Object $TaskFilter | ForEach-Object {
    $details +=New-Object -TypeName PSObject -Property @{
    Type = 'Task'
    Name = $_.TaskName
    Account = $_.'Run As User'} | Select-Object Type, Name, Account | Where-Object {$_.account -like "*$($serviceAccount)*"}}
    
    write-host ""
    write-host "Below $($details.count) Tasks running under Account {$($FullUser)}."
    write-host "-------------------------------------------------------------------"
    $details |select Type, Name, Account | format-table -AutoSize

        foreach($detail in $details)
        {
            try
            {
                $i+=Set-ScheduledTask -TaskName $detail.Name -user $Fulluser -Password $Password -EA SilentlyContinue 
            }
            catch
            {
                $error[0].Exception.Message
            }
        }
        
        if($details.count -eq $i.count)
        {
            write-host "All $($details.count) Tasks are updated successfully."
        }
        else
        {
            write-host "Out of $($details.count) Tasks {$($details.count - ($details.count - $i.count))} Tasks failed!!!"
        }
    } #Updated
        $Cached                              =  {
    Param ($User,$Password)
    Function Get-CachedCredential{ 
    <# 
        DESCRIPTION: 
        This function wraps cmdkey /list and returns an object that contains 
        the Targetname, user and type of cached credentials. 
       
        PARAMETER Type:
        To filter the list provide one of the basic types of  
        cached credentials 
                1. Domain 
                2. Generic 
        EXAMPLE:
        Get-CachedCredential 
 
        Target                                                                         Type                User                  
        ------                                                                         ----                ----                  
        LegacyGeneric:target=MicrosoftAccount:user=nitink.gupta@outlook.com            Generic             nitink.gupta@outlook.com
        MicrosoftOnlineServices:target=virtualapp/didlogical                           Generic             02kqbmtcoyoq            
        WindowsLive:target=virtualapp/didlogical                                       Generic             02elhualljdh            
        LegacyGeneric:target=NITIN_DELLXPS\Test                                        Generic             NITIN_DELLXPS\Test      
        LegacyGeneric:target=Microsoft_OC1:uri=nitinkg@microsoft.com:specific:OCS:1    Generic             nitinkg@microsoft.com   
        LegacyGeneric:target=Microsoft_OC1:uri=nitinkg@microsoft.com:certificate:OCS:1 Generic Certificate <Certificate>           
        LegacyGeneric:target=REDMOND\lpoaasvc                                          Generic             REDMOND\lpoaasvc  
 
           
    #> 
    [CmdletBinding()] 
    
    Param ([ValidateSet("Generic","Domain","Certificate","All")] [string]$Type) 
    Begin{ $Result = cmdkey /list } 
    Process{ 
                $Return = @() 
                $Temp = New-Object -TypeName psobject 
                foreach ($Entry in $Result) { 
                    if ($Entry) { 
                        $Line = $Entry.Trim(); 
                        if ($Line.Contains('Target: ')){ 
                            Write-Verbose $Line 
                            $Target = $Line.Replace('Target: ',''); 
                            } 
                        if ($Line.Contains('Type: ')) { 
                            Write-Verbose $Line 
                            $TargetType = $Line.Replace('Type: ',''); 
                            } 
                        if ($Line.Contains('User: ')) { 
                            Write-Verbose $Line 
                            $User = $Line.Replace('User: ',''); 
                            Add-Member -InputObject $Temp -MemberType NoteProperty -Name Target -Value $Target 
                            Add-Member -InputObject $Temp -MemberType NoteProperty -Name Type -Value $TargetType 
                            Add-Member -InputObject $Temp -MemberType NoteProperty -Name User -Value $User 
                            $Return += $Temp; 
                            Write-Verbose $Temp; 
                            $Temp = New-Object -TypeName psobject 
                            }}}} 
    End{ 
        if ($Type -eq "All" -or $Type -eq "") { 
            Write-Verbose "ALL" 
            return $Return; } 
        else { 
            Write-Verbose "FILTERED" 
            if ($Type -eq "Domain") { 
                $myType = "Domain Password" } 
            if ($Type -eq "Certificate") { 
                $myType = "Generic Certificate"} 

                if ($Return -ne $null){
                return $Return |Where-Object -Property Type -eq $myType}
                else{
                write-host $user "not available in cached credentials"}

}}
    } #Completed
    Function Add-CachedCredential{ 
    <# 
        DESCRIPTION: 
        This function wraps cmdkey /add and stores a TargetName and 
        user/pass combination in the vault 
        
        PARAMETER: 
            1. TargetName: The name of the object to store credentials for, typically 
                           this would be a computer name 
            
            2. Type: Add credentials in one of the few valid types of cached credentials 
                2.1 - Domain 
                2.2 - Generic 
            3. Username : Specify the username which needs to be updated
            4. Password : New Password
    #> 
    [CmdletBinding()] 
    Param ( 
        [Parameter(Mandatory=$true,ValueFromPipeline=$True)] [string]$TargetName, [ValidateSet("Generic","Domain")] [string]$Type, 
        [Parameter(Mandatory=$true)] [string]$Username,
        [Parameter(Mandatory=$true)] [string]$Password) 
    Begin{ 
        #$Username = $Credential.UserName; 
        #$Password = $Credential.GetNetworkCredential().Password; 
    } 
    Process { foreach ($Target in $TargetName) 
            { switch ($Type) 
                { "Generic" 
                {$Result = cmdkey /generic:$Target /user:$Username /pass:$Password 
                    if ($LASTEXITCODE -eq 0) 
                    {Return $Result;} 
                    {Write-Error $Result; Write-Error $LASTEXITCODE} 
                } 
                "Domain"{ 
                    $Result = cmdkey /add:$Target /user:$Username /pass:$Password 
                    if ($LASTEXITCODE -eq 0) 
                    {Return $Result;} 
                    {Write-Error $Result; Write-Error $LASTEXITCODE} 
                }}}} 
    End 
    {}
 } #Completed
    $CachedCredentials = Get-CachedCredential | Select User, Type, Target | Where-Object {$_.User -like "*$($User)*" -and $_.Type -notlike '*Domain*'}
    if($CachedCredentials)
    {
        write-host "Cached Credential available for Service Account {$($User)}"
        Get-CachedCredential | Select User, Type, Target | Where-Object {$_.User -like "*$($User)*"}
        write-host "Updating New Credentials for Service Account {$($User)}."
        write-host ""

        foreach($cred in $CachedCredentials)
        {
                Add-CachedCredential -TargetName $cred.Target -Type $cred.type -Username $cred.User -Password $Password -InformationAction SilentlyContinue
        }
    }
    else
    {
        write-host -ForegroundColor Cyan -BackgroundColor Black "Information : No Cached Credential found for Service Account {$($User)}."
    }
} #Updated
        $SQLChange                           =  {
        Param ($UserName, $password,$oldPwd, $Server)
        $flag = 1; $FailoverDone = 0; $i=1; $DT =@() 
        If($Server.IndexOf('.') -ge 0){ $local = $server.Substring(0,$server.IndexOf('.'))}else{$local=$Server}

        Function ExecuteSqlQuery ($Query, $Server) { 
                Try
                {
                    $Datatable = New-Object System.Data.DataTable 
                    $conn = New-Object System.Data.SqlClient.SqlConnection("Data Source="+$($server)+";Integrated Security=SSPI;Initial Catalog=master")
                    $conn.Open()
    
                    $Command = New-Object System.Data.SQLClient.SQLCommand 
                    $Command.Connection = $conn 
                    $Command.CommandText = $Query

                    $DataAdapter = new-object System.Data.SqlClient.SqlDataAdapter $Command 
                    $Dataset = new-object System.Data.Dataset 
                    $DataAdapter.Fill($Dataset) 
                    $conn.Close() 
                }
                catch
                {
                    write-host -ForegroundColor red -BackgroundColor Black "SQL Exception: Connection Failure on $($Server)." -NoNewline
                    write-host  "Details: $($Error[0].Exception.Message)."
                    $conn.Close()
                }
                return $Dataset.Tables[0] 
            }

        $SQLStatus = (Get-WmiObject  -Namespace root\cimv2 -Class Win32_Service | Where-Object { $_.StartName -like "*$($UserName)*" -and $_.Name -eq "MSSQLSERVER"})
        
        If($SQLStatus.State -eq 'Running')
        {
            $Query = "select SERVERPROPERTY ('IsHadrEnabled') as Status"; $IsserverAGEnabled = ExecuteSqlQuery -Query $Query -Server $Server
    
            If($IsserverAGEnabled.Status -eq 1) #If AG Enabled
            {
            write-host -ForegroundColor Cyan -BackgroundColor Black "Information : $($server) is a part of SQL AG cluster".

                $AODB      = "select top 1 database_name[Name] from 
                sys.dm_hadr_database_replica_cluster_states drcs"; $DB   = ExecuteSqlQuery -Query $AODB    -Server $server
                $AGQuery   = "select 'SECONDARY' AS Property, replica_server_name AS Value from sys.dm_hadr_availability_replica_cluster_states arcs 
                join sys.dm_hadr_database_replica_cluster_states drcs on arcs.replica_id=drcs.replica_id 
                join sys.dm_hadr_availability_replica_states ars on arcs.replica_id = ars.replica_id where arcs.replica_server_name = '$($server)' 
                AND drcs.database_name = '$($DB.Name)' AND ars.role_desc = 'SECONDARY'
                UNION ALL SELECT 'AGNAME' AS SITE , NAME AS [NODE] FROM SYS.AVAILABILITY_GROUPS_CLUSTER"; $Rows = ExecuteSqlQuery -Query $AGQuery -Server $server
                Foreach($Row in $Rows)
                {
                    if($Row.Property -ne $null)
                    {
                        if($Row.property -ne 'SECONDARY' -and $Rows.Count -eq 2)
                        {
                            $flag = 0
                            write-host -ForegroundColor Cyan -BackgroundColor Black "Information : $($server) is a Primary node of the SQL AG cluster".

                            Try
                            {
                                [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | out-null
                                $SMOWmiserver = New-Object ("Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer") "$($local)" 
                            
                                Try
                                {
                                    $ChangeService = $SMOWmiserver.Services | select name, ServiceAccount, DisplayName, StartMode | ? {$_.ServiceAccount -like "*$($UserName)*"} | FL
                                }
                                catch 
                                {
                                    Write-Warning "SQL Configuration Manager not Found or SMO WMI Provider missing. Retrying the same from Services.msc"
                                    Get-WmiObject -Namespace root\cimv2 -Class Win32_Service | Where-Object { $_.StartName -like "*$($UserName)*" -and $_.Name -eq "MSSQLSERVER" } | ForEach-Object {
                                    $Status = $_.Change($null, $null, $null, $null, $null, $null,$_.StartName,$Password).ReturnValue
            
                                    If($Status -eq 0)
                                    {
                                        write-host -ForegroundColor Green "....Success : Windows Service Passwoard Change request accepted for $($_.Name) Service."
                                        $DependentService = (Get-Service -Name $_.Name).DependentServices

                                        If($DependentService)
                                        {
                                            write-host -ForegroundColor Cyan -BackgroundColor Black "Information : Stopping Dependent Windows Service {$($DependentService.Name)}."
                                            Stop-Service -Name $($DependentService.Name)

                                            while((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($DependentService.Name)'").Started)
                                            {
                                                Start-Sleep -s 1
                                                write-host "." -NoNewline
                                            }

                                            write-host "."
                                            write-host -ForegroundColor Cyan -BackgroundColor Black "Information : Dependent Service {$($DependentService.Name)} Stopped Successfully."
                                            write-host -ForegroundColor Cyan -BackgroundColor Black "Information : Stopping Parent Service {$($_.Name)}."

                                            $stop = ($_.StopService()).ReturnValue
                    
                                            If($stop -eq 0)
                                            {
                                                write-host -ForegroundColor Cyan -BackgroundColor Black "Information : Stop Service Request Accepted for Windows Service {$($_.Name)}. Awaiting 'stopped' status." -NoNewline
                        
                                                while ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($_.Name)'").Started) 
                                                {
                                                    Start-Sleep -s 1
                                                    write-host -NoNewline "."
                                                }
                                                write-host "."

                                                write-host -ForegroundColor Green  "Success : Parent Service {$($_.Name)} Stopped Successfully."
                                                write-host -ForegroundColor Cyan -BackgroundColor Black "Information : Starting Parent Service {$($_.Name)} after Password Update."

                                                $start = $_.StartService().ReturnValue
                                                if ($start -eq 0)
                                                {
                                                    write-host -ForegroundColor Green "Information : Parent Service {$($_.Name)} Started Successfully."
                                                    write-host -ForegroundColor Cyan -BackgroundColor Black "Information : Starting Dependent Service {$($DependentService.Name)}."
                            
                                                    Start-sleep 5
                                                    Start-Service -Name $($DependentService.Name)

                                                }
                                                else
                                                {
                                                    write-host -ForegroundColor red -BackgroundColor Black  ("Failed : Failed to start service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393660(v=vs.85).aspx" -f $start) 
                                                }
                                            }
                                        }
                                        Else
                                        {
                                            If ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$($_.Name)'").Started)
                                            {
                                                $serviceName = $_.Name
                                                write-host -ForegroundColor Cyan -BackgroundColor Black  "Information : Stopping Service {$($serviceName)}."
                                                $stop = ($_.StopService()).ReturnValue
                        
                                                If($stop -eq 0)
                                                {
                                                    while ((Get-WmiObject -Namespace root\cimv2 -Class Win32_Service -Filter "Name='$serviceName'").Started)
                                                    {
                                                        Start-Sleep -s 1
                                                        write-host -NoNewline "."
                                                    }
                                                    write-host "."
                                                    write-host -ForegroundColor Green "....Success : Service {$($serviceName)} Successfully Stopped."

                                                    $start = $_.StartService().ReturnValue
                                                    write-host -ForegroundColor Cyan -BackgroundColor Black "Information : Initiating {$($serviceName)} Service Start after Password update."

                                                    If ($start -eq 0)
                                                    {
                                                        write-host -ForegroundColor Green "....Success : Service {$($serviceName)} Successfully Started."
                                                    }
                                                    Else
                                                    {
                                                        write-host -ForegroundColor red -BackgroundColor Black ("Failed : Failed to start service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393660(v=vs.85).aspx" -f $start) 
                                                    }

                                                }
                                                Else
                                                {
                                                    write-host -ForegroundColor red -BackgroundColor Black ("Failed : Failed to stop service. ReturnValue was '{0}'. See: http://msdn.microsoft.com/en-us/library/aa393673(v=vs.85).aspx" -f $stop) 
                                                }
                    
                                            }
                                        }
                                    }
                                    Else
                                    {
                                        write-host -ForegroundColor red -BackgroundColor Black "Failed : Windows Service Password Change request failed for $($_.Name) Service."
                                    }}
                                }

                                ForEach($service in $ChangeService)
                                {
                                    Try
                                    {
                                        $Service.ChangePassword($Oldpassword,$password)
                                        $service.Alter()

                                        write-host -ForegroundColor Cyan -BackgroundColor Black "Information : SQL Services Status post password change."
                                        Get-Service | Select DisplayName, Name, Status | ? {$_.Name -eq 'MSSQLSERVER'} | Format-table -AutoSize
                                    }
                                    Catch
                                    {
                                        write-host -ForegroundColor red -BackgroundColor Black  "Error : Password update failed for $($service.Name)." -NoNewline
                                        write-host "{Exception Details : $($Error[0].Exception.Message)}."
                                    }
                                }
                            
                            }
                            Catch
                            {
                                $flag = 1; 
                                write-host $error[0].exception.message
                            }
                        }
                        else
                        {
                            $Sec = 1; $flag = 0
                        }
                    }
                }
        }
            else
            {
            write-host -ForegroundColor Cyan -BackgroundColor Black  "Information : $($Server) - Standalone SQL Server Machine."
            $flag = 0
        }

            If($flag -eq 0) 
            {
            if($sec -eq 1)
            {
                write-host -ForegroundColor Cyan "Information : $($Server) is a Secondary Node of the AG Cluster."
            }
            write-host -ForegroundColor Cyan 'Information : Initiating Password update for SQL Services.'
    
            Try
            {
                [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | out-null
                $SMOWmiserver = New-Object ("Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer") "$($local)" 
                $ChangeService = $SMOWmiserver.Services | ? {$_.ServiceAccount -like "*$($UserName)*" -and $_.Name -eq "MSSQLSERVER"} 

                ForEach($service in $ChangeService)
                {
                    Try
                    {
                        $Service.ChangePassword($oldPwd,$password)
                        $service.Alter()
                
                        write-host -ForegroundColor Cyan -BackgroundColor Black "Information : SQL Services Status post password change."
                        Get-Service | Select DisplayName, Name, Status | ? {$_.Name -eq 'MSSQLSERVER'} | Format-table -AutoSize

                    }
                    Catch
                    {
                        write-host -ForegroundColor red -BackgroundColor Black  "Failed : Password update failed for $($service.Name)." -NoNewline
                        write-host "{Exception Details : $($Error[0].Exception.Message) or Incorrect password}."
                    }
                }
        
            }
            catch
            {
                $flag = 1; 
                write-host $error[0].exception.message
            }
        }
            else
            {
            write-host -ForegroundColor Yellow "Error: Exception During SQL Operations, SQL Account Password change operation failed."; 
            write-host -ForegroundColor red "Actual Exception => $($Error[0].Exception.Message)"
            $flag = 1
        }
        }
        elseif($SQLStatus.State -eq 'Stopped')
        {
            write-host -ForegroundColor Cyan -BackgroundColor Black "Information : SQL Service Available on [$($Server)] under logon [$($UserName)] and found in Stopped State."
            Get-WmiObject  -Namespace root\cimv2 -Class Win32_Service | Where-Object { $_.StartName -like "*$($UserName)*" -and $_.Name -like "*SQL*"} | ForEach-Object{
    
            if(($_.change($null, $null, $null, $null, $null, $null,$_.StartName,$Password).ReturnValue) -eq 0)
            {
                write-host -ForegroundColor Cyan -BackgroundColor Black  "Information : Password Change Accepted for {$($_.Name)} Service."
            }
            else
            {
                write-host -ForegroundColor red -BackgroundColor Black "Password Change Failed for {$($_.Name)} Service."
            }}
        }
        elseif(!$SQLStatus)
        {
            write-host -ForegroundColor Cyan -BackgroundColor Black "Information : SQL Server not available on {$($Server)}."
        }

    } #Updated without AG Failover 
        $SQLProxy                            =  {

        Param ($ServerName,$UserName, $Password )
        Function ExecuteSqlQuery ($Query, $Server) { 
            Try
            {
                $Datatable = New-Object System.Data.DataTable 
                $conn = New-Object System.Data.SqlClient.SqlConnection("Data Source="+$($server)+";Integrated Security=SSPI;Initial Catalog=master")
                $conn.Open()
    
                $Command = New-Object System.Data.SQLClient.SQLCommand 
                $Command.Connection = $conn 
                $Command.CommandText = $Query

                $DataAdapter = new-object System.Data.SqlClient.SqlDataAdapter $Command 
                $Dataset = new-object System.Data.Dataset 
                $DataAdapter.Fill($Dataset) 
                $conn.Close() 
            
            }
            catch
            {
                write-host -ForegroundColor red -BackgroundColor Black "SQL Exception: Connection Failure on $($Server)."
                write-host  "Details: $($Error[0].Exception.Message)."
                $conn.Close()
                $flag=1
            }
            return $Dataset.Tables[0] 
        } 
        
        Try
        { 
            $SQLStatus = (Get-WmiObject  -Namespace root\cimv2 -Class Win32_Service -EA SilentlyContinue | Where-Object {$_.Name -like "*MSSQLSERVER*" }) 
        }
        Catch 
        {
            write-host -ForegroundColor red -BackgroundColor Black $Error[0].Exception.Message
        }

        

        If($SQLStatus)
        {  
            if($SQLStatus.state -eq 'running')
            {
                TRy
                {
                $credQuery = "Select cred.name [Name], prox.enabled [Enabled] from  master.sys.credentials cred with (nolock) inner join msdb..sysproxies prox on cred.credential_id = prox.credential_id 
                where cred.name like '%$($UserName)%' and prox.enabled = 1"; $R = ExecuteSqlQuery -Query $credQuery -Server $ServerName      
                
                If($R)
                {
                    $AlterCred = "ALTER CREDENTIAL [$($R.Name)] WITH IDENTITY = N'$($R.Name)', SECRET = N'$($Password)'"; 
                    $S = ExecuteSqlQuery -Query $AlterCred -Server $ServerName
                    

                    if($S[0] -eq 0)
                    {
                        write-host -ForegroundColor Cyan -BackgroundColor Black "Information : SQL Proxy crdential sucessfully updated on [$($ServerName)] for Service account [$($R.Name)]"    
                    }
                    else
                    {
                        write-host -ForegroundColor red -BackgroundColor Black "Error : Failed to Update SQL Proxy credential on [$($ServerName)] for Service Account [$($R.Name)]."
                    }
                }
                else
                {"No Proxy Account Found"}
            }
                Catch 
                {
                    write-host -ForegroundColor red -BackgroundColor Black "Error: SQL Proxy Account updation Failed [$($Error[0].Exception.Message)]"
                }
            }
            else
            {
                write-host -ForegroundColor Cyan -BackgroundColor Black "SQL Service found in Stopped State"
                $SQLStatus
            }
        }
        else {"No SQL Found on $servername"}
    } #Updated
        $WinAutoLogOn                        =  {
    Param($ServiceAccount, $Server, $DefaultPassword)
    $RegPath = "hklm:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\" 
    $r = Get-ChildItem $RegPath 

    If($r.AutoAdminLogon -eq 1)
    {
        write-host -ForegroundColor Cyan -BackgroundColor Black "Windows Auto Logon Enabled on Server : $($Server)"
        
        If($r.DefaultUserName -like "*$($ServiceAccount)*") 
        {
            write-host -ForegroundColor Cyan -BackgroundColor Black "$ServiceAccount :  account is in use as Windows Auto Logon."
            write-host -ForegroundColor Cyan -BackgroundColor Black "Updating Password..."

            Set-ItemProperty $RegPath "AutoAdminLogon" -Value "1" -type String  
            Set-ItemProperty $RegPath "DefaultUsername" -Value "$ServiceAccount" -type String  
            Set-ItemProperty $RegPath "DefaultPassword" -Value "$DefaultPassword" -type String

        }
        else
        {
            write-host -ForegroundColor Cyan -BackgroundColor Black "$ServiceAccount not in use."
        }    
    }
} #Code Added but not using
     
        $AzureAccount                =  [Environment]::UserName + "@microsoft.com"
        $Fulluser = $ServiceAccount.Trim()
        $user = $Fulluser.Substring($Fulluser.IndexOf('\')+1,(($Fulluser.Length)) - $Fulluser.IndexOf('\')-1) #Pulling the Name from the Service account after removing the Domain name       
        $session = New-PSSession -ComputerName $server -Credential $Credential

        If($AzureKeyVault -eq 'True')
        {
            if(AzureLogin -AzureSubAdmin $AzureAccount -VaultName $KeyVaultName -Sub_Name $SubscriptionName -ResourceGrp $ResourceGroup) 
            {
                write-host -ForegroundColor Cyan "4. Pulling Existing Credentials from Azure KeyVault {$($KeyVaultName)}."
                Try
                {
                    $Results = (Get-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $user.Trim())
                    Write-host -ForegroundColor Cyan "5. Service Account {$Results.Name} found in AKV {$KeyVaultName}"

                    if($Results.Name -eq $user.Trim())
                    {
                        $Credentials = $Results.SecretValueText.Split(" ")
                        $AKVPassword = $Credentials[2].ToString()
                        $AKVOldPassword=$Credentials[3].ToString()
                        
                        write-host    ""
                        write-host    "Validating and Updating Web Application pool on : $server"
                        write-host  -ForegroundColor Cyan -BackgroundColor Black  "------------------------------------------------------------------------------------"
                        Invoke-Command -Session $session -ScriptBlock $AppPool -ArgumentList($user,$AKVPassword) 

                        write-host    ""
                        write-host    "Validating and Updating Web Anonymous Authentication on : $server"
                        write-host -ForegroundColor Cyan -BackgroundColor Black   "------------------------------------------------------------------------------------"
                        Invoke-Command -Session $session -ScriptBlock $IISWebSiteAuthenticationCredentials -ArgumentList($server, $user,$AKVPassword)

    
                        write-host    ""
                        write-host    "Validating & Updating Windows Services on : $server"
                        write-host  -ForegroundColor Cyan -BackgroundColor Black  "------------------------------------------------------------------------------------"
                        Invoke-Command -Session $session -ScriptBlock $GetServiceRunningAccounts -ArgumentList($user,$AKVPassword) 

                        write-host    ""
                        write-host    "Validating & Updating SQL Services on : $server"
                        write-host -ForegroundColor Cyan -BackgroundColor Black   "------------------------------------------------------------------------------------"
                        Invoke-Command -Session $session -ScriptBlock $SQLChange -ArgumentList($user,$AKVPassword, $AKVOldPassword, $server) 

                        write-host    ""
                        write-host    "Validating & Updating SQL Proxy Accounts on : $server"
                        write-host -ForegroundColor Cyan -BackgroundColor Black   "------------------------------------------------------------------------------------"
                        Invoke-Command -Session $session -ScriptBlock $SQLProxy -ArgumentList($server, $user,$AKVPassword) 

                        write-host    ""
                        write-host    "Validating & Updating Windows Task Scheduler on : $server"
                        write-host -ForegroundColor Cyan -BackgroundColor Black   "------------------------------------------------------------------------------------"  
                        Invoke-Command -Session $session -ScriptBlock $GetSchduleTaskUsers -ArgumentList($user, $FullUser,$AKVPassword) 

                        write-host    ""
                        write-host    "Validating & Updating System Cached Credentials on : $server"
                        write-host -ForegroundColor Cyan -BackgroundColor Black   "------------------------------------------------------------------------------------"
                        Invoke-Command -Session $session -ScriptBlock $Cached -ArgumentList($user,$AKVPassword) 

                        write-host    ""
                        write-host    "Validating & Updating COM+ Applications on : $server"
                        write-host -ForegroundColor Cyan -BackgroundColor Black   "------------------------------------------------------------------------------------"
                        Invoke-Command -Session $session -ScriptBlock $COMAccount -ArgumentList($user,$AKVPassword, $server) 
                        write-host ""
                        $Retrun = $true
                    }
                    else{"Credential not Found on Vault"}
                }
                Catch {$Retrun = $false}
            }
            else {write-host "Azure Authentication Failed."}
        }
        else
        {
            Try
            {
               write-host    ""
               write-host    "Validating and Updating Web Application pool on : $($Server)"
               write-host -ForegroundColor Cyan -BackgroundColor Black   "------------------------------------------------------------------------------------"
               Invoke-Command -Session $session -ScriptBlock $AppPool -ArgumentList($user,$Password) 

           
               write-host    ""
               write-host    "Validating and Updating Web Anonymous Authentication on : $($server)"
               write-host  -ForegroundColor Cyan -BackgroundColor Black  "------------------------------------------------------------------------------------"
               Invoke-Command -Session $session -ScriptBlock $IISWebSiteAuthenticationCredentials -ArgumentList($server.trim(), $user,$Password)
    
               write-host    ""
               write-host    "Validating & Updating Windows Services on : $($Server)"
               write-host  -ForegroundColor Cyan -BackgroundColor Black  "------------------------------------------------------------------------------------"
               Invoke-Command -Session $session -ScriptBlock $GetServiceRunningAccounts -ArgumentList($user,$Password) 

               write-host    ""
               write-host    "Validating & Updating SQL Services on : $($Server)"
               write-host -ForegroundColor Cyan -BackgroundColor Black   "------------------------------------------------------------------------------------"
               Invoke-Command -Session $session -ScriptBlock $SQLChange -ArgumentList($user,$Password,$OldPassword,$server.trim())

               write-host    ""
               write-host    "Validating & Updating SQL Proxy Accounts on : $($Server)"
               write-host -ForegroundColor Cyan -BackgroundColor Black   "------------------------------------------------------------------------------------"
               Invoke-Command -Session $session -ScriptBlock $SQLProxy -ArgumentList($server.Trim(), $user,$Password) 
           

               write-host    ""
               write-host    "Validating & Updating Windows Task Scheduler on : $($Server)"
               write-host -ForegroundColor Cyan -BackgroundColor Black    "------------------------------------------------------------------------------------"  
               Invoke-Command -Session $session -ScriptBlock $GetSchduleTaskUsers -ArgumentList($user, $FullUser,$Password) 

               write-host    ""
               write-host    "Validating & Updating System Cached Credentials on : $($Server)"
               write-host -ForegroundColor Cyan -BackgroundColor Black   "------------------------------------------------------------------------------------"
               Invoke-Command -Session $session -ScriptBlock $Cached -ArgumentList($user,$Password) 

               write-host    ""
               write-host    "Validating & Updating COM+ Applications on : $($Server)"
               write-host -ForegroundColor Cyan -BackgroundColor Black   "------------------------------------------------------------------------------------"
               Invoke-Command -Session $session -ScriptBlock $COMAccount -ArgumentList($user,$Password,$server)
               write-host    ""
               $Retrun = $true
            }
            catch{$Retrun = $false}
        }

        Remove-PSSession $session
    }
    catch
    {
        $Retrun = $false
    }} -ArgumentList $_, $Details.ServiceAccount, $Details.NewPassword, $Details.OldPassword,'False', $cred  }| Wait-Job | Receive-Job 
    
    #-ArgumentList $_, $Details.ServiceAccount, $Details.NewPassword,$Details.OldPassword ,'True', $cred, $subscription, $ResourceGrp, $KeyVault }| Wait-Job | Receive-Job  
    
    #FileSystem values              : -ArgumentList $_, $Details.ServiceAccount, $Details.NewPassword, $Details.OldPassword,'False', $cred  }| Wait-Job | Receive-Job 
    #AKV Values If want to leverage : -ArgumentList $_, $Details.ServiceAccount, $Details.NewPassword,$Details.OldPassword ,'True', $cred, $subscription, $ResourceGrp, $KeyVault }| Wait-Job | Receive-Job  
}

Write-Host -ForegroundColor Yellow -BackgroundColor Black "End Time : $(get-date)"
Stop-Transcript
    
Remove-Variable * -ErrorAction SilentlyContinue; Remove-Module *;